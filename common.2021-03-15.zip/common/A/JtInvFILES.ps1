Set-StrictMode -version latest
$ErrorActionPreference = "Stop"

New-JtInvFiles

