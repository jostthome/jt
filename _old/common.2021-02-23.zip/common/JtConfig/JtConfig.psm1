using module Jt  
using module JtIo

class JtConfig : JtClass {

    [JtIoFolder]$JtIoFolder_Base
    [JtIoFolder]$JtIoFolder_Report
    [JtIoFolder]$JtIoFolder_Inv
    
    JtConfig() {
        $This.ClassName = "JtConfig"
        Write-JtLog -Where $This.ClassName -Text "START!"
        
        [String]$MyProjectPath = Get-JtFolderPath_Base

        $This.JtIoFolder_Base = [JtIoFolder]::new($MyProjectPath)
        $This.JtIoFolder_Report = New-JtIoFolder_Report
        $This.JtIoFolder_Inv = New-JtIoFolder_Inv
    }

    [Boolean]DoPrintInfo() {
        #        Write-Host "SHOULD BE LIKE: Get_JtIoFolder_Base   : D:\Seafile\al-apps\apps\inventory"
        [String]$FolderPathBase = $This.Get_JtIoFolder_Base().GetPath()
        Write-JtLog -Where $This.ClassName -Text "Path of JtIoFolder_Base: $FolderPathBase"
        return $True
    }
    
    # --------------------------------------------------------------------------------------
    [JtIoFolder]Get_JtIoFolder_Base() {
        return $This.JtIoFolder_Base
    }

    [JtIoFolder]Get_JtIoFolder_Inv() {
        return $This.JtIoFolder_Inv
    }

    [JtIoFolder]Get_JtIoFolder_Report() {
        return $This.JtIoFolderReport
    }
}

Function New-JtConfig {

    [JtConfig]::new()
}

