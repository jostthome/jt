using module Jt
using module JtIo
using module JtInf
using module JtTbl

class JtInf_AFolder : JtInf {

    [Boolean]$IsValid = $True

    [JtFld]$Name
    [JtFld]$JtVersion
    [JtFld]$Alias
    [JtFld]$Computername
    [JtFld]$DaysAgo
    [JtFld]$Errors
    [JtFld]$FolderPath
    [JtFld]$Ip
    [JtFld]$Ip3
    [JtFld]$KlonVersion
    [JtFld]$LabelC
    [JtFld]$Org
    [JtFld]$Org1
    [JtFld]$Org2
    [JtFld]$ReportExists
    [JtFld]$SystemId
    [JtFld]$Timestamp
    [JtFld]$Type
    [JtFld]$User
    [JtFld]$WinBuild
    [JtFld]$WinGen
    [JtFld]$WinVersion


    static [String]GetIp([String]$TheFolderPath) {
        [String]$MyIp = ""
        [String]$MyFilePath_Ipconfig = -join ($TheFolderPath, "\", [JtIo]::FilePrefix_Report, ".", "ip", [JtIo]::FileExtension_Meta) 
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $MyFilePath_Ipconfig
        if ($MyJtIoFile.IsExisting()) {
            [String]$MyConIpconfig = Get-Content -Path $MyFilePath_Ipconfig
            $MyIp = $MyConIpconfig
        }
        return $MyIp
    }


    static [String]GetMasterUser([String]$FolderPath) {
        [String]$MyResult = "---"
        
        [String]$Match = -join ([JtIo]::FilePrefix_Report, '.*.', 'user', [JtIo]::FileExtension_Meta)
        
        $MyAlFiles = Get-ChildItem -Path $FolderPath | Where-Object { $_.Name -match $Match }
        
        if ($Null -ne $MyAlFiles) {
            if ($MyAlFiles.Length -gt 0) {
                $Filename = $MyAlFiles[0].Name
                [String[]]$Parts = $Filename.Split(".")
                $MyResult = $Parts[1]
            }
        }
        
        return $MyResult
    }


    static [String]GetKlonVersion([String]$FolderPath) {
        [String]$MyResult = "---"
        
        [String]$Match = -join ('_*.klon', [JtIo]::FileExtension_Meta)
        
        $MyAlFiles_Meta = Get-ChildItem -Path $FolderPath | Where-Object { $_.Name -match $Match }
        
        if ($Null -ne $MyAlFiles_Meta) {
            if ($MyAlFiles_Meta.Length -gt 0) {
                $File1 = $MyAlFiles_Meta[0]
                $MyResult = [JtIo]::GetDateForKlon($File1)
            }
        }
        return $MyResult
    }


    static [String]GetTheTimestamp([String]$TheFolderPath) {
        [String]$TypeName = ""
        [String]$Stamp = ""
        $MyDate = [JtIoFolder]::GetReportFolderDateTime($TheFolderPath)
        $TypeName = $MyDate.getType().Name
        if ($TypeName -eq "DateTime") {
            $Stamp = $MyDate.toString([JtIo]::TimestampFormat) 
        }
        return $Stamp
    }
    
    static [String]GetJtVersion([String]$TheFolderPath) {
        [String]$MyExtension = -join (".version", [JtIo]::FileExtension_Meta)
        [String]$MyFilter = -join ("*", $MyExtension)

        [JtIoFolder]$MyJtIoFolder = [JtIoFolder]::new($TheFolderPath)
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter
        
        [String]$MyOut = "not found"
        if ($MyAlJtIoFiles.Count -eq 1) {
            [JtIoFile]$MyJtIoFile = $MyAlJtIoFiles[0]
            $MyOut = $MyJtIoFile.GetName()

            $MyOut = $MyOut.Replace($MyExtension, "")
            $MyOut = $MyOut.Replace("report.", "")
        }

        return $MyOut
    }

    
    static [String]GetWinVersion([String]$TheFolderPath) {
        [String]$WinV = ""
        [String]$FilePathWinMeta = -join ($TheFolderPath, "\", [JtIo]::FilePrefix_Report, ".", "win", [JtIo]::FileExtension_Meta) 
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $FilePathWinMeta
        if ($MyJtIoFile.IsExisting()) {
            [String]$conWinMet = Get-Content -Path $FilePathWinMeta
            $winMetParts = $conWinMet.Split(" ")
            if ($winMetParts.Length -ge 4) {
                $winVer = $winMetParts[4]
                
                $winVer = $winVer.Replace("]", "")
                $WinV = $winVer
            }
        }
        return $WinV
    }

    static [String]GetWinVersionBuild([String]$WinVersion) {
        [String]$MyResult = 0
        if ($Null -eq $WinVersion) {
 
        }
        else {
            [String[]]$Parts = $WinVersion.Split(".")
            if ($Parts.Count -gt 3) {
                $MyResult = $Parts[3]
            }
        }
        return $MyResult
    }

    static [String]GetWinVersionGen([String]$WinVersion) {
        [String]$MyResult = 0
        if ($Null -eq $WinVersion) {
     
        }
        else {
            [String[]]$Parts = $WinVersion.Split(".")
            if ($Parts.Count -gt 3) {
                $MyResult = $Parts[2]
            }
        }
        return $MyResult
    }
    


    JtInf_AFolder() {
        $This.Name = New-JtFld -Label "Name"
        $This.JtVersion = New-JtFld -Label "JtVersion"
        $This.Alias = New-JtFld -Label "Alias"
        $This.Computername = New-JtFld -Label "Computername"
        $This.DaysAgo = New-JtFld -Label "DaysAgo"
        $This.Errors = New-JtFld -Label "Errors"
        $This.FolderPath = New-JtFld -Label "FolderPath"
        $This.Ip = New-JtFld -Label "Ip"
        $This.Ip3 = New-JtFld -Label "Ip3"
        $This.KlonVersion = New-JtFld -Label "KlonVersion"
        $This.LabelC = New-JtFld -Label "LabelC"
        $This.Org = New-JtFld -Label "Org"
        $This.Org1 = New-JtFld -Label "Org1"
        $This.Org2 = New-JtFld -Label "Org2"
        $This.ReportExists = New-JtFld -Label "ReportExists"
        $This.SystemId = New-JtFld -Label "SystemId"
        $This.Timestamp = New-JtFld -Label "Timestamp"
        $This.Type = New-JtFld -Label "Type"
        $This.User = New-JtFld -Label "User"
        $This.WinVersion = New-JtFld -Label "WinVersion"
        $This.WinBuild = New-JtFld -Label "WinBuild"
        $This.WinGen = New-JtFld -Label "WinGen"
    }

}
Function New-JtInf_AFolder {
    
    [JtInf_AFolder]::new()
}

Function Get-JtInf_AFolder {
    
    #[OutputType([JtInf_AFolder])]
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [String]$MyFunctionName = "Get-JtInf_AFolder"
    [JtInf_AFolder]$MyJtInf = New-JtInf_AFolder

    [JtIoFolder]$MyJtIoFolder = $Null
    if ($FolderPath) {
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPath
    }
    else {
        Write-JtError -Where $MyFunctionName -Text "PATH is NULL! Using default. PATH: $MyJtIoFolder"
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder_Report
    }
    [String]$MyFolderPath = $MyJtIoFolder.GetPath()
        

    if (!($MyJtIoFolder.IsExisting())) {
        Write-JtError -Where $MyFunctionName -Text "Folder does not exist: MyJtIoFolder: $MyJtIoFolder"
        return $MyJtInf
    }

    [JtTimeStop]$MyTimeStop = [JtTimeStop]::new()
    [String]$MyMessage = "Preparing Information for: $MyFolderPath"
    $MyTimeStop.Start($MyMessage)
    
    $MyJtInf.Get_FolderPath().SetValue($MyFolderPath)

    [String]$MyId = $MyFolderPath
    $MyJtInf.SetId($Myid)
    
    [String]$MyFolderName = $MyJtIoFolder.GetName()
    $MyJtInf.Get_Name().SetValue($MyFolderName)
    $MyJtInf.IsValid = $True

    [String]$MyLabelC = "label_c"
    [String]$MyComputername = "computername"
    [String]$MySystemId = "systemid"
    
    if ("report" -eq $MyFolderName) {
        $MyComputername = $env:COMPUTERNAME
        $MyLabelC = [JtIo]::GetLabelC()
    }
    else {
        [String[]]$MyAlParts = $MyFolderName.Split(".")
        if ($MyAlParts.length -lt 2) {
            Write-JtError -Where $This.ClassName -Text "Ungueltiger Name: $MyFolderName - $MyFolderPath"
            $MyJtInf.IsValid = $False
        }
        else {
            $MyComputername = $MyAlParts[0]
            $MyLabelC = $MyAlParts[1]
        }
    }

    [JtComputername]$MyJtComputername = New-JtComputername -Name $MyComputername

    $MyJtInf.Get_LabelC().SetValue($MyLabelC)
    $MyJtInf.Get_Computername().SetValue($MyComputername)

    $MySystemId = -join ($MyComputername, ".", $MyLabelC)
    $MyJtInf.Get_SystemId().SetValue($MySystemId)

    [String]$MyAlias = [JtIo]::GetAliasForComputername($MyComputername)
    $MyJtInf.Get_Alias().SetValue($MyAlias)

    $MyJtInf.Get_Org().SetValue($MyJtComputername.GetOrg())
    $MyJtInf.Get_Org1().SetValue($MyJtComputername.GetOrg1())
    $MyJtInf.Get_Org2().SetValue($MyJtComputername.GetOrg2())
    $MyJtInf.Get_Type().SetValue($MyJtComputername.GetType())


    if (Test-JtIoFolderPath -FolderPath $MyFolderPath) {
        [String]$MyJtVersion = [JtInf_AFolder]::GetJtVersion($MyFolderPath)
        $MyJtInf.Get_JtVersion().SetValue($MyJtVersion)

        [String]$MyTimestamp = [JtInf_AFolder]::GetTheTimestamp($MyFolderPath)
        $MyJtInf.Get_Timestamp().SetValue($MyTimestamp)

        [String]$MyDaysAgo = Get-JtReportLogDaysAgo -FolderPath $MyFolderPath
        $MyJtInf.Get_DaysAgo().SetValue($MyDaysAgo)

        [String]$MyWinVersion = [JtInf_AFolder]::GetWinVersion($MyFolderPath)
        $MyJtInf.Get_WinVersion().SetValue($MyWinVersion)

        [String]$MyWinGen = [JtInf_AFolder]::GetWinVersionGen($MyWinVersion)
        $MyJtInf.Get_WinGen().SetValue($MyWinGen)

        [String]$MyWinBuild = [JtInf_AFolder]::GetWinVersionBuild($MyWinVersion)
        $MyJtInf.Get_WinBuild().SetValue($MyWinBuild)

        [String]$MyKlonVersion = [JtInf_AFolder]::GetKlonVersion($MyFolderPath)
        $MyJtInf.Get_KlonVersion().SetValue($MyKlonVersion)

        [String]$MyIp = [JtInf_AFolder]::GetIp($MyFolderPath)
        $MyJtInf.Get_Ip().SetValue($MyIp)

        [String]$MyIp3 = Convert-JtIp_To_Ip3 -Ip $MyIp
        $MyJtInf.Get_Ip3().SetValue($MyIp3)

        [String]$MyUser = [JtInf_AFolder]::GetMasterUser($MyFolderPath)
        $MyJtInf.Get_User().SetValue($MyUser)

        
        [String]$MyReportExists = $True
        $MyJtInf.Get_ReportExists().SetValue($MyReportExists)
    }
    else {
        $MyJtInf.IsValid = $False
    }

    return $MyJtInf
}

Export-ModuleMember -Function New-JtInf_AFolder
Export-ModuleMember -Function Get-JtInf_AFolder
