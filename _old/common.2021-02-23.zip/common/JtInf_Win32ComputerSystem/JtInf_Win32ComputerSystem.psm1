using module JtInf
using module JtIo
using module JtTbl

class JtInf_Win32ComputerSystem : JtInf {


    [JtFld]$Modell
    [JtFld]$Herst
    [JtFld]$Ram
    [JtFld]$Computername
    [JtFld]$Owner 
    [JtFld]$Domain


    JtInf_Win32ComputerSystem () {
        $This.Modell = New-JtFld -Label "Modell"
        $This.Herst = New-JtFld -Label "Herst"
        $This.Ram = New-JtFld -Label "Ram"
        $This.Computername = New-JtFld -Label "Computername"
        $This.Owner = New-JtFld -Label "Owner"
        $This.Domain = New-JtFld -Label "Domain"
    }
    
}

Function New-JtInf_Win32ComputerSystem {

    [JtInf_Win32ComputerSystem]::new()
}


Function Get-JtInf_Win32ComputerSystem {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Win32ComputerSystem]$MyJtInf = New-JtInf_Win32ComputerSystem

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

        
    
    [String]$MyName = "Win32_ComputerSystem"
    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName

    if ($MyObj) {
        $MyJtInf.Computername.SetValue($MyObj.Name)
        $MyJtInf.Herst.SetValue($MyObj.Manufacturer)
        $MyJtInf.Modell.SetValue($MyObj.Model)
        
        [String]$MyGB = Convert-JtString_To_Gb -Text $MyObj.TotalPhysicalMemory
        
        $MyJtInf.Ram.SetValue($MyGB)
        $MyJtInf.Owner.SetValue($MyObj.PrimaryOwnerName)
        $MyJtInf.Domain.SetValue($MyObj.Domain)
    }
    return [JtInf_Win32ComputerSystem]$MyJtInf
}
    
Export-ModuleMember -Function Get-JtInf_Win32ComputerSystem
Export-ModuleMember -Function New-JtInf_Win32ComputerSystem
