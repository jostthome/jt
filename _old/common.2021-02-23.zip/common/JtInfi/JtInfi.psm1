using module Jt
using module JtIo
using module JtInf_AFolder
using module JtInf_Bitlocker
using module JtInf_Soft
using module JtInf_Win32Bios
using module JtInf_Win32ComputerSystem
using module JtInf_Win32LogicalDisk
using module JtInf_Win32NetworkAdapter
using module JtInf_Win32OperatingSystem
using module JtInf_Win32Processor
using module JtInf_Win32VideoController

class JtInfi : JtClass {
    
    hidden [JtIoFolder]$JtIoFolder

    hidden [Boolean]$Valid = $False
    hidden [Boolean]$IsValidCsv = $False
    hidden [Boolean]$IsValidXml = $False

    hidden [JtInf_AFolder]$Cache_JtInf_AFolder = $Null
    hidden [JtInf_Bitlocker]$Cache_JtInf_Bitlocker = $Null
    hidden [JtInf_Soft]$Cache_JtInf_Soft = $Null
    hidden [JtInf_Win32Bios]$Cache_JtInf_Win32Bios = $Null
    hidden [JtInf_Win32ComputerSystem]$Cache_JtInf_Win32ComputerSystem = $Null
    hidden [JtInf_Win32LogicalDisk]$Cache_JtInf_Win32LogicalDisk = $Null
    hidden [JtInf_Win32NetworkAdapter]$Cache_JtInf_Win32NetworkAdapter = $Null
    hidden [JtInf_Win32OperatingSystem]$Cache_JtInf_Win32OperatingSystem = $Null
    hidden [JtInf_Win32Processor]$Cache_JtInf_Win32Processor = $Null
    hidden [JtInf_Win32VideoController]$Cache_JtInf_Win32VideoController = $Null

    JtInfi([JtIoFolder]$MyJtIoFolder) : base() {
        $This.ClassName = "JtInfi"
        if($Null -eq $MyJtIoFolder) {
            Write-JtError -Where $This.ClassName -Text "Folder is NULL"
            Throw "Folder is NULL"
        }
        $This.JtIoFolder = $MyJtIoFolder
        #  Get-JtInf_AFolder -JtIoFolder $This.JtIoFolder 
    }

    [Boolean]GetIsNormalBoot() {
        # Example: For al-dek-nb-dek05.win10p the result should be: $True
        # Example: For al-its-pc-h38.win10p the result should be: $True
        # Example: For al-its-pc-h38.win10p-spezial the result should be: $False

        [Boolean]$MyResult = $True
        [Boolean]$Spezial = $This.GetJtInf_AFolder().SystemId.GetValue().Contains("spezial")
        if ($True -eq $Spezial) {
            $MyResult = $False
        }
        return $MyResult
    }
    
    [JtInf_AFolder]GetJtInf_AFolder() {
        [JtInf_Afolder]$MyJtInf = $This.Cache_JtInf_AFolder
        if ($Null -eq $MyJtInf) {
            [JtInf_Afolder]$MyJtInf = Get-JtInf_AFolder -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_AFolder = $MyJtInf
        }
        return $MyJtInf
    }

    [JtInf_Bitlocker]GetJtInf_Bitlocker() {
        [JtInf_Bitlocker]$MyJtInf = $This.Cache_JtInf_Bitlocker
        if ($Null -eq $MyJtInf) {
            [JtInf_Bitlocker]$MyJtInf = Get-JtInf_Bitlocker -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Bitlocker = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Soft]GetJtInf_Soft() {
        [JtInf_Soft]$MyJtInf = $This.Cache_JtInf_Soft
        if ($Null -eq $MyJtInf) {
            # $MyJtInf = Get-JtInf_Soft -FolderPath $This.GetJtIoFolder()
            # [JtInf_Soft]$MyJtInf = $MyJtInf[-1]
            [JtInf_Soft]$MyJtInf = Get-JtInf_Soft -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Soft = $MyJtInf
        }
        return $MyJtInf
    }

    [JtInf_Win32Bios]GetJtInf_Win32Bios() {
        [JtInf_Win32Bios]$MyJtInf = $This.Cache_JtInf_Win32Bios
        if ($Null -eq $MyJtInf) {
            $MyInf = Get-JtInf_Win32Bios -FolderPath $This.GetJtIoFolder()
            [JtInf_Win32Bios]$MyJtInf = $MyInf
            $This.Cache_JtInf_Win32Bios = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Win32ComputerSystem]GetJtInf_Win32ComputerSystem() {
        [JtInf_Win32ComputerSystem]$MyJtInf = $This.Cache_JtInf_Win32ComputerSystem
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32ComputerSystem]$MyJtInf = Get-JtInf_Win32ComputerSystem -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32ComputerSystem = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Win32LogicalDisk]GetJtInf_Win32LogicalDisk() {
        [JtInf_Win32LogicalDisk]$MyJtInf = $This.Cache_JtInf_Win32LogicalDisk
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32LogicalDisk]$MyJtInf = Get-JtInf_Win32LogicalDisk -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32LogicalDisk = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Win32NetworkAdapter]GetJtInf_Win32NetworkAdapter() {
        [JtInf_Win32NetworkAdapter]$MyJtInf = $This.Cache_JtInf_Win32NetworkAdapter
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32NetworkAdapter]$MyJtInf = Get-JtInf_Win32NetworkAdapter -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32NetworkAdapter = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Win32OperatingSystem]GetJtInf_Win32OperatingSystem() {
        [JtInf_Win32OperatingSystem]$MyJtInf = $This.Cache_JtInf_Win32OperatingSystem
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32OperatingSystem]$MyJtInf = Get-JtInf_Win32OperatingSystem -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32OperatingSystem = $MyJtInf
        }
        return $MyJtInf
    }
    
    [JtInf_Win32Processor]GetJtInf_Win32Processor() {
        [JtInf_Win32Processor]$MyJtInf = $This.Cache_JtInf_Win32Processor
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32Processor]$MyJtInf = Get-JtInf_Win32Processor -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32Processor = $MyJtInf
        }
        return $MyJtInf
    }

    [JtInf_Win32VideoController]GetJtInf_Win32VideoController() {
        [JtInf_Win32VideoController]$MyJtInf = $This.Cache_JtInf_Win32VideoController
        if ($Null -eq $MyJtInf) {
            [JtInf_Win32VideoController]$MyJtInf = Get-JtInf_Win32VideoController -FolderPath $This.GetJtIoFolder()
            $This.Cache_JtInf_Win32VideoController = $MyJtInf
        }
        return $MyJtInf
    }

    [JtIoFolder]GetJtIoFolder() {
        return $This.JtIoFolder
    }

    [String]GetOutput() {
        $This.GetJtInf_AFolder()
        $This.GetJtInf_Bitlocker()
        $This.GetJtInf_Soft()
        $This.GetJtInf_Win32Bios()
        $This.GetJtInf_Win32ComputerSystem()
        $This.GetJtInf_Win32LogicalDisk()
        $This.GetJtInf_Win32NetworkAdapter()
        $This.GetJtInf_Win32OperatingSystem()
        $This.GetJtInf_Win32Processor()
        $This.GetJtInf_Win32VideoController()
        return "output"
    }
    
    [Boolean]IsValid() {
        return $This.GetJtInf_AFolder().IsValid()
    }
}

Function New-JtInfi {
    Param (
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [JtIoFolder]$MyJtIoFolder = $Null
    if($FolderPath) {
        $MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPath
    } else {
        $MyJtIoFolder = New-JtIoFolder_Report
    }
    [JtInfi]$MyJtInfi = [JtInfi]::new($MyJtIoFolder)
    $MyJtInfi

}

Export-ModuleMember -Function New-JtInfi 