using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32NetworkAdapter : JtRep {

    JtRep_Obj_Win32NetworkAdapter() : Base("obj.win32_networkadapter") {
        $This.ClassName = "JtRep_Obj_Win32NetworkAdapter"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        # $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Ip) | Out-Null 
        # $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Ip3) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().MAC) | Out-Null 
        return $MyJtTblRow
    }
}


Function New-JtRep_Obj_Win32NetworkAdapter {

    [JtRep_Obj_Win32NetworkAdapter]::new() 

}


