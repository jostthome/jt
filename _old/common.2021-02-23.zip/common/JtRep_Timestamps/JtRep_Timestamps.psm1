using module JtIo
using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Timestamps : JtRep {

    JtRep_Timestamps () : Base("report.timestamps") {
        $This.ClassName = "JtRep_Timestamps"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$TheJtInfi) {
        [JtInfi]$MyJtInfi = $TheJtInfi
        [JtTblRow]$MyJtTblRowFiles = New-JtTblRow
        [JtIoFolder]$MyJtIoFolder = $MyJtInfi.GetJtIoFolder()
        [JtIoFolder]$MyJtIoFolderReportTimestamp = $MyJtIoFolder.GetJtIoFolder_Sub("timestamp")
        if(!($MyJtIoFolderReportTimestamp.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "GetjtTblRow. FOLDER timestamp is missing."
            return $Null
        }
        [String]$MyExtension = [JtIo]::FileExtension_Meta_Time
        [String]$MyFilter = -join ("*.", $MyExtension)

        [String]$MyLabel = ""
        [String]$MyValue = ""
        
        [String]$MyMaxTime = ""
        [String]$MyMaxDate = ""
        
        [int32]$i = 0

        $MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter
        Foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyColumnName = -join ("Time", $i)
    
            # example: report.2020-05-02_17-35-42.export.time.meta
            [String]$MyFilename = $MyJtIoFile.GetName()

            [String]$MyLabel = $MyFilename.Replace($MyExtension, "")
            [String]$MyFilename = $MyLabel.Replace( -join ([JtIo]::FilePrefix_Report, "."), "")

            $MyAlParts = $MyFileName.Split(".")
            $MyLabel = -join ("Time", $i)

            $MyValue = $MyFileName
            $MyTimeInfo = ""
            try {

                $MyTimeInfo = [datetime]::ParseExact($MyAlParts[0], "yyyy-MM-dd_HH-mm-ss", $null);  
                $MyMaxTime = $MyTimeInfo.ToString("HHmm")
                $MyMaxDate = $MyTimeInfo.ToString("yyyy-MM-dd")
            }
            catch {
                Write-JtError -Where $This.ClassName -Text "Problem: $MyAlParts[0]"
            }

            $MyJtTblRowFiles.Add($MyLabel, $MyValue) | Out-Null

            $i = $i + 1
        }


        [JtTblRow]$MyJtTblRow = New-JtTblRow
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().SystemId) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Errors) | Out-Null

        [String]$MyLabel = "TimeCount"
        [String]$MyValue = $i
        $MyJtTblRow.Add($MyLabel, $MyValue) | Out-Null

        [String]$MyLabel = "TimeTime"
        [String]$MyValue = $MyMaxTime
        $MyJtTblRow.Add($MyLabel, $MyValue) | Out-Null

        [String]$MyLabel = "TimeDate"
        [String]$MyValue = $MyMaxDate
        $MyJtTblRow.Add($MyLabel, $MyValue) | Out-Null

        [String]$MyLabel = "Errors"
        [String]$MyFolderPath = $MyJtInfi.GetJtInf_AFolder().Get_FolderPath()
        [String]$intErrors = [JtIo]::GetErrors($MyFolderPath)
        [String]$MyValue = $IntErrors
        $MyJtTblRow.Add($MyLabel, $MyValue) | Out-Null
        $MyJtTblRow.Join($MyJtTblRowFiles)
        return $MyJtTblRow
    }
}
Function New-JtRep_Timestamps {

    [JtRep_Timestamps]::new() 

}
