using module Jt  
using module JtInfi
using module JtIo

using module JtRep
using module JtRep_Bitlocker
using module JtRep_Folder
using module JtRep_Hardware
using module JtRep_HardwareSn
using module JtRep_Net
using module JtRep_Software
using module JtRep_SoftwareAdobe
using module JtRep_SoftwareMicrosoft
using module JtRep_SoftwareMicrosoftNormal
using module JtRep_SoftwareOpsi
using module JtRep_SoftwareSecurity
using module JtRep_SoftwareSupport
using module JtRep_SoftwareVray
using module JtRep_Z_G13
using module JtRep_Z_Iat
using module JtRep_Z_Lab
using module JtRep_Z_Pools
using module JtRep_Z_Server
using module JtRep_Z_Vorwag
using module JtRep_Timestamps
using module JtRep_Obj_Win32Bios
using module JtRep_Obj_Win32Computersystem
using module JtRep_Obj_Win32LogicalDisk
using module JtRep_Obj_Win32NetworkAdapter
using module JtRep_Obj_Win32OperatingSystem
using module JtRep_Obj_Win32Processor
using module JtRep_Obj_Win32VideoController

using module JtTbl



class JtCsv : JtClass {
    
    [String]$Label = $Null
    [JtIoFolder]$JtIoFolder = $Null
    
    JtCsv([String]$TheLabel, [JtIoFolder]$TheJtIoFolder) {
        $This.ClassName = "JtCsv"
        $This.Label = $TheLabel
        $This.JtIoFolder = $TheJtIoFolder
    }
}


class JtCsvTool : JtClass {

    [JtIoFolder]$JtIoFolderOutput_Combine
    [System.Collections.ArrayList]$AlJtIoFolders_Reports
    [String]$LabelSelection
    
    JtCsvTool([JtIoFolder]$TheJtIoFolderReports, [JtIoFolder]$TheJtIoFolderOutput, [String]$TheLabelSelection, [System.Collections.ArrayList]$TheSelection) {
        $This.ClassName = "JtCsvTool"

        $This.LabelSelection = $TheLabelSelection
        $This.JtIoFolderOutput_Combine = $TheJtIoFolderOutput.GetJtIoFolder_Sub($This.LabelSelection, $True)

        [System.Collections.ArrayList]$MyAlJtIoFolders_Reports = $TheJtIoFolderReports.GetAlJtIoFolders_Sub($True)

        [System.Collections.ArrayList]$MyAlJtIoFolders_Reports_Selected = [JtCsvTool]::GetAlIoFolders_Selected($MyAlJtIoFolders_Reports, $TheSelection) 

        $This.AlJtIoFolders_Reports = $MyAlJtIoFolders_Reports_Selected
    }
    
    JtCsvTool([JtIoFolder]$TheJtIoFolderReports, [JtIoFolder]$TheJtIoFolderOutput) {
        $This.ClassName = "JtCsvTool"
        
        $This.LabelSelection = "all"
        $This.JtIoFolderOutput_Combine = $TheJtIoFolderOutput.GetJtIoFolder_Sub($This.LabelSelection, $True)
  
        [System.Collections.ArrayList]$MyAlJtIoFolders_Reports = $TheJtIoFolderReports.GetAlJtIoFolders_Sub($True)

        $This.AlJtIoFolders_Reports = $MyAlJtIoFolders_Reports
    }

    static [System.Collections.ArrayList]GetAlIoFolders_Selected([System.Collections.ArrayList]$TheAlJtIoFolders, [System.Collections.ArrayList]$TheAlSelection) {
        [System.Collections.ArrayList]$MyAlSelection = $TheAlSelection
        [System.Collections.ArrayList]$MyAlJtIoFolders = $TheAlJtIoFolders

        [System.Collections.ArrayList]$MyAlJtIoFolders_Selected = New-Object System.Collections.ArrayList
        foreach ($Folder in $MyAlJtIoFolders) {
            [JtIoFolder]$MyJtIoFolder = $Folder
            if ($Null -eq $MyAlSelection) {
                $MyAlJtIoFolders_Selected.Add($MyJtIoFolder)
            }
            else {
                [Boolean]$MyBlnSelected = [JtCsvTool]::IsJtIoFolderInSelection($MyJtIoFolder, $MyAlSelection)
                if ($MyBlnSelected) {
                    $MyAlJtIoFolders_Selected.Add($MyJtIoFolder)
                }
            } 
        }
        return $MyAlJtIoFolders_Selected
    }

    static [Boolean]IsJtIoFolderInSelection([JtIoFolder]$TheJtIoFolder, [System.Collections.ArrayList]$TheAlFoldernames) {
        if ($Null -eq $TheAlFoldernames) {
            return $False
        }
        [Boolean]$MyBlnSelected = $False
        foreach ($Element in $TheAlFoldernames) {
            [String]$MyFoldername = $Element.ToString()
            
            [String]$MySearch = -join ("*", $MyFoldername, "*")
            [String]$MyFolderPathFull = $TheJtIoFolder.GetPath()
            if ($MyFolderPathFull -like $MySearch) {
                return $True
            }
        }
        return $MyBlnSelected
    }




    [System.Collections.ArrayList]GetAlJtIoFolders_Sub_Selected([System.Collections.ArrayList]$TheSelection) {
        [System.Collections.ArrayList]$MyAlJtIoFolders = $This.GetAlJtIoFolders_Sub($False)
        [System.Collections.ArrayList]$MyAlJtIoFolders_Selected = [JtCsvTool]::GetAlIoFolders_Selected($MyAlJtIoFolders, $TheSelection)
        return $MyAlJtIoFolders_Selected
    }

    [Boolean]DoIt() {
        [JtIoFolder]$MyJtIoFolderOutput_Combine = $This.JtIoFolderOutput_Combine
        Write-JtLog -Where $This.ClassName -Text "DoIt - MyJtIoFolderOutput_Combine: $MyJtIoFolderOutput_Combine"
        
        [System.Collections.ArrayList]$MyAlFilenames_Csv = $This.GetAlFilenames_Csv()
        foreach ($Filename in $MyAlFilenames_Csv) {
            [String]$MyFilename = $Filename

            [System.Collections.ArrayList]$MyAlJtIoFiles_Csv = [System.Collections.ArrayList]::new()
            [System.Collections.ArrayList]$MyAlFilePaths_Csv = [System.Collections.ArrayList]::new()
            
            [System.Collections.ArrayList]$MyAlJtIoFolders_Reports = $This.AlJtIoFolders_Reports
            foreach ($Folder in $MyAlJtIoFolders_Reports) {
                [JtIoFolder]$MyJtIoFolder = $Folder
                [JtIoFolder]$MyJtIoFolderCsv = $MyJtIoFolder.GetJtIoFolder_Sub("csv")
                if ($MyJtIoFolderCsv.IsExisting()) {
                    [JtIoFile]$MyJtIoFile = $MyJtIoFolderCsv.GetJtIoFile($MyFilename)
                    if ($MyJtIoFile.IsExisting()) {
                        $MyAlJtIoFiles_Csv.Add($MyJtIoFile)
                        $MyAlFilePaths_Csv.Add($MyJtIoFile.GetPath())
                    }
                }
            }

            $MyDataCsv = $MyAlFilePaths_Csv | Import-Csv  -Delimiter ([JtClass]::Delimiter)

            [JtIoFile]$MyJtIoFileOutput = $MyJtIoFolderOutput_Combine.GetJtIoFile($MyFilename)
            [String]$MyFilePathOutput = $MyJtIoFileOutput.GetPath()
            Write-JtIoFile -Where $This.ClassName -Text "Combining for MyFilename: $MyFilename" -FilePath $MyFilePathOutput            
            $MyDataCsv | Export-Csv $MyFilePathOutput -NoTypeInformation -Delimiter ([JtClass]::Delimiter) -Force
        }
        return $True
    }

    [System.Collections.ArrayList]GetAlFilenames_Csv() {
        [System.Collections.ArrayList]$MyAlFilenames = [System.Collections.ArrayList]::new()
        
        [System.Collections.ArrayList]$MyJtReps = [JtReps]::GetJtReps()
        foreach ($Rep in $MyJtReps) {
            [JtRep]$MyJtRep = $Rep
            $MyAlFilenames.Add($MyJtRep.GetFilename_Csv())
        }

        return $MyAlFilenames
    }
}


Function Convert-JtAl_to_FileCsv {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][System.Collections.ArrayList]$ArrayList,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][FolderPathOutput]$FolderPathOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    $MyFunctionName = "Convert-JtAl_to_FileCsv"
    

    $MyAl = $ArrayList
    $MyLabel = $TheLabel
    [String]$MyExtension = [JtIo]::FileExtension_Csv
    [String]$MyFilenameOutput = -join ($MyLabel, $MyExtension)
    $MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPathOutput
    [String]$MyFilePathCsv = $MyJtIoFolder.GetFilePath($MyFilenameOutput)
    
    Write-JtIoFile -Where $MyFunctionName -Text "WARNING. Creating file. EXTENSION: $MyExtension" -FilePath $MyFilePathCsv
    $MyAl | Export-Csv -Path $MyFilePathCsv -NoTypeInformation -Delimiter ([JtClass]::Delimiter)
}


Function Convert-JtAlJtIoFiles_to_FileCsv {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][System.Collections.ArrayList]$ArrayList,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$FilenameTemplate
    )

    [String]$MyFunctionName = " Convert-JtAlJtIoFiles_to_FileCsv"

    [System.Collections.ArrayList]$MyAlJtIoFiles = $ArrayList
    [String]$MyFolderPath_Output = $FolderPathOutput
    [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyFolderPath_Output
    [String]$MyLabel = $Label
    [String]$MyFilenameTemplate = $FilenameTemplate

    Write-JtLog -Where $MyFunctionName -Text "MyLabel: $MyLabel - MyFilenameTemplate: $MyFilenameTemplate - MyJtIoFolderOutput: $MyJtIoFolderOutput"

    [JtTblTable]$MyJtTblTable = New-JtTblTable -Label "FileTable"      
    foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File

        [JtTblRow]$MyJtTblRow = $Null    
        if ($MyFilenameTemplate.Length -lt 1) {
            $MyJtTblRow = Convert-JtIoFile_To_JtTblRow -FilePath $MyJtIoFile
        }
        else {
            $MyJtTblRow = [JtTblFilelist]::GetRowForFileUsingTemplate($MyJtIoFile, $MyFilenameTemplate)
        }
        $MyJtTblTable.AddRow($MyJtTblRow)
    }
    [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
    Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel  
}

Function Convert-JtAlJtIoFiles_to_JtTblTable {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][System.Collections.ArrayList]$ArrayList,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFunctionName = "Convert-JtAlJtIoFiles_to_FileCsv"

    [System.Collections.ArrayList]$MyAlJtIoFiles = $ArrayList
    [String]$MyLabel = $Label

    Write-JtLog -Where $MyFunctionName -Text "MyLabel: $MyLabel"

    [JtTblTable]$MyJtTblTable = New-JtTblTable -Label "FileTable"
    foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File

        [JtTblRow]$MyJtTblRow = $Null    
        
        $MyJtTblRow = Convert-JtIoFile_To_JtTblRow_Normal -FilePath $MyJtIoFile
        $MyJtTblTable.AddRow($MyJtTblRow)
    }
    return $MyJtTblTable
}

Function Convert-JtIoFolder_to_DataTable2 {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFunctionName = "Convert-JtIoFolder_to_DataTable2"

    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPathInput
    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
    [JtTemplateFile]$MyJtTemplateFile = $This.JtTemplateFile
    [String]$MyFilenameTemplate = $MyJtTemplateFile.GetName()
    Write-JtLog -Where $MyFunctionName -Text "MyFilenameTemplate: $MyFilenameTemplate" 
    [System.Collections.ArrayList]$MyAlColRens = $MyJtTemplateFile.GetJtColRens()

    [JtColRen]$MyJtColRen = New-JtColRenFileName
    $MyAlColRens.Add($MyJtColRen)
    
    [JtColRen]$MyJtColRen = New-JtColRenFilePath
    $MyAlColRens.Add($MyJtColRen)

    $MyAlFilenameParts = $MyFilenameTemplate.Split(".")
    [System.Data.Datatable]$MyDataTable = New-Object System.Data.Datatable
    
    foreach ($ColRen in $MyAlColRens) {
        [JtColRen]$MyJtColRen = $ColRen
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyDataTable.Columns.Add($MyLabel, "String")
    }

    foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File
        [String]$MyFilename = $MyJtIoFile.GetName()
        # Write-JtLog -Where $This.ClassName -Text "____FileName: $FileName"

        $MyAlFilenameParts = $MyFilename.Split(".")
        $MyRow = $MyDataTable.NewRow()
        for ([Int32]$j = 0; $j -lt $MyAlFilenameParts.Count; $j++) {
            [JtColRen]$MyJtColRen = $MyAlColRens[$j]
            if ($Null -eq $MyJtColRen) {
                Throw "MyColRen is NULL for $j with MyFilename: $MyFilename"
            }
            else {
                [String]$MyHeader = $MyJtColRen.GetHeader()
                [String]$MyLabel = $MyJtColRen.GetLabel()
                
                [String]$MyValue = $MyAlColRens[$j].GetOutput($MyAlFilenameParts[$j])
                $MyRow.($MyLabel) = $MyValue
            }
        }

        [JtColRen]$MyJtColRen = New-JtColRenFileName
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyLabel = $MyJtColRen.GetLabel()
        [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
        $MyRow.($MyLabel) = $MyValue

        [JtColRen]$MyJtColRen = New-JtColRenFilePath
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyLabel = $MyJtColRen.GetLabel()
        [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
        $MyRow.($MyLabel) = $MyValue

        $MyDataTable.Rows.Add($MyRow)
    }
    return $MyDataTable
}


































Function Convert-JtDataTable_To_FileCsv {

    Param (
        [Parameter(Mandatory = $True)][System.Object[]]$DataTable,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput, 
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$FilenameOutput,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFunctionName = "Convert-JtDataTable_To_FileCsv"
    [String]$MyExtension = [JtIo]::FileExtension_Csv
    [String]$MyFilenameOutput = -join ($MyFunctionName, $MyExtension)
    if ($FilenameOutput) {
        $MyFilenameOutput = $FilenameOutput
    }
    if ($Label) {
        $MyFilenameOutput = -join ($Label, $MyExtension)
    }
    
    $MyDataTable = $DataTable
    [String]$MyFolderPath_Output = $FolderPathOutput
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath_Output

    Write-JtLog -Where $MyFunctionName -Text "Starting ... MyFilenameOutput: $MyFilenameOutput"

    [String]$MyFilePathCsv = $MyJtIoFolder.GetFilePath($MyFilenameOutput)

    if ($MyDataTable.count -gt 0) {
        Write-JtIoFile -Where $MyFunctionName -Text "WARNING. Creating file with EXTENSION: $MyExtension" -FilePath $MyFilePathCsv
    
        $MyData = $MyDataTable[0].Table
        $MyData | Export-Csv -Path $MyFilePathCsv -NoTypeInformation -Delimiter ([JtClass]::Delimiter)
    }
    else {
        Write-JtError -Where $MyFunctionName -Text "No rows. At path MyFilePathCsv: $MyFilePathCsv"
    }
}

Function Convert-JtTblTable_To_FileCsv {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtTblTable]$JtTblTable,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )
    [String]$MyFunctionName = "Convert-JtTblTable_To_FileCsv"

    [String]$MyLabel = $Label
    [JtTblTable]$MyJtTblTable = $JtTblTable
    [String]$MyFolderPath_Output = $FolderPathOutput
    #
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath_Output
        
    Write-JtLog -Where $MyFunctionName -Text "Label: $MyLabel"
    $MyDatatable = Convert-JtTblTable_To_Datatable -JtTblTable $MyJtTblTable

    if ($Null -eq $MyDatatable) {
        Write-JtError -Where $MyFunctionName -Text "Datatable is NULL. LABEL: $MyLabel"
    }
    else {
        [String]$MyFolderPath_Output = $MyJtIoFolder.GetPath()
        Convert-JtDataTable_To_FileCsv -Datatable $MyDatatable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel
    }
}



Function Convert-JtTblTable_To_Datatable {
    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtTblTable]$JtTblTable
    )

    [String]$MyFunctionName = "Convert-JtTblTable_To_Datatable"
    Write-JtLog -Where $MyFunctionName -Text "Start..."

    [JtTblTable]$MyJtTblTable = $JtTblTable

    [System.Data.DataTable]$MyDataTable = New-Object System.Data.DataTable
    [System.Collections.ArrayList]$MyAlObjects = $MyJtTblTable.GetObjects()

    [System.Collections.Specialized.OrderedDictionary]$MyOrdDic = $MyAlObjects[0]
    foreach ($MyKey in $MyOrdDic.keys) {
        $MyDataTable.Columns.Add($MyKey, "String")
    }
    [System.Collections.ArrayList]$MyAlObjects = $MyJtTblTable.GetObjects()

    [Int16]$MyIntObjects = $MyAlObjects.count
    Write-JtLog -Where $MyFunctionName -Text "Number of objects: $MyIntObjects"


    foreach ($Element in $MyAlObjects) {
        [System.Collections.Specialized.OrderedDictionary]$MyOrdDic = $Element

        $MyRow = $MyDataTable.NewRow()

        foreach ($MyKey in $MyOrdDic.keys) {
            $MyRow.($MyKey) = $MyOrdDic[$MyKey]
        }
        $MyDataTable.Rows.Add($MyRow)
    }
    # [System.Data.DataTable]$DataTable | Format-Table
    
    # return [System.Data.DataTable]$DataTable
    # return [System.Data.DataTable]$DataTable
    return $MyDataTable
}


Function Convert-JtIoFile_To_JtTblRow {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilePath
    )

    [JtTblRow]$MyJtTblRow = New-JtTblRow
    
    [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $FilePath
    [String]$MyFilename = $MyJtIoFile.GetName()
    Write-JtLog -Text "---------------Filename: $MyFilename"
    # $MyContent = Get-Content $MyJtIoFile.GetPath()

    # [String]$MyFolderPath = $MyContent
    # if (($MyFolderPath.length -gt 0) -and (Test-JtIoFolderPath -FolderPath $MyFolderPath)) {
    [String]$MyExtension2 = $MyJtIoFile.GetExtension()
    [String]$MyFilePath = $MyJtIoFile.GetPath()
    [JtIoFolder]$MyJtIoParentFolder = $MyJtIoFile.GetJtIoFolder_Parent()
    [String]$MyFoldernameParent = $MyJtIoParentFolder.GetName()

    [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "1"
    $MyValue = $Mypart
    $MyJtTblRow.Add("IN1", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "2"
    $MyValue = $Mypart
    $MyJtTblRow.Add("IN2", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "3"
    $MyValue = $Mypart
    $MyJtTblRow.Add("IN3", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "4"
    $MyValue = $Mypart
    $MyJtTblRow.Add("IN4", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "5"
    $MyValue = $Mypart
    $MyJtTblRow.Add("IN5", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "7"
    $MyValue = $Mypart
    $MyJtTblRow.Add("JAHR", $MyValue)

    [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "8"
    $MyValue = $Mypart
    $MyValue = $MyPart.Replace("_", ",")
    $MyJtTblRow.Add("BETRAG", $MyValue)


    $MyJtTblRow.Add("NAME", $MyFileName)
    $MyJtTblRow.Add("PARENT_NAME", $MyFoldernameParent)

    $MyJtTblRow.Add("EXTENSION", $MyExtension2)
    $MyJtTblRow.Add("PATH", $MyFilePath)
    # }
    # else {
    #     return $Null
    # }
    return $MyJtTblRow
}


Function Convert-JtIoFile_To_JtTblRow_Normal {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilePath
    )

    [String]$MyFunctionName = "Convert-JtIoFile_To_JtTblRow_Normal"
    [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $FilePath

    Write-JtLog -Where $MyFunctionName -Text "FilePath: $FilePath"

    # [JtTblRow]$MyJtTblRow = New-JtTblRow
    # [String[]]$AlParts = $TheFilenameTemplate.Split(".")

    # foreach ($Element in $AlParts) {
    #     [String]$MyPart = $Element

    #     [String]$MyValue = $MyJtTblRowAll.GetValue($MyPart)
    #     $MyJtTblRow.Add($MyPart, $MyValue)
    # }
    # return $MyJtTblRow
                
    [JtTblRow]$MyJtTblRow = New-JtTblRow
        
    [JtIoFolder]$MyJtIoFolderParent = $MyJtIoFile.GetJtIoFolder_Parent()
    [String]$MyFoldernameParent = $MyJtIoFolderParent.GetName()

    Foreach ($i in 1..5) {
        [String]$MyPart = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "$i"
        $MyJtTblRow.Add("PART$i", $MyPart)
    }
    $MyJtTblRow.Add("PARENT_NAME", $MyFoldernameParent)

    [String]$MyFilename = $MyJtIoFile.GetName()
    $MyJtTblRow.Add("NAME", $MyFileName)
        
    [String]$MyExtension2 = $MyJtIoFile.GetExtension2()
    $MyJtTblRow.Add("EXTENSION2", $MyExtension2)

    [String]$MyFilePath = $MyJtIoFile.GetPath()
    $MyJtTblRow.Add("PATH", $MyFilePath)

    Foreach ($i in 5..9) {

        [String]$MyLev = Convert-JtPath_To_Parts -Path $MyFilePath -PatternOut "$i"
        $MyJtTblRow.Add("LEV$i", $MyLev)
    }


    return $MyJtTblRow
}



Function Get-JtIoFilename_Csv_Filelist {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Foldername
    )

    [String]$MyFolderName = $Foldername
    [String]$MyFilePrefix = [JtIo]::FilePrefix_Folder
    [String]$MyFileLabel = $MyFolderName
    [String]$MyFileExtension = [JtIo]::FileExtension_Csv
    [String]$MyFilenameOutput = -join ($MyFilePrefix, ".", $MyFileLabel, ".", "files", $MyFileExtension)
    return $MyFilenameOutput
}




Function Get-JtIoFilename_Meta {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Extension2
    )
        
    [String]$MyFilePrefix = [JtIo]::FilePrefix_Folder
    [String]$MyExtension2 = $Extension2
    [String]$MyLabel = $Label
    [String]$MyLabel = Convert-JtLabel_To_Filename -Label $MyLabel
        
    [String]$MyFilename = -join ($MyFilePrefix, ".", $MyLabel, $MyExtension2)
    $MyFilename = Convert-JtLabel_To_Filename -Label $MyFilename 
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Xxx {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Part1,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Part2,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Part3,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Part4,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Part5,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Year,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Value,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Extension2
    )

    [String]$MyLabel = -join ($Part1, ".", $Part2, ".", $Part3, ".", $Part4, ".",$Part5, ".", $Year, ".", $Value)
[String]$MyExtension = $Extension2
[String]$MyFilename = Get-JtIoFilename_Meta -Label $MyLabel -Extension $MyExtension2
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Anzahl {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderName,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Anzahl
    )

    # [String]$MyFunctionName = "Get-JtIoFilename_Meta_Betrag_Miete"
    [String]$MyFolderName = $FolderName
    [String]$MyValue = $Anzahl
    
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Anzahl

    $MyParams = @{
        Part1      = Convert-JtDotter -Text $MyFolderName -PatternOut "1" 
        Part2      = Convert-JtDotter -Text $MyFolderName -PatternOut "2" 
        Part3      = Convert-JtDotter -Text $MyFolderName -PatternOut "3" 
        Part4      = Convert-JtDotter -Text $MyFolderName -PatternOut "4" 
        Part5      = Convert-JtDotter -Text $MyFolderName -PatternOut "5" 
        Value      = $MyValue
        Year       = $MyYear
        Extension2 = $MyExtension2
    }
    [String]$MyFilename = Get-JtIoFilename_Meta_Xxx @MyParams
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Betrag {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderName,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Betrag,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Year
    )

    [String]$MyYear = "JAHRE"
    if ($Year) {
        if($Year.Length -gt 0) {
            $MyYear = $Year
        }
    }
    
    [String]$MyFolderName = $FolderName
    [String]$MyValue = $Betrag
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Betrag

    $MyParams = @{
        Part1      = Convert-JtDotter -Text $MyFolderName -PatternOut "1"
        Part2      = Convert-JtDotter -Text $MyFolderName -PatternOut "2"
        Part3      = Convert-JtDotter -Text $MyFolderName -PatternOut "3"
        Part4      = Convert-JtDotter -Text $MyFolderName -PatternOut "4"
        Part5      = Convert-JtDotter -Text $MyFolderName -PatternOut "5"
        Value      = Convert-JtString_To_Betrag -Text $MyValue
        Year       = $MyYear
        Extension2 = $MyExtension2
    }
    [String]$MyFilename = Get-JtIoFilename_Meta_Xxx @MyParams
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Betrag_Voraus {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderName,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Betrag,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Year
    )

    # [String]$MyFunctionName = "Get-JtIoFilename_Meta_Betrag_Voraus"
    [String]$MyLabel = "ZNK"

    [String]$MyFolderName = $FolderName
    [String]$MyValue = $Betrag
    [String]$MyYear = $Year
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Betrag

    $MyParams = @{
        Part1      = Convert-JtDotter -Text $MyFolderName -PatternOut "1"
        Part2      = Convert-JtDotter -Text $MyFolderName -PatternOut "2"
        Part3      = Convert-JtDotter -Text $MyFolderName -PatternOut "3"
        Part4      = Convert-JtDotter -Text $MyFolderName -PatternOut "4"
        Part5      = $MyLabel
        Value      = Convert-JtString_To_Betrag -Text $MyValue
        Year       = $MyYear
        Extension2 = $MyExtension2
    }
    [String]$MyFilename = Get-JtIoFilename_Meta_Xxx @MyParams
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Betrag_Miete {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderName,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Betrag,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Year
    )

    # [String]$MyFunctionName = "Get-JtIoFilename_Meta_Betrag_Miete"
    [String]$MyLabel = "ZMI"

    [String]$MyFolderName = $FolderName
    [String]$MyValue = $Betrag
    [String]$MyYear = $Year
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Betrag

    $MyParams = @{
        Part1      = Convert-JtDotter -Text $MyFolderName -PatternOut "1"
        Part2      = Convert-JtDotter -Text $MyFolderName -PatternOut "2"
        Part3      = Convert-JtDotter -Text $MyFolderName -PatternOut "3"
        Part4      = Convert-JtDotter -Text $MyFolderName -PatternOut "4"
        Part5      = $MyLabel
        Value      = Convert-JtString_To_Betrag -Text $MyValue
        Year       = $MyYear
        Extension2 = $MyExtension2
    }
    [String]$MyFilename = Get-JtIoFilename_Meta_Xxx @MyParams
    return $MyFilename
}

Function Get-JtIoFilename_Meta_Betrag_Zahlung {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderName,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Betrag,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Year
    )

    # [String]$MyFunctionName = "Get-JtIoFilename_Meta_Betrag_Zahlung"
    [String]$MyLabel = "ZAH"

    [String]$MyFolderName = $FolderName
    [String]$MyValue = $Betrag
    [String]$MyYear = $Year
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Betrag

    $MyParams = @{
        Part1      = Convert-JtDotter -Text $MyFolderName -PatternOut "1"
        Part2      = Convert-JtDotter -Text $MyFolderName -PatternOut "2"
        Part3      = Convert-JtDotter -Text $MyFolderName -PatternOut "3"
        Part4      = Convert-JtDotter -Text $MyFolderName -PatternOut "4"
        Part5      = $MyLabel
        Value      = Convert-JtString_To_Betrag -Text $MyValue
        Year       = $MyYear
        Extension2 = $MyExtension2
    }
    [String]$MyFilename = Get-JtIoFilename_Meta_Xxx @MyParams
    return $MyFilename
}



Function Get-JtIoFilename_Meta_Time {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFilePrefix = [JtIo]::FilePrefix_Report
    [String]$MyLabel = $Label
    [String]$MyExtension2 = [JtIo]::FileExtension_Meta_Time

    [String]$MyFilenameOutput = -join ($MyFilePrefix, ".", $MyLabel, $MyExtension2)
    return $MyFilenameOutput
}

Function Convert-JtIoFolder_To_FileCsv {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Filter,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFunctionName = "Convert-JtIoFolder_To_FileCsv"
    [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $FolderPathInput
    [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $FolderPathOutput -Force

    [String]$MyFolderPath_Input = $MyJtIoFolder_Input.GetPath()
    [String]$MyFolderPath_Output = $MyJtIoFolder_Output.GetPath()
    [String]$MyLabel = $Label
    [String]$MyFilter = $Filter

    Write-JtLog -Where $MyFunctionName -Text "Creating CSV filelist for MyFolderPath_Input: $MyFolderPath_Input"
    
    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyFolderPath_Input -Filter $MyFilter -Recurse

    [Int16]$MyIntNumberOfFiles = $MyAlJtIoFiles.count
    
    if (! ($MyIntNumberOfFiles -gt 0 )) {
        Write-JtLog -Where $MyFunctionName -Text "No files found. Noting to do. MyFolderPath_Input: $MyFolderPath_Input"
        return
    }

    Convert-JtAlJtIoFiles_to_FileCsv -ArrayList $MyAlJtIoFiles -FolderPathOutput $MyFolderPath_Output -Label $MyLabel 
}

class JtReps {

    static [System.Collections.ArrayList]GetJtReps() {
        [System.Collections.ArrayList]$MyJtReps = [System.Collections.ArrayList]::new()

        [JtRep]$MyJtRep = New-JtRep_Folder
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32Bios
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32Computersystem
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32LogicalDisk
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32NetworkAdapter
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32OperatingSystem
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32Processor
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Obj_Win32VideoController
        $MyJtReps.Add($MyJtRep)
        # [JtRep]$MyJtRep = New-JtRep_InstalledSoftware
        # $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Bitlocker
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Hardware
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_HardwareSn
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Net
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Software
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareAdobe
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareMicrosoft
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareMicrosoftNormal
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareOpsi
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareSecurity
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareSupport
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_SoftwareVray
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Timestamps
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_G13
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_Iat
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_Lab
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_Pools
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_Server
        $MyJtReps.Add($MyJtRep)
        [JtRep]$MyJtRep = New-JtRep_Z_Vorwag
        $MyJtReps.Add($MyJtRep)
        return $MyJtReps
    }
}


Function New-JtCsvGenerator {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyFunctionName = "New-JtCsvGenerator"
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPath
    
    [String]$MyLabel = "NO LABEL"
    if ($Label) {
        $MyLabel = $Label
    }

    Write-JtLog -Where $MyFunctionName -Text "Starting ... LABEL: $MyLabel - MyJtIoFolder: $MyJtIoFolder"
        
    [JtInfi]$MyJtInfi = New-JtInfi -FolderPath $MyJtIoFolder
        
    [System.Collections.ArrayList]$MyAlJtReps = [JtReps]::GetJtReps()
    foreach ($JtRep in $MyAlJtReps) {
        [JtRep]$MyJtRep = $JtRep
        [String]$MyLabelRep = $MyJtRep.GetLabel()
        Write-JtLog -Where $MyFunctionName -Text "MyLabel: $MyLabel - MyLabelRep: $MyLabelRep - MyJtIoFolder: $MyJtIoFolder"

        [Boolean]$MyBlnUseLine = $True
        if ($True -eq $MyJtRep.BlnHideSpezial ) {
            if ($MyJtInfi.GetIsNormalBoot()) {
                $MyBlnUseLine = $True
            }
            else {
                $MyBlnUseLine = $False
            }
        }
        else {
            $MyBlnUseLine = $True
        }
            
        # test it
        [Boolean]$MyBlnUseLine = $True
        # test it
            
        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label $MyLabelRep
        if ($True -eq $MyBlnUseLine) {
            [JtTblRow]$MyJtTblRow = $Null
            try {
                $MyJtTblRow = $MyJtRep.GetJtTblRow($MyJtInfi)
            }
            catch {
                Write-JtError -Where $MyFunctionName -Text "Problem while getting row... MyLabelRep: $MyLabelRep"
            }
            try {
                $MyJtTblTable.AddRow($MyJtTblRow) | Out-Null
            }
            catch {
                Write-JtError -Where $MyFunctionName -Text "Problem while adding row..."
            }
        }

        [String]$MyLabel_Table = $MyJtTblTable.GetLabel()
        [JtIoFolder]$MyJtIoFolder_Csv = $MyJtIoFolder.GetJtIoFolder_Sub("csv", $True)
        [String]$MyFolderPath_Output = $MyJtIoFolder_Csv.GetPath()
        Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel_Table 
    }
    return $MyFolderPath_Output
}


Class JtCsvFolderSummary : JtClass {
    
    [String]$Label = $Null
    [String]$Sub = $Null
    [String]$Expected = $Null
    [JtIoFolder]$JtIoFolder_Base = $Null

    JtCsvFolderSummary ([String]$TheLabel, [String]$TheFolderPath, [String]$TheSub, [String]$TheExpected) : Base() {
        $This.ClassName = "JtCsvFolderSummary"
        $This.Label = $TheLabel
        [JtIoFolder]$MyJtIoFolder_Base = New-JtIoFolder -FolderPath $TheFolderPath
        $This.JtIoFolder_Base = $MyJtIoFolder_Base
        $This.Sub = $TheSub
        $This.Expected = $TheExpected
    }
}

Function New-JtCsvFolderSummary {
    
    Param (
        [String]$Label,
        [String]$FolderPath,
        [String]$Sub,
        [String]$Expected
    )
        
    [JtCsvFolderSummary]::new($Label, $FolderPath, $Sub, $Expected)
}
    
Class JtCsvFolderSummaryAll : JtCsvFolderSummary {
        
    JtCsvFolderSummaryAll([String]$TheLabel, [String]$TheFolderPath, [String]$TheSub, [String]$TheExpected) : base($TheLabel, $TheFolderPath, $TheSub, $TheExpected) {
        $This.ClassName = "JtCsvFolderSummaryAll"
            
        [String]$MyLabel = $TheLabel
        [String]$MySub = $TheSub
        
        Write-JtLog -Where $This.ClassName -Text "Label: $MyLabel - Sub: $MySub"
        
        [JtIoFolder]$MyJtIoFolder_Base = $This.JtIoFolder_Base
        [JtIoFolder]$MyJtIoFolder_Work = $MyJtIoFolder_Base.GetJtIoFolder_Sub($MySub)
        
        if (!($MyJtIoFolder_Base.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "The folder is not existing. MySub: $MySub in MyJtIoFolder_Base: $MyJtIoFolder_Base"
        }
        else {
            [JtTblTable]$MyJtTblTable = $This.GetTable($MyJtIoFolder_Work)
            [String]$MyFolderPath_Output = $MyJtIoFolder_Base.GetPath()
            Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel 
        }
    }
    
    [JtTblTable]GetTable([JtIoFolder]$TheJtIoFolder) {
        [JtIoFolder]$MyJtIoFolder = $TheJtIoFolder
        [System.Collections.ArrayList]$MyAlExtensions_All = $MyJtIoFolder.GetAlExtensions_Recurse()

        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label $This.ClassName
        [String]$MyExpected = $This.Expected
        [Array]$MyAlExtensions_Expected = $MyExpected.Split(",")
                
        [System.Collections.ArrayList]$MyAlJtIoSubfolders = $MyJtIoFolder.GetAlJtIoFolders_Sub()
        foreach ($SubFolder in $MyAlJtIoSubfolders) {
            [JtTblRow]$MyJtTblRow = New-JtTblRow
            [JtIoFolder]$MyJtIoFolder = $SubFolder
            $MyIntFileCountExpected = 0 
            $MyIntFileCountAll = 0 
            
            $MyJtTblRow.Add("Name", $MyJtIoFolder.GetName())
            # $MyJtTblRow.Add("Label", $MyLabel)
            
            foreach ($Extension in $MyAlExtensions_Expected) {
                [String]$MyExtension = $Extension

                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count
                
                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyExtension -Prefix "X"  
                $MyColumnValue = $MyIntCountForType
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

                $MyIntFileCountExpected = $MyIntFileCountExpected + $MyIntCountForType
            }

            $MyColumnName = "CountExpected"
            $MyColumnValue = $MyIntFileCountExpected
            $MyJtTblRow.Add($MyColumnName, $MyIntFileCountExpected)

            foreach ($Extension in $MyAlExtensions_All) {
                [String]$MyExtension = $Extension
                [String]$MyLabelExtension = $MyExtension.Replace([JtIo]::FileExtension_Meta, "")
                
                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count


                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyLabelExtension -Prefix "Z" 
                $MyColumnValue = $MyIntCountForType
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
                    
                $MyIntFileCountAll = $MyIntFileCountAll + $MyIntCountForType
            }
                
            $MyColumnName = "CountAll"
            $MyColumnValue = $MyIntFileCountAll   
            $MyJtTblRow.Add($MyColumnName, $MyIntFileCountAll)
                
            [Boolean]$MySameNumber = $False
            if (($MyIntFileCountExpected - $MyAlExtensions_Expected.Length) -eq 0) {
                $MySameNumber = $True
            }
            [String]$MyIsExpected = "" 
            if ($MySameNumber) {
                $MyIsExpected = "OK"
            }
            else {
                $MyIsExpected = ""
            }
                
            $MyColumnName = "Expected"
            $MyColumnValue = $MyIsExpected
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
            $MyJtTblTable.AddRow($MyJtTblRow)
        }
        return $MyJtTblTable
    }
}

Function New-JtCsvFolderSummaryAll {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Sub,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Expected
    )

    [JtCsvFolderSummaryAll]::new($Label, $FolderPath, $Sub, $Expected)

}

Class JtCsvFolderSummaryMeta : JtCsvFolderSummary {
    
    JtCsvFolderSummaryMeta([String]$TheLabel, [String]$TheFolderPath, [String]$TheSub, [String]$TheExpected) : base($TheLabel, $TheFolderPath, $TheSub, $TheExpected) {
        $This.ClassName = "JtCsvFolderSummaryMeta"

        [String]$MyLabel = $TheLabel
        [String]$MySub = $TheSub

        Write-JtLog -Where $This.ClassName -Text "Label: $MyLabel - Sub: $MySub"

        [JtIoFolder]$MyJtIoFolder_Base = $This.JtIoFolder_Base
        [JtIoFolder]$MyJtIoFolder_Work = $MyJtIoFolder_Base.GetJtIoFolder_Sub($MySub)

        if (!($MyJtIoFolder_Base.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "The folder is not existing. MySub: $MySub in MyJtIoFolder_Base: $MyJtIoFolder_Base"
        }
        else {
            [JtTblTable]$MyJtTblTable = $This.GetTable($MyJtIoFolder_Work)
            [String]$MyFolderPath_Output = $MyJtIoFolder_Base.GetPath()
            Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel
        }
    }

    [JtTblTable]GetTable([JtIoFolder]$TheJtIoFolder) {
        [JtIoFolder]$MyJtIoFolder = $TheJtIoFolder
            
        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label $This.ClassName
        [String]$MyExpected = $This.Expected
        [Array]$MyAlExtensions_Expected = $MyExpected.Split(",")

        [System.Collections.ArrayList]$MyAlJtIoSubfolders = $MyJtIoFolder.GetAlJtIoFolders_Sub()
        foreach ($SubFolder in $MyAlJtIoSubfolders) {
            [JtTblRow]$MyJtTblRow = New-JtTblRow
            [JtIoFolder]$MyJtIoFolder = $SubFolder
            [Int16]$MyIntFileCountExpected = 0 

            [String]$MyFolderName = $MyJtIoFolder.GetName()
            $MyJtTblRow.Add("NAME", $MyFolderName)
            # $MyJtTblRow.Add("Label", $MyLabel)

            foreach ($MyType in $MyAlExtensions_Expected) {
                [String]$MyExtension = [String]$MyType

                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count
                
                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyExtension -Prefix "X"
                $MyColumnValue = $MyIntCountForType
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

                $MyIntFileCountExpected = $MyIntFileCountExpected + $MyIntCountForType
            }
            [int16]$MyIntExpected = $MyAlExtensions_Expected.Count

            # Is the result ok? ("OK", "")
            [String]$MyNumberOk = "0"
            if ($MyIntFileCountExpected -ge $MyIntExpected) {
                $MyNumberOk = "1"
            }
            
            $MyColumnName = "OK"
            $MyColumnValue = $MyNumberOk
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Is the result ok? ("OK", "")
            [String]$MyTextOk = "Nein"
            if ($MyIntFileCountExpected -ge $MyIntExpected) {
                $MyTextOk = "Ja"
            }

            $MyColumnName = "Best"
            $MyColumnValue = $MyTextOk
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            $MyColumnName = "Gef_SOLL"
            $MyColumnValue = $MyAlExtensions_Expected.Count
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # How many files were expected? (1)
            $MyColumnName = "Gef_IST"
            $MyColumnValue = $MyIntFileCountExpected
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
            
            # Which filetypes had to be delivered? (".pdf,.txt")
            $MyColumnName = "Typen_SOLL"
            $MyColumnValue = $MyExpected
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Which filetypes were delivered? (.pdf,.txt)
            [System.Collections.ArrayList]$MyAlTypes = $MyJtIoFolder.GetAlExtensions()
            $MyColumnName = "Typen_IST"
            $MyColumnValue = $MyAlTypes -join ","
            # $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Generate columes for each expected type (X_pdf,X_jpg)
            foreach ($Extension in $MyAlExtensions_Expected) {
                [String]$MyExtension = $Extension
                [String]$MyLabelExtension = $MyExtension.Replace([JtIo]::FileExtension_Meta, "")

                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count
                
                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyLabelExtension -Prefix "X" 
                $MyColumnValue = $MyIntCountForType
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyLabelExtension -Prefix "X2" 
                $MyColumnValue = "-"
                [JtIoFile]$MyFile = $null
                if ($MyAlJtIoFiles.Count -gt 0) {
                    [JtIoFile]$MyFile = $MyAlJtIoFiles[0]
                    $MyColumnValue = $MyFile.GetName()
                    $MyColumnValue = $MyColumnValue.Replace($MyExtension, "")
                }
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
            }
            $MyJtTblTable.AddRow($MyJtTblRow)
        }
        return $MyJtTblTable 
    }
}


Function New-JtCsvFolderSummaryMeta {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Sub
    )

    [JtCsvFolderSummaryMeta]::new($Label, $FolderPath, $Sub, ".user.meta,.room.meta")

}

Class JtCsvFolderSummaryExpected : JtCsvFolderSummary {
    
    JtCsvFolderSummaryExpected([String]$TheLabel, [String]$TheFolderPath, [String]$TheSub, [String]$TheExpected) : base($TheLabel, $TheFolderPath, $TheSub, $TheExpected) {
        $This.ClassName = "JtCsvFolderSummaryExpected"

        [String]$MyLabel = $TheLabel
        [String]$MySub = $TheSub

        Write-JtLog -Where $This.ClassName -Text "Label: $MyLabel - Sub: $MySub"
        
        [JtIoFolder]$MyJtIoFolder_Base = $This.JtIoFolder_Base
        [JtIoFolder]$MyJtIoFolder_Work = $MyJtIoFolder_Base.GetJtIoFolder_Sub($MySub)

        if (!($MyJtIoFolder_Base.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "The folder is not existing. MySub: $MySub in MyJtIoFolder_Base: $MyJtIoFolder_Base"
        }
        else {
            [JtTblTable]$MyJtTblTable = $This.GetTable($MyJtIoFolder_Work)
            [String]$MyFolderPath_Output = $MyJtIoFolder_Base.GetPath()
            Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel 
        }
    }


    [JtTblTable]GetTable([JtIoFolder]$TheJtIoFolder) {
        [JtIoFolder]$MyJtIoFolder = $TheJtIoFolder

    
        $MyJtTblTable = New-JtTblTable -Label $This.ClassName

        
        [System.Collections.ArrayList]$MyAlJtIoSubfolders = $MyJtIoFolder.GetAlJtIoFolders_Sub()
        foreach ($SubFolder in $MyAlJtIoSubfolders) {
            [JtTblRow]$MyJtTblRow = New-JtTblRow
            [JtIoFolder]$MyJtIoFolder = $SubFolder
            [Int16]$MyIntFileCountExpected = 0 

            [String]$MyFoldername = $MyJtIoFolder.GetName()
            $MyJtTblRow.Add("Name", $MyFoldername)
            $MyJtTblRow.Add("Label", $This.Label)

            [Array]$MyAlExtensions_Expected = $This.Expected.Split(",")

            foreach ($Extension in $MyAlExtensions_Expected) {
                [String]$MyExtension = $Extension
                [String]$MyLabelType = $MyExtension

                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count
                
                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyExtension -Prefix "X" 
                $MyColumnValue = $MyIntCountForType
                #$MyJtTblRow.Add($MyColumnName, $MyColumnValue)

                $MyIntFileCountExpected = $MyIntFileCountExpected + $MyIntCountForType
            }

            [int16]$MyIntExpected = $MyAlExtensions_Expected.Count
            

            # Is the result ok? ("OK", "")
            [String]$MyNumberOk = "0"
            if ($MyIntFileCountExpected -ge $MyIntExpected) {
                $MyNumberOk = "1"
            }
            
            $MyColumnName = "OK"
            $MyColumnValue = $MyNumberOk
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Is the result ok? ("OK", "")
            [String]$MyTextOk = "Nein"
            if ($MyIntFileCountExpected -ge $MyIntExpected) {
                $MyTextOk = "Ja"
            }

            $MyColumnName = "Best"
            $MyColumnValue = $MyTextOk
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            $MyColumnName = "Gef_SOLL"
            $MyColumnValue = $MyAlExtensions_Expected.Count
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # How many files were expected? (1)
            $MyColumnName = "Gef_IST"
            $MyColumnValue = $MyIntFileCountExpected
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
            
            # Which filetypes had to be delivered? (".pdf,.txt")
            $MyColumnName = "Typen_SOLL"
            $MyColumnValue = $This.Expected
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Which filetypes were delivered? (.pdf,.txt)
            [System.Collections.ArrayList]$MyAlTypes = $MyJtIoFolder.GetAlExtensions()
            $MyColumnName = "Typen_IST"
            $MyColumnValue = $MyAlTypes -join ","
            $MyJtTblRow.Add($MyColumnName, $MyColumnValue)

            # Generate columes for each expected type (X_pdf,X_jpg)
            foreach ($MyType in $MyAlExtensions_Expected) {
                [String]$MyExtension = [String]$MyType
                [String]$MyLabelType = $MyExtension

                [String]$MyFilter = -join ("*", $MyExtension)
                [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter 
                [Int16]$MyIntCountForType = $MyAlJtIoFiles.Count
                
                $MyColumnName = Convert-JtString_To_ColHeader -Text $MyExtension -Prefix "X" 
                $MyColumnValue = $MyIntCountForType
                
                $MyJtTblRow.Add($MyColumnName, $MyColumnValue)
            }
            $MyJtTblTable.AddRow($MyJtTblRow)
        }
        Return $MyJtTblTable

    }
}

Function New-JtCsvFolderSummaryExpected {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Sub,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Expected
    )

    [JtCsvFolderSummaryExpected]::new($Label, $FolderPath, $Sub, $Expected)
}




Function Test-JtIoFolder_Report {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

    if (!($MyJtIoFolder.IsExisting())) {
        return $False
    }
    return $True
}



Export-ModuleMember -Function Convert-JtIoFile_To_JtTblRow
Export-ModuleMember -Function Convert-JtIoFile_To_JtTblRow_Normal
Export-ModuleMember -Function Convert-JtIoFolder_To_FileCsv

Export-ModuleMember -Function Convert-JtAl_to_FileCsv
Export-ModuleMember -Function Convert-JtAlJtIoFiles_to_FileCsv
Export-ModuleMember -Function Convert-JtAlJtIoFiles_to_JtTblTable
Export-ModuleMember -Function Convert-JtDataTable_To_FileCsv

Export-ModuleMember -Function Convert-JtTblTable_To_Datatable
Export-ModuleMember -Function Convert-JtTblTable_To_FileCsv

Export-ModuleMember -Function Get-JtIoFilename_Csv_Filelist
Export-ModuleMember -Function Get-JtIoFilename_Meta
Export-ModuleMember -Function Get-JtIoFilename_Meta_Anzahl
Export-ModuleMember -Function Get-JtIoFilename_Meta_Betrag
Export-ModuleMember -Function Get-JtIoFilename_Meta_Betrag_Voraus
Export-ModuleMember -Function Get-JtIoFilename_Meta_Betrag_Miete
Export-ModuleMember -Function Get-JtIoFilename_Meta_Betrag_Zahlung
Export-ModuleMember -Function Get-JtIoFilename_Meta_Time

Export-ModuleMember -Function New-JtCsvFolderSummary
Export-ModuleMember -Function New-JtCsvFolderSummaryExpected
Export-ModuleMember -Function New-JtCsvFolderSummaryMeta 
Export-ModuleMember -Function New-JtCsvFolderSummaryAll
Export-ModuleMember -Function New-JtCsvGenerator

Export-ModuleMember -Function Test-JtIoFolder_Report