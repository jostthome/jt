using module Jt  
using module JtTbl


class JtInf : JtClass{

    [JtFld]$Id
    [String]$JtInf_Name

    JtInf() {
        $This.ClassName = "Inf"
        $This.Id = New-JtFld -Label "Id"
        $This.JtInf_Name = $This.GetType()
    }

    SetId([String]$MyId) {
        $This.Id.SetValue($MyId)
    }

    [String]GetKey() {
        [String]$Key = -Join ($This.Id.getValue(), ".", $This.Id)
        return $Key
    }

    [String]GetName() {
        return $This.JtInf_Name
    }

    [Object[]]GetProperties() {
        [Object[]]$Prop = Get-Member -InputObject $This -MemberType Property -force
        return $Prop 
    }

    [Boolean]SetObjValue([System.Object]$TheObj, [String]$TheFieldName, [String]$TheProp) {
        [System.Object]$MyObj = $TheObj
        [String]$MyFieldName = $TheFieldName
        [String]$MyProp = $TheProp

        if ($Null -ne $MyObj) {
                $This.($MyFieldName).SetValue($MyObj.($MyProp))
        }
        else {
            Write-JtError -Where $This.ClassName -Text "Obj is NULL, MyFieldName: $MyFieldName"
        }
        return $True
    }
}

Function New-JtInf {
    [JtInf]::new()
}




Export-ModuleMember -Function New-JtInf




