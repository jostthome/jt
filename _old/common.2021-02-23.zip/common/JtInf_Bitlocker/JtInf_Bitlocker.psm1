using module JtInf
using module JtIo
using module JtTbl


class JtInf_Bitlocker : JtInf {
    
    [JtFld]$C_CapacityGB
    [JtFld]$C_VolumeType
    [JtFld]$C_EncryptionMethod
    [JtFld]$C_ProtectionStatus
    [JtFld]$D_CapacityGB
    [JtFld]$D_VolumeType
    [JtFld]$D_EncryptionMethod
    [JtFld]$D_ProtectionStatus



    JtInf_Bitlocker () {
        $This.C_CapacityGB = New-JtFld -Label "C_CapacityGB"
        $This.C_VolumeType = New-JtFld -Label "C_VolumeType"
        $This.C_EncryptionMethod = New-JtFld -Label "C_EncryptionMethod"
        $This.C_ProtectionStatus = New-JtFld -Label "C_ProtectionStatus"
        $This.D_CapacityGB = New-JtFld -Label "D_CapacityGB"
        $This.D_VolumeType = New-JtFld -Label "D_VolumeType"
        $This.D_EncryptionMethod = New-JtFld -Label "D_EncryptionMethod"
        $This.D_ProtectionStatus = New-JtFld -Label "D_ProtectionStatus"
    }

    [JtFld]Get_C_CapacityGB() {
        return $This.C_CapacityGB
    } 

    [JtFld]Get_C_VolumeType() {
        return $This.C_VolumeType
    } 

    [JtFld]Get_C_EncryptionMethod() {
        return $This.C_EncryptionMethod
    } 

    [JtFld]Get_C_ProtectionStatus() {
        return $This.C_ProtectionStatus
    } 

    [JtFld]Get_D_CapacityGB() {
        return $This.D_CapacityGB
    } 

    [JtFld]Get_D_VolumeType() {
        return $This.D_VolumeType

    } 
    [JtFld]Get_D_EncryptionMethod() {
        return $This.D_EncryptionMethod
    } 

    [JtFld]Get_D_ProtectionStatus() {
        return $This.D_ProtectionStatus
    }
}


Function New-JtInf_Bitlocker {

    [JtInf_Bitlocker]::new()
}

Function Get-JtInf_Bitlocker {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Bitlocker]$MyJtInf = New-JtInf_Bitlocker
    
    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [String]$MyName = "Bitlocker"

    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if($MyObj) {
    foreach ($Element in $MyObj) {
        $MyElement = $Element
        [String]$MyDriveLetter = $MyElement.MountPoint.Replace(":", "")
        [String]$MyCapacityGB = $MyElement.CapacityGB
        [String]$MyVolumeType = $MyElement.VolumeType
        [String]$MyEncryptionMethod = $MyElement.EncryptionMethod
        [String]$MyProtectionStatus = $MyElement.ProtectionStatus 
        if ($MyDriveLetter -eq "C") {
            $MyJtInf.C_CapacityGB.SetValue($MyCapacityGB)
            $MyJtInf.C_VolumeType.SetValue($MyVolumeType)
            $MyJtInf.C_EncryptionMethod.SetValue($MyEncryptionMethod)
            $MyJtInf.C_ProtectionStatus.SetValue($MyProtectionStatus)
        }
        elseif ($DriveLetter -eq "D") {
            $MyJtInf.D_CapacityGB.SetValue($MyCapacityGB)
            $MyJtInf.D_VolumeType.SetValue($MyVolumeType)
            $MyJtInf.D_EncryptionMethod.SetValue($MyEncryptionMethod)
            $MyJtInf.D_ProtectionStatus.SetValue($MyProtectionStatus)
        }
    }
    }
    return [JtInf_Bitlocker]$MyJtInf 
}


Export-ModuleMember -Function New-JtInf_Bitlocker
Export-ModuleMember -Function Get-JtInf_Bitlocker
