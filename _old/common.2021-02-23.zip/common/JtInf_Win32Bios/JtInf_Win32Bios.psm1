using module JtInf
using module JtIo
using module JtTbl

class JtInf_Win32Bios : JtInf {

    [String]$Label_Hersteller = "Hersteller"

    [JtFld]$Hersteller
    [JtFld]$Sn
    [JtFld]$BIOSVersion

    JtInf_Win32Bios() {
        $This.Hersteller = New-JtFld "Hersteller"
        $This.Sn = New-JtFld "Sn"
        $This.BIOSVersion = New-JtFld "BIOSVersion"
    }
}
Function New-JtInf_Win32Bios {

    [JtInf_Win32Bios]::new()
}

Function Get-JtInf_Win32Bios {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Win32Bios]$MyJtInf = New-JtInf_Win32Bios

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [String]$MyName = "Win32_Bios"
    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if ($MyObj) {
        $MyJtInf.Hersteller.SetValue($MyObj.Manufacturer)
        $MyJtInf.Sn.SetValue($MyObj.SerialNumber)
        $MyJtInf.BIOSVersion.SetValue($MyObj.SMBIOSBIOSVersion)
    }
        
    return $MyJtInf
}

Export-ModuleMember -Function Get-JtInf_Win32Bios
Export-ModuleMember -Function New-JtInf_Win32Bios
