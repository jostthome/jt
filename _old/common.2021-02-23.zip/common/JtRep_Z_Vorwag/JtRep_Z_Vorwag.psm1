using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Vorwag : JtRep {

    JtRep_Z_Vorwag () : Base("z.vorwag") {
        $This.ClassName = "JtRep_Z_Vorwag"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellCommand)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().ArchiCAD)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().LibreOffice)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Firefox64)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Thunderbird32)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Thunderbird64)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Flash)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().WibuKey)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AcrobatReader)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())

        return $MyJtTblRow
    }
}


Function New-JtRep_Z_Vorwag {

    [JtRep_Z_Vorwag]::new() 

}

