using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32Processor : JtRep {

    JtRep_Obj_Win32Processor() : Base("obj.win32_processor") {
        $This.ClassName = "JtRep_Obj_Win32Processor"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Cpu) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Ghz) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Cores) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().CoresH) | Out-Null

        return $MyJtTblRow
    }
}
Function New-JtRep_Obj_Win32Processor {

    [JtRep_Obj_Win32Processor]::new() 

}


