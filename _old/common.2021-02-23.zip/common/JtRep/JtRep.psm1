using module Jt  
using module JtIo
using module JtTbl
using module JtInfi


class JtRep : JtClass {

    hidden [JtTimeStop]$Uhr
    hidden [String]$Label
    hidden [Boolean]$BlnHideSpezial = $False

    JtRep([String]$Label) {
        $This.ClassName = $Label
        $This.Label = $Label
        
        $This.BlnHideSpezial = $True
        $This.Uhr = [JtTimeStop]::new()
    }

    
    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        Throw "This should not happen! Should be 'GetJtTblRow' overwritten!!!!"
        return $Null
    }

    [JtTblRow]GetJtTblRowDefault([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = New-JtTblRow
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().SystemId) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Org1) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Org2) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Type) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Computername) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().LabelC) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().DaysAgo) | Out-Null
        #        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Alias) | Out-Null
        return $MyJtTblRow
    }

    [String]GetFilename_Csv() {
        [String]$MyResult = -join ($This.Label, ".csv")
        Return $MyResult
    }

    [String]GetLabel() {
        return $This.Label
    }

}

