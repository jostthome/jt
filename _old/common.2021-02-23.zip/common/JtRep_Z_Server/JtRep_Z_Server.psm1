using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Server : JtRep {

    JtRep_Z_Server() : Base("z.server") {
        $This.ClassName = "JtRep_Z_Server"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seadrive)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seafile)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().ServerViewAgents)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Bacula)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Java)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AntiVirus)

        return $MyJtTblRow
    }
}

Function new-JtRep_Z_Server {

    [JtRep_Z_Server]::new() 

}



