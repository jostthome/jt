using module JtInfi
using module JtInf_Soft
using module JtRep
using module JtTbl

class JtRep_Software : JtRep {
 
    JtRep_Software () : Base("software") {
        $This.ClassName = "JtRep_Software"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        [JtInf_Soft]$MyJtInf_Soft = $MyJtInfi.GetJtInf_Soft()
        [Object[]]$MyAlFields = $MyJtInf_Soft.GetFields()

        foreach ($Field in $MyAlFields) {
            [JtFldSoft]$MyJtFldSoft = $Field

            $MyJtInf_Soft.($MyJtFldSoft.GetLabel())
            
            [String]$MyLabel = $MyJtFldSoft.GetLabel()
            [String]$MyValue = $MyJtInf_Soft.($MyLabel)

            [JtFld]$MyFld = New-JtFld -Label $MyLabel -Value $MyValue
            $MyJtTblRow.Add($MyFld)
        }
        return $MyJtTblRow
    }
}

Function New-JtRep_Software {

    [JtRep_Software]::new() 

}

Function Get-JtRep_Software_Row {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtInfi]$JtInfi
    )

    [JtInfi]$MyJtInfi = $JtInfi
    [JtRep_Software]$MyJtRep = [JtRep_Software]::new() 
    [JtTblRow]$MyJtTblRow = $MyJtRep.GetJtTblRow($MyJtInfi)
    return $MyJtTblRow
}



