using module JtTbl
using module JtInfi
using module JtRep

class JtRep_HardwareSn : JtRep {

    JtRep_HardwareSn() : Base("report.hardwaresn") {
        $This.ClassName = "JtRep_HardwareSn"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = New-JtTblRow
        
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().Sn) | Out-Null
        
        [JtTblRow]$MyJtTblRowDefault = $This.GetJtTblRowDefault($MyJtInfi)
        $MyJtTblRow.Join($MyJtTblRowDefault)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Herst) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Modell) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Ram) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Ghz) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32VideoController().Grafikkarte) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C_Capacity) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D_Capacity) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().BIOSVersion) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Mac) | Out-Null

        return $MyJtTblRow
    }

}



Function New-JtRep_HardwareSn {

    [JtRep_HardwareSn]::new() 

}

