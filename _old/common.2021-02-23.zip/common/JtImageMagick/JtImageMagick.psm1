using module Jt  
using module JtTbl
using module JtIo

class JtImageMagick : JtClass {
    
    [String]$ConvertExe = "c:\apps\tools\ImageMagick\convert.exe"
    [String]$CompositeExe = "c:\apps\tools\ImageMagick\composite.exe"
    [String]$FolderPathOutput = ""
    [String]$FilenameOutput = ""
    
    JtImageMagick([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick"

        [String]$MyFolderPath_Output = $TheFolderPathOutput
        [String]$MyFilenameOutput = $TheFilenameOutput

        if ($MyFolderPath_Output) {
            if (!(Test-JtIoFolderPath -FolderPath $MyFolderPath_Output)) {
                # Throw "Path does not exist MyFolderPathOutput: $MyFolderPath_Output"
                New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
            }
        }
        else {
            Throw "Problem with parameter: MyFolderPathOutput!"
        }
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath_Output -Force

        $This.FolderPathOutput = $MyJtIoFolder.GetPath()
        $This.FilenameOutput = $MyFilenameOutput
    }

    static [String]GetFilenameForNumber([Int16]$I) {
        [Int16]$Thousand = 1000 + $I
        [String]$ThreeDigits = -join ("", $Thousand )
        $ThreeDigits = [String]$ThreeDigits.SubString(1, 3)
        [String]$MyFilename = -join ("img", $ThreeDigits, ".jpg")
        return $MyFilename
    }

    [Void]AddParameter([String]$TheParameter, [String]$TheValue) {
        $This.Params = -join ($This.Params, " ", "-", $TheParameter, " ", $TheValue)
    }

    [Void]AddParameterSpecial([String]$TheParameter, [String]$TheValue) {
        $This.Params = -join ($This.Params, " ", $TheParameter, ":", """", $TheValue, """")
    }
    
    [Void]SetFont([String]$TheValue) {
        # "-font Arial"
        $This.AddParameter("font", $TheValue)
    }
        
    [Void]SetFill([String]$TheValue) {
        # "-fill white"
        $This.AddParameter("fill", $TheValue)
    }
        
    [Void]SetGravity([String]$TheValue) {
        # "-gravity NorthWest"
        $This.AddParameter("gravity", $TheValue)
    }
            
    [Void]SetLabel([String]$TheValue) {
        # "-fill white"
        $This.AddParameterSpecial("label", $TheValue)
    }

    [Void]SetPointsize([String]$TheValue) {
        # "-pointsize 20"
        $This.AddParameter("pointsize", $TheValue)
    }

    [Void]SetSize([Int16]$X, [Int16]$Y) {
        # -size ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y)
        $This.AddParameter("size", $MyValue)
    }
    

    [String]GetParams() {
        return $This.Params
    }

}

class JtImageMagick_Composite : JtImageMagick {
    
    [String]$Params = ""
    [String]$Output = ""
    [String]$FolderPathInput1 = ""
    [String]$FolderPathInput2 = ""
    [String]$FilenameInput1 = ""
    [String]$FilenameInput2 = ""

    JtImageMagick_Composite([String]$TheFolderPathInput1, [String]$TheFilenameInput1, [String]$TheFolderPathInput2, [String]$TheFilenameInput2, [String]$TheFolderPathOutput, [String]$TheFilenameOutput) : Base ([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick_Composite"

        $This.FolderPathInput1 = $TheFolderPathInput1
        $This.FilenameInput1 = $TheFilenameInput1
        $This.FolderPathInput2 = $TheFolderPathInput2
        $This.FilenameInput2 = $TheFilenameInput2
    }
    
    [String]DoWrite() {
        # [String]$Args1 = -Join (" -crop ", $MyX1, "x", $MyY1, "+0+0 -background white ", $FolderPathInput, " ", $FilePathTarget )
 
        [String]$MyFilePathInput1 = -join ($This.FolderPathInput1, "\", $This.FilenameInput1)
        [String]$MyFilePathInput2 = -join ($This.FolderPathInput2, "\", $This.FilenameInput2)
        [String]$MyFilePathOutput = -join ($This.FolderPathOutput, "\", $This.FilenameOutput)
        
        [String]$MyArgumentList = -join ($This.GetParams(), " ", $MyFilePathInput1, " ", $MyFilePathInput2, " ", $MyFilePathOutput)
        
        Write-JtLog -Where $This.ClassName -Text $MyArgumentList
        Write-JtIoFile -Where $This.ClassName -Text "DoWrite..." -FilePath $MyFilePathOutput
        Start-Process -FilePath $This.CompositeExe  -ArgumentList $MyArgumentList -NoNewWindow  -Wait
        return $MyFilePathOutput
    }
}

Function New-JtImageMagick_Composite {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput1, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput1, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput2,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput2,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameOutput
    )

    [JtImageMagick_Composite]::new($FolderPathInput1, $FilenameInput1, $FolderPathInput2, $FilenameInput2, $FolderPathOutput, $FilenameOutput)
}


class JtImageMagick_Convert : JtImageMagick {
    
    [String]$Params = ""
    [String]$FolderPathInput = ""
    [String]$FilenameInput = ""
    
    JtImageMagick_Convert([String]$TheFolderPathInput, [String]$TheFilenameInput, [String]$TheFolderPathOutput, [String]$TheFilenameOutput) : Base ([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick_Convert"

        $This.FolderPathInput = $TheFolderPathInput
        $This.FilenameInput = $TheFilenameInput
    }

    [Void]SetBackground([String]$TheValue) {
        $This.AddParameter("background", $TheValue)
    }

    [Void]SetCrop([Int16]$X, [Int16]$Y) {
        # -crop ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y, "+0+0")
        $This.AddParameter("crop", $MyValue)
    }

    [Void]SetExtent([Int16]$X, [Int16]$Y) {
        # -extent ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y)
        $This.AddParameter("extent", $MyValue)
    }

    [Void]SetResize([Int16]$X, [Int16]$Y) {
        # -resize ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y, "+0+0")
        $This.AddParameter("resize", $MyValue)
    }

    [String]DoWrite() {
        # [String]$Args1 = -Join (" -crop ", $MyX1, "x", $MyY1, "+0+0 -background white ", $FolderPathInput, " ", $FilePathTarget )
        [String]$MyFolderPath_Input = $This.FolderPathInput
        [String]$MyFilenameInput = $This.FilenameInput
        [String]$MyFilePathInput = -join ($MyFolderPath_Input, "\", $MyFilenameInput)

        if (!(Test-JtIoFilePath -FilePath $MyFilePathInput)) {
            Write-JtError -Where $This.ClassName -Text "DoWrite... Not existing. MyFilePathInput: $MyFilePathInput"
#            Throw "FolderPathInput does not exist! $MyFolderPath_Input"
        }

        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput= $This.FilenameOutput

        [String]$MyFilePathOutput = -join ($MyFolderPath_Output, "\", $MyFilenameOutput)
        [String]$MyArgumentList = -join ($This.GetParams(), " ", $MyFilePathInput, "  ", $MyFilePathOutput)
        
        
        Write-JtIoFile -Where $This.ClassName -Text "DoWrite... " -FilePath $MyFilePathOutput
        Write-JtLog -Where $This.ClassName -Text "DoWrite... ArgumentList: $MyArgumentList"
        Start-Process -FilePath $This.ConvertExe  -ArgumentList $MyArgumentList -NoNewWindow  -Wait
        return $MyFilePathOutput
    }
}

Function New-JtImageMagick_Convert {

    param(
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameOutput
    )

    [JtImageMagick_Convert]::new($FolderPathInput, $FilenameInput, $FolderPathOutput, $FilenameOutput)
}

class JtImageMagick_Convert_PdfToJpg : JtImageMagick {
    
    [String]$Params = ""
    [String]$FolderPathInput = ""
    [String]$FilenameInput = ""
    
    JtImageMagick_Convert_PdfToJpg([String]$TheFolderPathInput, [String]$TheFilenameInput, [String]$TheFolderPathOutput, [String]$TheFilenameOutput) : Base ([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick_Convert_PdfToJpg"

        $This.FolderPathInput = $TheFolderPathInput
        $This.FilenameInput = $TheFilenameInput
    }


    [String]DoWrite() {
        # [String]$Args1 = -Join (" -crop ", $MyX1, "x", $MyY1, "+0+0 -background white ", $FolderPathInput, " ", $FilePathTarget )
        [String]$MyFolderPath_Input = $This.FolderPathInput
        [String]$MyFilenameInput = $This.FilenameInput
        [String]$MyFilePathInput = -join($MyFolderPath_Input, "\", $MyFilenameInput)

        if (!(Test-JtIoFilePath -FilePath $MyFilePathInput)) {
            Write-JtError -Where $This.ClassName -Text "DoWrite... FilePath does not exist. MyFilePathInput: $MyFilePathInput"
#            Throw "FolderPathInput does not exist! $MyFolderPath_Input"
        }

        [String]$MyFilePathInput = -join ($MyFolderPath_Input, "\", $MyFilenameInput, "[0]")
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = $This.FilenameOutput
        [String]$MyFilePathOutput = -join ($MyFolderPath_Output, "\", $MyFilenameOutput)
        [String]$MyArgumentList = -join ($This.GetParams(), " ", $MyFilePathInput, "  ", $MyFilePathOutput)
        
        Write-JtIoFile -Where $This.ClassName -Text "DoWrite..." -FilePath $MyFilePathOutput
        Write-JtLog -Where $This.ClassName -Text "DoWrite... ArgumentList: $MyArgumentList"
        Start-Process -FilePath $This.ConvertExe  -ArgumentList $MyArgumentList -NoNewWindow  -Wait
        return $MyFilePathOutput
    }

    [Void]SetColorspace([String]$TheValue) {
        # -colorspace rgb 
        $This.AddParameter("colorspace", $TheValue)
    }
    
    [Void]SetDepth([int16]$TheIntNumber) {
        # -depth 8 
        [String]$MyValue = -join ("", $TheIntNumber)
        $This.AddParameter("depth", $MyValue)
    }
    
    [Void]SetDensity([Int16]$TheIntNumber) {
        # -density 300 
        [String]$MyValue = -join ("", $TheIntNumber)
        $This.AddParameter("density", $MyValue)
    }
}

Function New-JtImageMagick_Convert_JpgToPdf {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput
    )

    
    [String]$MyFolderPath_Input = $FolderPathInput
    [String]$MyFilenameInput = $FilenameInput
    
    [String]$MyFolderPath_Output = $FolderPathOutput
    [String]$MyFilenameOutput = $MyFilenameInput.Replace(".jpg", ".pdf")
    
    [JtImageMagick_Convert]$MyJtImageMagick_Convert = New-JtImageMagick_Convert -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
    $MyJtImageMagick_Convert.DoWrite()
}

Function New-JtImageMagick_Convert_PdfToJpg {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput
    )

    [String]$MyFunctionName = "New-JtImageMagick_Convert_PdfToJpg"
    
    [String]$MyFolderPath_Input = $FolderPathInput
    [String]$MyFilenameInput = $FilenameInput
    
    [String]$MyFolderPath_Output = $FolderPathOutput
    [String]$MyFilenameOutput = $MyFilenameInput.Replace(".pdf", ".jpg")

    [JtImageMagick_Convert_PdfToJpg]$MyJtImageMagick_Convert_PdfToJpg = [JtImageMagick_Convert_PdfToJpg]::new($MyFolderPath_Input, $MyFilenameInput, $MyFolderPath_Output, $MyFilenameOutput)
    Write-JtLog -Where $MyFunctionName -Text "FolderPathInput: $MyFolderPath_Input"
        
    $MyJtImageMagick_Convert_PdfToJpg.SetColorspace("rgb")
    $MyJtImageMagick_Convert_PdfToJpg.SetDepth(8)
    $MyJtImageMagick_Convert_PdfToJpg.SetDensity(300)
    $MyJtImageMagick_Convert_PdfToJpg.DoWrite()
}

class JtImageMagickItem : JtClass {

    JtImageMagickItem() {
        $This.ClassName = "JtImageMagickItem"
    }

    [Boolean]DoWrite() {
        Throw "Should be overwritten..."

        return $False
    }
}


class JtImageMagick_Image : JtImageMagick {
    
    [String]$Params = ""
    [String]$FolderPathInput = $Null
    [String]$FilenameInput = $Null

    
    JtImageMagick_Image([String]$TheFolderPathInput, [String]$TheFilenameInput, [String]$TheFolderPathOutput, [String]$TheFilenameOutput) : Base ([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick_Image"
        $This.FolderPathInput = $TheFolderPathInput
        $This.FilenameInput = $TheFilenameInput
    }

    JtImageMagick_Image([String]$TheFolderPathOutput, [String]$TheFilenameOutput) : Base ([String]$TheFolderPathOutput, [String]$TheFilenameOutput) {
        $This.ClassName = "JtImageMagick_Image"
        $This.FolderPathInput = $Null
        $This.FilenameInput = $Null
    }

    [Void]SetBackground([String]$TheValue) {
        $This.AddParameter("background", $TheValue)
    }

    [Void]SetColorspace([String]$TheValue) {
        # -colorspace rgb 
        $This.AddParameter("colorspace", $TheValue)
    }
    
    [Void]SetCrop([Int16]$X, [Int16]$Y) {
        # -crop ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y, "+0+0")
        $This.AddParameter("crop", $MyValue)
    }

    [Void]SetDepth([int16]$Number) {
        # -depth 8 
        [String]$MyValue = -join ("", $Number)
        $This.AddParameter("depth", $MyValue)
    }
    
    [Void]SetDensity([Int16]$Number) {
        # -density 300 
        [String]$MyValue = -join ("", $Number)
        $This.AddParameter("density", $MyValue)
    }

    [Void]SetExtent([Int16]$X, [Int16]$Y) {
        # -extent ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y)
        $This.AddParameter("extent", $MyValue)
    }

    [Void]SetResize([Int16]$X, [Int16]$Y) {
        # -resize ", $MyX1, "x", $MyY1

        [String]$MyValue = -join ($X, "x", $Y, "+0+0")
        $This.AddParameter("resize", $MyValue)
    }

    [String]DoWrite() {
        # [String]$Args1 = -Join (" -crop ", $MyX1, "x", $MyY1, "+0+0 -background white ", $FolderPathInput, " ", $FilePathTarget )
        
        [String]$MyFilePathInput = ""


        if($This.FilenameInput) {
            [String]$MyFolderPath_Input = $This.FolderPathInput
            [String]$MyFilenameInput = $This.FilenameInput
            [String]$MyFilePathInput = -join ($MyFolderPath_Input, "\", $MyFilenameInput)
        }
        
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = $This.FilenameOutput
        [String]$MyFilePathOutput = -join ($MyFolderPath_Output, "\", $MyFilenameOutput)

    
        [String]$MyArgumentList = -join ($This.GetParams(), " ", $MyFilePathInput, "  ", $MyFilePathOutput)
        
        Write-JtIoFile -Where $This.ClassName -Text "DoWrite... MyFilenameOutput: $MyFilenameOutput" -FilePath $MyFilePathOutput
        Write-JtLog -Where $This.ClassName -Text "MyArgumentList: $MyArgumentList"
        Start-Process -FilePath $This.ConvertExe  -ArgumentList $MyArgumentList -NoNewWindow  -Wait
        return $MyFilePathOutput
    }
}


Function New-JtImageMagick_Image {

    param(
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$FolderPathInput,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$FilenameInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameOutput
    )

    [JtImageMagick_Image]::new($FolderPathInput, $FilenameInput, $FolderPathOutput, $FilenameOutput)
}


class JtImageMagick_Item_Background : JtImageMagickItem {

    [String]$Generation = $Null
    [String]$System = $Null
    [String]$User = $Null
    [String]$FolderPathOutput = $Null
    [String]$FolderPathTemplate
    
    JtImageMagick_Item_Background([String]$TheFolderPathOutput, [String]$TheGeneration, [String]$TheSystem, [String]$TheUser) : Base() {
        $This.ClassName = "JtImageMagick_Item_Background"

        [String]$MyFolderPath_Output = $TheFolderPathOutput

        New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
        $This.FolderPathOutput = -join ($MyFolderPath_Output, "\", "BACKGROUND")
        $This.FolderPathTemplate = -join ($MyFolderPath_Output, "\", "TEMPLATE")

        
        $This.System = $TheSystem
        $This.User = $TheUser
        $This.Generation = $TheGeneration
    }

    [String]DoWriteImageBase() {
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = -join ("_", $This.Generation, ".", $This.System, ".", $This.User, ".", "base.jpg")
        
        [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
        $MyJtImageMagick_Image.SetSize(2560, 30)
        $MyJtImageMagick_Image.SetFont("Arial")
        $MyJtImageMagick_Image.SetGravity("NorthWest")
        $MyJtImageMagick_Image.SetPointsize(20)
        $MyJtImageMagick_Image.SetBackground("green")
        $MyJtImageMagick_Image.SetFill("white")
        
        $MyLabel = "..."
        $MyJtImageMagick_Image.SetLabel($MyLabel)
        $MyJtImageMagick_Image.DoWrite()
        
        return $MyFilenameOutput
    }

        
    [String]DoWriteImageDate() {
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = -join ("_", $This.Generation, ".", $This.System, ".", $This.User, ".", "date.jpg")
        
        [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
        $MyJtImageMagick_Image.SetSize(1500, 30)
        $MyJtImageMagick_Image.SetFont("Arial")
        $MyJtImageMagick_Image.SetGravity("NorthWest")
        $MyJtImageMagick_Image.SetPointsize(20)
        $MyJtImageMagick_Image.SetBackground("black")
        $MyJtImageMagick_Image.SetFill("white")
        
        $D = Get-Date
        $MyLabel = -join ("             System: ", $This.System, "     User: ", $This.User, "     Version: ", $D.toString("yyyy-MM-dd"))
        $MyJtImageMagick_Image.SetLabel($MyLabel)
        $MyJtImageMagick_Image.DoWrite()
        
        return $MyFilenameOutput
    }
    
    [String]DoWriteImageDisclaimer() {
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        
        [String]$MyFilenameOutput = -join ("_", $This.Generation, ".", $This.System, ".", $This.User, ".", "disclaimer.jpg")
        [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
        $MyJtImageMagick_Image.SetSize(1500, 30)
        $MyJtImageMagick_Image.SetFont("Arial")
        $MyJtImageMagick_Image.SetGravity("NorthEast")
        $MyJtImageMagick_Image.SetPointsize(20)
        $MyJtImageMagick_Image.SetBackground("black")
        $MyJtImageMagick_Image.SetFill("white")

        [String]$MyLabel = ""
        if ($This.System -eq "win10p") {
            $MyLabel = "Normales System" 
        }
        else {
            $MyLabel = "Bitte Computer neu starten, um auf ALLE Anwendungen Zugriff zu haben..." 
        }
        $MyJtImageMagick_Image.SetLabel($MyLabel)
        $MyJtImageMagick_Image.DoWrite()
        return $MyFilenameOutput
    }

    [String]DoWriteImageTitleLeft([String]$TheFilenameInput2) {
        [String]$MyFolderPath_Input1 = $This.FolderPathOutput
        [String]$MyFilenameInput1 = $TheFilenameInput2
        [String]$MyFolderPath_Input2 = $This.FolderPathTemplate
        [String]$MyFilenameInput2 = $This.GetFilenameTemplate()

        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = -join ("_", $This.Generation, ".", $This.System, ".", $This.User, ".jpg")
        
        $MyParameters = @{
            FolderPathInput1 = $MyFolderPath_Input1
            FilenameInput1 = $MyFilenameInput1
            FolderPathInput2 = $MyFolderPath_Input2
            FilenameInput2 = $MyFilenameInput2
            FolderPathOutput = $MyFolderPath_Output
            FilenameOutput = $MyFilenameOutput
        }
        Write-JtLog -Where "DoWriteImageTitleLeft" -Text "Before composite"
        [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
        $MyJtImageMagick_Composite.SetGravity("NorthWest")
        $MyJtImageMagick_Composite.DoWrite()
        return $MyFilenameOutput
    }
    
    [String]DoWriteImageTitleRight([String]$TheFilenameInput1, [String]$TheFilenameInput2) {
        [String]$MyFolderPath_Input1 = $This.FolderPathOutput
        [String]$MyFilenameInput1 = $TheFilenameInput1
        [String]$MyFolderPath_Input2 = $This.FolderPathOutput
        [String]$MyFilenameInput2 = $TheFilenameInput2
        
        [String]$MyFolderPath_Output = $This.FolderPathOutput
        [String]$MyFilenameOutput = -join ($This.Generation, ".", $This.System, ".", $This.User, ".", "background.jpg")
        
        Write-JtLog -Where "DoWriteImageTitleRight" -Text "Before composite"
        $MyParameters = @{
            FolderPathInput1 = $MyFolderPath_Input1
            FilenameInput1 = $MyFilenameInput1
            FolderPathInput2 = $MyFolderPath_Input2
            FilenameInput2 = $MyFilenameInput2
            FolderPathOutput = $MyFolderPath_Output
            FilenameOutput = $MyFilenameOutput
        }
        [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
        $MyJtImageMagick_Composite.SetGravity("NorthEast")
        $MyJtImageMagick_Composite.DoWrite()
        return $MyFilenameOutput
    }

    [String]GetFilenameTemplate() {
        [String]$MyFilenameTemplate = -join ($This.Generation, ".", $This.System, ".", $This.User, ".jpg")
        return $MyFilenameTemplate
    }
    
    
    [Void]DoWrite() {
        # [String]$FilenameBase = $This.DoWriteImageBase()
        [String]$MyFilenameDate = $This.DoWriteImageDate()
        [String]$MyFilenameDisclaimer = $This.DoWriteImageDisclaimer()

        [String]$MyFilenameTitleLeft = $This.DoWriteImageTitleLeft($MyFilenameDate)
        [String]$MyFilenameBackground = $This.DoWriteImageTitleRight($MyFilenameDisclaimer, $MyFilenameTitleLeft)
        [String]$MyFilenameBackground
    }
}

Function New-JtImageMagick_Item_Background {
    
    param (
        [Parameter(Mandatory = $True)]
        [String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)]
        [String]$Generation, 
        [Parameter(Mandatory = $True)]
        [String]$System, 
        [Parameter(Mandatory = $True)]
        [String]$User
    )

    [JtImageMagick_Item_Background]$MyJtImageMagick_Item_Background = [JtImageMagick_Item_Background]::new($FolderPathOutput, $Generation, $System, $User)
    $MyJtImageMagick_Item_Background.DoWrite()

}


Function New-JtImageMagick_Item_Icon {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameOutput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][Int16]$Pointsize,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][Int16]$X,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][Int16]$Y,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Background
    )

    [String]$MyFolderPath_Output = $FolderPathOutput
    [String]$MyFilenameOutput = $FilenameOutput
    New-JtIoFolder -FolderPath $MyFolderPath_Output -Force

    [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
    $MyJtImageMagick_Image.SetFont("Arial")
    $MyJtImageMagick_Image.SetSize($X, $Y)
    $MyJtImageMagick_Image.SetGravity("Center")
        
    $MyJtImageMagick_Image.SetPointsize($Pointsize)
    if ($Null -eq $Background) {
        $Background = "red"
    }
    $MyJtImageMagick_Image.SetBackground($Background)
    $MyJtImageMagick_Image.SetFill("white")
    $MyJtImageMagick_Image.SetLabel($Label)
    $MyJtImageMagick_Image.DoWrite()
    return $False
}


Function New-JtImageMagick_Item_Login {

    param (
        [Parameter(Mandatory = $True)]
        [String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)]
        [String]$Generation, 
        [Parameter(Mandatory = $True)]
        [String]$System, 
        [Parameter(Mandatory = $True)]
        [String]$User,
        [Parameter(Mandatory = $True)]
        [String]$Background
    )
    [String]$MyFolderPath_Output = -join ($FolderPathOutput, "\", "LOGIN")

    if (!(Test-JtIoFolderPath -FolderPath $MyFolderPath_Output)) {
        Throw "Path does not exist: $MyFolderPath_Output"
    }

    New-JtIoFolder -FolderPath $MyFolderPath_Output -Force

    [String]$MyFilenameOutput = -join ($Generation, ".", $System, ".", $User, ".png")
    [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
    $MyJtImageMagick_Image.SetFont("Arial")
    $MyJtImageMagick_Image.SetSize(250, 250)
    $MyJtImageMagick_Image.SetGravity("Center")
        
    # Pointsize??
    $MyJtImageMagick_Image.SetPointsize(65)
    $MyJtImageMagick_Image.SetBackground($Background)
    $MyJtImageMagick_Image.SetFill("white")

    [String]$Classification = ""
    if ($System -eq "win10p") {
        $Classification = "normal" 
    }
    else {
        $Classification = "spezial" 
    }

    [String]$Label = ""
    if ($User -eq "pool") {
        $Label = -join ($User, "\n", $Classification, "\n", $Generation) 
    }
    else {
        $D = Get-Date
        $Label = -join ($D.toString("yyyy"), "\n", $D.toString("MM"), "\n", $D.toString("dd"))
    }
    $MyJtImageMagick_Image.SetLabel($Label)

    $MyJtImageMagick_Image.DoWrite()
    return $False
}


Function New-JtImageMagick_Item_Cover {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilenameInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput
    )

    [String]$MyFunctionName = "New-JtImageMagick_Item_Cover"

    [String]$MyFilename_Pdf = $FilenameInput
    [String]$MyFilename_Jpg = $MyFilename_Pdf.ToLower()
    [String]$MyFilename_Jpg = $MyFilename_Jpg.Replace([JtIo]::FileExtension_Pdf, [JtIo]::FileExtension_Jpg)

    [JtIoFolder]$MyJtIoFolderInput_Base = New-JtIoFolder -FolderPath $FolderPathInput
    [JtIoFolder]$MyJtIoFolderOutput_Base = New-JtIoFolder -FolderPath $FolderPathOutput -Force


    [JtIoFolder]$MyJtIoFolder_A = $MyJtIoFolderOutput_Base.GetJtIoFolder_Sub("A", $True)

    [JtIoFolder]$MyJtIoFolderInput = $MyJtIoFolderInput_Base
    [JtIoFolder]$MyJtIoFolderOutput = $MyJtIoFolder_A
    
[String]$MyFilenameInput = $MyFilename_Pdf
[String]$MyFilenameOutput = $MyFilename_Pdf

    [String]$MyFilePathInput  = $MyJtIoFolderInput.GetFilePath($MyFilenameInput)
    [String]$MyFilePathOutput = $MyJtIoFolderOutput.GetFilePath($MyFilenameOutput)
    Write-JtLog -Where $MyFunctionName -Text "Copying... MyFilePathInput: $MyFilePathInput MyFilePathOutput: $MyFilePathOutput"
    Copy-Item $MyFilePathInput $MyFilePathOutput
    
    [JtIoFolder]$MyJtIoFolder_B = $MyJtIoFolderOutput_Base.GetJtIoFolder_Sub("B", $True)

    [JtIoFolder]$MyJtIoFolderInput  = $MyJtIoFolder_A
    [JtIoFolder]$MyJtIoFolderOutput = $MyJtIoFolder_B

    [String]$MyFilenameInput = $MyFilename_Pdf
    [String]$MyFilenameOutput = $MyFilename_Jpg
    
    [String]$MyFolderPath_Input = $MyJtIoFolderInput.GetPath()
    [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
    
    New-JtImageMagick_Convert_PdfToJpg -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output
    
    [JtIoFolder]$MyJtIoFolder_C = $MyJtIoFolderOutput_Base.GetJtIoFolder_Sub("C", $True)

    [JtIoFolder]$MyJtIoFolderInput  = $MyJtIoFolder_B
    [JtIoFolder]$MyJtIoFolderOutput = $MyJtIoFolder_C

    [String]$MyFilenameInput = $MyFilename_Jpg
    [String]$MyFilenameOutput = $MyFilename_Jpg

    [String]$MyFolderPath_Input = $MyJtIoFolderInput.GetPath()
    [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
    New-JtImageMagick_Resize -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -X1 1920 -Y1 1080
    
    
    [JtIoFolder]$MyJtIoFolder_D = $MyJtIoFolderOutput_Base.GetJtIoFolder_Sub("D", $True)

    [JtIoFolder]$MyJtIoFolderInput = $MyJtIoFolder_C
    [JtIoFolder]$MyJtIoFolderOutput = $MyJtIoFolder_D

    [String]$MyFilenameInput = $MyFilename_Jpg
    [String]$MyFilenameOutput = $MyFilename_Jpg

    [String]$MyFolderPath_Input = $MyJtIoFolderInput.GetPath()
    [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
    New-JtImageMagick_Resize -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -X1 384 -Y1 216

}



Function New-JtImageMagick_Resize {

    param (
        [Parameter(Mandatory = $True)]
        [String]$FolderPathInput, 
        [Parameter(Mandatory = $True)]
        [String]$FilenameInput, 
        [Parameter(Mandatory = $True)]
        [String]$FolderPathOutput, 
        [Parameter(Mandatory = $True)]
        [Int16]$X1,
        [Parameter(Mandatory = $True)]
        [Int16]$Y1
    )

    $MyFunctionName = "New-JtImageMagick_Resize"

    Write-JtLog -Where $MyFunctionName -Text "Starting..."

    [String]$MyFolderPath_Input = $FolderPathInput
    [String]$MyFilenameInput = $FilenameInput

    [String]$MyFolderPath_Output = $FolderPathOutput
    [String]$MyFilenameOutput = $MyFilenameInput

    [JtImageMagick_Convert]$MyJtImageMagick_Convert = New-JtImageMagick_Convert -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
    $MyJtImageMagick_Convert.SetResize($X1, $Y1)
    $MyJtImageMagick_Convert.SetExtent($X1, $Y1)
    $MyJtImageMagick_Convert.DoWrite()
    return
}

class JtImageMagick_Tool : JtClass {

    [String]$FolderPathInput = $Null
    [String]$FolderPathWork = $Null

    JtImageMagick_Tool([String]$MyFolderPath_Input, [String]$MyFolderPath_Work) {
        $This.ClassName = "JtImageMagick_Tool"
        Write-JtLog -Where $This.ClassName -Text "Starting..."

        $This.FolderPathInput = $MyFolderPath_Input
        Write-JtLog -Where $This.ClassName -Text "MyFolderPathInput: $MyFolderPath_Input"
        
        $This.FolderPathWork = $MyFolderPath_Work
        Write-JtLog -Where $This.ClassName -Text "MyFolderPathWork: $MyFolderPath_Work"
    }

    [Void]DoCropJpgs([String]$MyInputSubJpg, [String]$MyTagetSubJpg, [int16]$MyX1, [int16]$MyY1) {
        Write-JtLog -Where $This.ClassName -Text "DoCropJpgs..."
        Write-JtLog -Where $This.ClassName -Text "Dimensions: $MyY1  x $MyX1"
    
        [String]$MyFolderPath_Input = $This.DoUseWorkSub($MyInputSubJpg)
        [String]$MyFolderPath_Output = $This.DoUseWorkSub($MyTagetSubJpg)

        [JtIoFolder]$MyJtIoFolderInput = New-JtIoFolder -FolderPath $MyFolderPath_Input
        
        $MyAlJtIoFiles = $MyJtIoFolderInput.GetIoFiles()
        foreach ($File in $MyAlJtIoFiles) {
            [String]$MyFilenameInput = $File.GetName()
            [String]$MyFilenameOutput = $MyFilenameInput
            
            Write-JtLogHost -Where $This.ClassName -Text "Creating JPG... MyFilenameOutput: $MyFilenameOutput in MyFolderPathOutput: $MyFolderPath_Output"
            
            [JtImageMagick_Convert]$MyJtImageMagick_Convert = New-JtImageMagick_Convert -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
            $MyJtImageMagick_Convert.SetCrop($MyX1, $MyY1)
            $MyJtImageMagick_Convert.SetBackground("white")
            $MyJtImageMagick_Convert.DoWrite()
            
            #    c:\apps\tools\JtImageMagick\convert.exe %1.jpg %1.jpg.pdf
        }
    }

    [Void]DoExtendJpgs([String]$MyInputSubJpg, [String]$MyTagetSubJpg, [int16]$MyX1, [int16]$MyY1) {
        Write-JtLog -Where $This.ClassName -Text "DoExtendJpgs..."

        $Msg = -join ("Dimensions: ", $MyY1, " x ", $MyX1)
        Write-JtLog -Where $This.ClassName -Text $Msg
    
        [String]$MyFolderPath_Input = $This.DoUseWorkSub($MyInputSubJpg)
        [String]$MyFolderPath_Output = $This.DoUseWorkSub($MyTagetSubJpg)

        [JtIoFolder]$MyJtIoFolderInput = New-JtIoFolder -FolderPath $MyFolderPath_Input
        
        $MyJtIoAlFiles = GetJtChildItem -FolderPath $MyJtIoFolderInput
        
        foreach ($File in $MyJtIoAlFiles) {
            [String]$MyFilenameInput = $File.GetName()
            [String]$MyFilenameOutput = $MyFilenameInput

            [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutput
            $MyJtImageMagick_Image.SetResize($MyY1, $MyY1)
            $MyJtImageMagick_Image.SetExtent($MyY1, $MyX1)
            $MyJtImageMagick_Image.SetGravity("center")
            $MyJtImageMagick_Image.SetBackground("white")
            $MyJtImageMagick_Image.DoWrite()
            
            #    c:\apps\tools\JtImageMagick\convert.exe %1.jpg %1.jpg.pdf
        }
    }

    [Void]DoInitFolderPathWork() {
        Write-JtLog -Where $This.ClassName -Text "DoInitFolderPathWork..."

        [JtIoFolder]$MyFolderPath_Work = $This.FolderPathWork
        $MyFolderPath_Work.DoRemoveEverything()
    }


    [Void]DoMatrixJpgs([String]$MyInputSubJpg, [String]$MyTargetSubJpg, [int16]$MyColumns) {
        Write-JtLog -Where $This.ClassName -Text "DoMatrixJpgs... Columns: $MyColumns, Source: $MyInputSubJpg, Target: $MyTargetSubJpg "

        [String]$MyFolderPath_InputJpg = $This.DoUseWorkSub($MyInputSubJpg)
        [String]$MyFolderPath_OutputJpg = $This.DoUseWorkSub($MyTargetSubJpg)
        
        [int16]$Col = 0
        [int16]$Row = 0

        [JtIoFolder]$MyJtIoFolderInputJpg = New-JtIoFolder -FolderPath $MyFolderPath_InputJpg

        [String]$MyFilter = -join("*", [JtIo]::FileExtension_Jpg)
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolderInputJpg -Filter $MyFilter 

        
        $Col = 0;    
        $Row = 1;
        foreach ($File in $MyAlJtIoFiles) {
            $Col = $Col + 1
            [String]$MyFilenameNew = -join ("img_", $Row.toString("000"), "_x_", $Col.toString("000"), ".jpg")
            
            [String]$MyFolderPath_Input = $File.GetPath()
            [String]$MyFolderPath_Output = -Join ($MyFolderPath_OutputJpg, "\", $MyFilenameNew)
            $MyFolderPath_Input
            $MyFolderPath_Output
            
            if ($Col -ge $MyColumns) {
                $Col = 0
                $Row = $Row + 1
            }
            
            Write-JtLog -Where $This.ClassName -Text "Copying from  MyFolderPathInput: $MyFolderPath_Input to MyFolderPathOutput: $MyFolderPath_Output"
            Copy-Item -Path $MyFolderPath_Input -Destination $MyFolderPath_Output
        }
    }

    [Void]DoPdf2Jpg([String]$MySubPdf, [String]$MySubJpg) {
        [String]$MyFolderPath_Input = $This.DoUseWorkSub($MySubPdf)
        [String]$MyFolderPath_Output = $This.DoUseWorkSub($MySubJpg)
        
        Write-JtLog -Where $This.ClassName -Text "DoPdf2Jpg...   MyFolderPathInput  (PDF): $MyFolderPath_Input"
        Write-JtLog -Where $This.ClassName -Text "DoPdf2Jpg...   MyFolderPathOutput (JPG): $MyFolderPath_Output"
        
        $MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyFolderPath_Input
        foreach ($File in $MyAlJtIoFiles) {
            [String]$MyFilenameInput = $File.GetName()
            New-JtImageMagick_Convert_PdfToJpg -FolderPathInput $MyFolderPath_Input -FilenameInput $MyFilenameInput -FolderPathOutput $MyFolderPath_Output
        }
    }

    [Void]DoStartIn([String]$TheSub) {
        [String]$MySub = $TheSub
        Write-JtLog -Where $This.ClassName -Text "DoStartIn... MySub: $MySub"
        
        [String]$MyFolderPath_Input = -join ($This.FolderPathInput, "\", "*.*")
        [String]$MyFolderPath_Output = -join ($This.FolderPathWork, "\", $MySub)
        
        New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
        
        $MyMsg = "Copying ... $MyFolderPath_Input to $MyFolderPath_Output"
        Write-JtLog -Where $This.ClassName -Text $MyMsg
    
        Copy-Item -Path $MyFolderPath_Input  -Destination $MyFolderPath_Output -Recurse


        [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyFolderPath_Output


        Convert-JtIoFilenamesAtFolderPath -FolderPath $MyJtIoFolderOutput.GetPath()
    }
        [String]DoUseWorkSub([String]$TheSub) {
            [String]$MySub = $TheSub
            Write-JtLog -Where $This.ClassName -Text "DoUseWorkSub"
            
            $MyMsg = "Using sub dir $MySub in FolderPathWork: $This.FolderPathWork"
            Write-JtLog -Where $This.ClassName -Text $MyMsg
            
            [String]$MyFolderPath = -join ($This.FolderPathWork, "\", $MySub)
            New-JtIoFolder -FolderPath $MyFolderPath -Force
            
            return $MyFolderPath
        }
}

Function New-JtImageMagick_Tool {

    param(
        [Parameter(Mandatory = $True)]
        [String]$FolderPathInput,
        [Parameter(Mandatory = $True)]
        [String]$FolderPathWork
    )

    [JtImageMagick_Tool]::new($FolderPathInput, $FolderPathWork)
}

Function New-JtImageTwin {

    param (
        [String]$FolderPathInput1,
        [Int16]$InputFileX1,
        [Int16]$InputFileY1,
        [String]$FolderPathOutput,
        [String]$FilenameOutput
    )

    [String]$MyFunctionName = "New-JtImageTwin"
    [String]$MyFolderPath_Input1 = $FolderPathInput1
    [String]$MyFolderPath_Output = $FolderPathOutput
    [String]$MyFilenameOutput = $FilenameOutput
    
    [JtIoFolder]$MyJtIoFolderWork = Get-JtIoFolder_Work -Name $MyFunctionName
    [String]$MyFolderPath_Output_Work = $MyJtIoFolderWork.GetPath()

    [String]$MyFolderPath_Output = $FolderPathOutput
    [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyFolderPath_Output -Force

    [String]$MyFilenameOutputBlank = $MyFilenameOutput.replace(".jpg", "_blank.jpg")
    [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output_Work -FilenameOutput $MyFilenameOutputBlank

    [Int16]$IntSizeX = [Int16]$InputFileX1 + [Int16]$InputFileX1
    $MyJtImageMagick_Image.SetSize($IntSizeX, $InputFileY1)
    $MyJtImageMagick_Image.SetFont("Arial")
    $MyJtImageMagick_Image.SetGravity("NorthWest")
    $MyJtImageMagick_Image.SetPointsize(20)
    $MyJtImageMagick_Image.SetBackground("green")
    $MyJtImageMagick_Image.SetFill("yellow")
    $MyJtImageMagick_Image.SetLabel(".")
    [String]$MyFilePathImageWorkBlank = $MyJtImageMagick_Image.DoWrite()
    

    [String]$MyFilenameOutputLeft = $MyFilenameOutput.replace(".jpg", "_left.jpg")
    $MyParameters = @{
        FolderPathInput1 = $MyFolderPath_Input1
        FolderPathInput2 = $MyFilePathImageWorkBlank
        FolderPathOutput = $MyJtIoFolderWork.GetPath()
        FilenameOutput = $MyFilenameOutputLeft
    }
    
    [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
    $MyJtImageMagick_Composite.SetGravity("NorthWest")
    [String]$MyFilePathWorkImageLeft = $MyJtImageMagick_Composite.DoWrite()
    
    [String]$MyFilenameOutputRight = $MyFilenameOutput.replace(".jpg", "_right.jpg")
    $MyParameters = @{
        FolderPathInput1 = $MyFolderPath_Input1
        FilenameInput1 = $MyFilenameOutputLeft
        FolderPathInput2 = $MyFolderPath_Output_Work
        FilenameInput2 = $MyFilenameInput
        FolderPathOutput   = $MyJtIoFolderWork.GetPath()
        FilenameOutput = $MyFilenameOutputRight
    }

    [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
    $MyJtImageMagick_Composite.SetGravity("NorthEast")
    [String]$MyFilePathImageWorkFinal = $MyJtImageMagick_Composite.DoWrite()
    [String]$MyFilePathOutput = $MyJtIoFolderOutput.GetFilePath($MyFilenameOutput)

    Write-JtIoFile -Where $MyFunctionName -Text "Copying $MyFilePathImageWorkFinal to ..." -FilePath $MyFilePathOutput
    Copy-Item $MyFilePathImageWorkFinal $MyFilePathOutput

    return $MyFilePathOutput
}



Function New-JtImageAttachRight {

    param (
        [String]$FolderPathInput1,
        [Int16]$InputFileX1,
        [Int16]$InputFileY1,
        [String]$FolderPathInput2,
        [Int16]$InputFileX2,
        [Int16]$InputFileY2,
        [String]$FolderPathOutput,
        [String]$FilenameOutput
    )
        
    [String]$MyFunctionName = "New-JtImageAttachRight"
    # [JtIoFolder]$MyJtIoFolderWork = Get-JtIoFolder_Work -Name $MyFunctionName
    [String]$MyFilenameOutput = $FilenameOutput
    [String]$MyFolderPath_Input1 = $FolderPathInput1
    [String]$MyFolderPath_Input2 = $FolderPathInput2
    [String]$MyFolderPath_Output = $FolderPathOutput
    

    [String]$MyFilenameOutputBlank = $MyFilenameOutput.replace(".jpg", "_blank.jpg")
    [JtImageMagick_Image]$MyJtImageMagick_Image = New-JtImageMagick_Image -FolderPathOutput $MyFolderPath_Output -FilenameOutput $MyFilenameOutputBlank

    [Int16]$IntSizeX = [Int16]$InputFileX1 + [Int16]$InputFileX2
    $MyJtImageMagick_Image.SetSize($IntSizeX, $InputFileY1)
    $MyJtImageMagick_Image.SetFont("Arial")
    $MyJtImageMagick_Image.SetGravity("NorthEast")
    $MyJtImageMagick_Image.SetPointsize(20)
    $MyJtImageMagick_Image.SetBackground("green")
    $MyJtImageMagick_Image.SetFill("yellow")
    $MyJtImageMagick_Image.SetLabel(".")
    [String]$MyFilePathWorkImageBlank = $MyJtImageMagick_Image.DoWrite()
    

    [String]$MyFilenameOutputLeft = $FilenameOutput.replace(".jpg", "_left.jpg")
    $MyParameters = @{
        FolderPathInput1 = $MyFolderPath_Input1
        FolderPathInput2 = $MyFilePathWorkImageBlank
        FolderPathOutput = $MyJtIoFolderWork.GetPath()
        FilenameOutput   = $MyFilenameOutputLeft
    }
    
    [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
    $MyJtImageMagick_Composite.SetGravity("NorthWest")
    [String]$MyFilePathWorkImageLeft = $MyJtImageMagick_Composite.DoWrite()
    
    [String]$MyFilenameOutputRight = $MyFilenameOutput.replace(".jpg", "_east.jpg")
    $MyParameters = @{
        FolderPathInput1 = $MyFolderPath_Input2
        FolderPathInput2 = $MyFilePathWorkImageLeft
        FolderPathOutput = $MyJtIoFolderWork.GetPath()
        FilenameOutput = $MyFilenameOutputRight
    }

    [JtImageMagick_Composite]$MyJtImageMagick_Composite = New-JtImageMagick_Composite @MyParameters
    $MyJtImageMagick_Composite.SetGravity("NorthEast")
    [String]$MyFilePathWorkImageRight = $MyJtImageMagick_Composite.DoWrite()

    [String]$MyFolderPath_Output = $MyJtIoFolderWork.GetPath()
    [String]$MyFilenameOutput = $MyFilenameOutput
    [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
    [String]$MyFilePathOutput = $MyJtIoFolderOutput.GetFilePath($MyFilenameOutput)

    Write-JtLog -Text "MyFilePathWorkImageRight: $MyFilePathWorkImageRight"
    Write-JtLog -Text "MyFilePathOutput: $MyFilePathOutput"
    Copy-Item $MyFilePathWorkImageRight $MyFilePathOutput

    return $MyFilePathOutput
}



Export-ModuleMember -Function New-JtImageMagick_Composite
Export-ModuleMember -Function New-JtImageMagick_Convert
Export-ModuleMember -Function New-JtImageMagick_Convert_JpgToPdf 
Export-ModuleMember -Function New-JtImageMagick_Convert_PdfToJpg
Export-ModuleMember -Function New-JtImageMagick_Image
Export-ModuleMember -Function New-JtImageMagick_Item_Background
Export-ModuleMember -Function New-JtImageMagick_Item_Icon
Export-ModuleMember -Function New-JtImageMagick_Item_Login
Export-ModuleMember -Function New-JtImageMagick_Item_Cover
Export-ModuleMember -Function New-JtImageMagick_Resize
Export-ModuleMember -Function New-JtImageMagick_Tool
Export-ModuleMember -Function New-JtImageTwin
Export-ModuleMember -Function New-JtImageAttachRight