using module Jt  
using module JtIo
using module JtColRen

class JtTemplateFile : JtClass {

    [JtIoFile]$JtIoFile
    [JtIoFolder]$JtIoFolder
    [String]$FilenameTemplate
    [Boolean]$Valid = $False

    JtTemplateFile([JtIoFolder]$TheJtIoFolder) {
        $This.ClassName = "JtTemplateFile"
        $This.JtIoFolder = $TheJtIoFolder
        $This.DoInit()
    }

    [Boolean]DoInit() {
        [JtIoFolder]$MyJtIoFolder = $This.JtIoFolder
        # Write-JtLog -Where $This.ClassName -Text "DoInit. Path: $FolderPath"
        $This.JtIoFile = $null

        [String]$MyExtension = [JtIo]::FileExtension_Folder
        [String]$MyFilter = -join ("*", $MyExtension)
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter
        if ($MyAlJtIoFiles.Count -gt 0) {
            $This.JtIoFile = $MyAlJtIoFiles[0]
            $This.Valid = $True
            $This.FilenameTemplate = $This.JtIoFile.GetName()
        }
        else {
            $This.Valid = $False
            Write-JtError -Where $This.ClassName -Text "Template file is missing. MyJtIoFolder: $MyJtIoFolder Filter: $MyFilter"
        }
        return $True
    }

    [Boolean]IsValid() {
        return $This.Valid
    }
    
    [JtColRen]GetJtColRenForColumnNumber([Int16]$IntCol) {
        [System.Collections.ArrayList]$MyAlJtColRens = $This.GetJtColRens()
        if ($IntCol -lt $MyAlJtColRens.Count) {
            return $MyAlJtColRens[$IntCol]
        }
        else {
            [String]$MyLabel = -join ("Column_Number_", $IntCol)
            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label $MyLabel
            Write-JtError -Where $This.ClassName -Text "Problem with column number: $IntCol"
        }
        return $MyJtColRen
    }

    [System.Collections.ArrayList]GetJtColRens() {
        [System.Collections.ArrayList]$MyAlJtColRens = [System.Collections.ArrayList]::new()
        if (!($This.Valid)) {
            [JtIoFolder]$MyJtIoFolder = $This.JtIoFolder
            Write-JtError -Where $This.ClassName -Text "GetJtColRens. Not VALID; returning NULL at PATH: $MyJtIoFolder"
            return $Null
        }

        [String]$MyFilenameTemplate = $This.FilenameTemplate
        
        $MyAlTemplateParts = $MyFilenameTemplate.Split(".")
        foreach ($Part in $MyAlTemplateParts) {
            [String]$MyPart = $Part
            # Write-JtLog -Where $This.ClassName -Text "GetJtColRens. MyFilenameTemplate: $MyFilenameTemplate"
            [JtColRen]$MyJtColRen = Get-JtColRen -Name $MyPart
            $MyAlJtColRens.Add($MyJtColRen)
        }
        return $MyAlJtColRens
    }

    [Int16]GetJtColRensCount() {
        [System.Collections.ArrayList]$MyAlJtColRens = $This.GetJtColRens()
        [Int32]$NumTemplateParts = $MyAlJtColRens.Count
        return $NumTemplateParts
    }

    [JtIoFolder]GetJtIoFolder() {
        return [JtIoFolder]$This.JtIoFolder
    }

    [Boolean]GetHasColumnForAnzahl() {
        [JtColRen]$MyColCompare = New-JtColRenInputAnzahl
        return $This.GetHasColumnOfType($MyColCompare)
    }
    
    [Boolean]GetHasColumnForArea() {
        [JtColRen]$MyColCompare = New-JtColRenInput_Bxh
        return $This.GetHasColumnOfType($MyColCompare)
    }
    
    [Boolean]GetHasColumnForEuro() {
        [JtColRen]$MyColCompare = New-JtColRenInputCurrencyEuro
        return $This.GetHasColumnOfType($MyColCompare)
    }

    [Boolean]GetHasColumnOfType([JtColRen]$MyJtColRen) {
        [Boolean]$MyResult = $False
        [System.Collections.ArrayList]$MyAlJtColRens = $This.GetJtColRens()
        
        [JtColRen]$MyColCompare = $MyJtColRen
        foreach ($MyJtColRen in $MyAlJtColRens) {
            [JtColRen]$MyJtColRen = $MyJtColRen
            if ($MyColCompare -eq $MyJtColRen) {
                $MyResult = $True
                return $MyResult
            }
        }
        return $MyResult
    }

    [Boolean]DoCheckFile([JtIoFile]$TheJtIoFile) {
        [JtIoFile]$MyJtIoFile = $TheJtIoFile
        [Boolean]$MyResult = $True

        if (!($This.IsValid())) {
            return $False
        }

        [String]$MyFilename = $MyJtIoFile.GetName()
        $MyAlFileNameParts = $MyFilename.Split(".")
        [Int16]$MyNumOfFilenameParts = $MyAlFileNameParts.Count

        [System.Collections.ArrayList]$MyAlColRens = $This.GetJtColRens()
        [Int16]$MyNumOfTemplateParts = $MyAlColRens.Count
        
            
        [String]$MyFilePath = $MyJtIoFile.GetPath()
        # Write-JtLog -Where $This.ClassName -Text "DoCheckFile. Checking file: $TheFilePath"
        if ($MyNumOfFilenameParts -ne $MyNumOfTemplateParts) {
            Write-JtError -Where $This.ClassName -Text "DoCheckFile. Not in expected format. Filename: $MyFilename - Parts in filename: $MyNumOfFilenameParts - Parts in template: $MyNumOfTemplateParts"
                
            [String]$MyMessage = "Problem with file (DoCheckFile): MyFilename: $MyFilename"
            Write-JtFolder -Text $MyMessage -FilePath $MyFilePath
            $MyResult = $False
        }
        else {
            for ([Int32]$i = 0; $i -lt $MyNumOfTemplateParts; $i++) {
                [String]$MyValue = $MyAlFileNameParts[$i]
                [JtColRen]$MyJtColRen = $MyAlColRens[$i]
                [Boolean]$IsValid = $MyJtColRen.CheckValid($MyValue)
                if (! ($IsValid)) {
                    [String]$MyMessage = "DoCheckFile. File not valid; MyFilename: $MyFilename"
                    Write-JtFolder -Text $MyMessage -FilePath $MyFilePath
                    return $False
                }
            }
        }
        return $MyResult
    }

    [String]GetName() {
        return $This.FilenameTemplate
    }
}

Function Get-JtTemplateFile {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
        
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
    [JtTemplateFile]::new($MyJtIoFolder)
}

Function Get-JtTemplateFile_Check_FolderPath {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFunctionName = "Get-JtTemplateFile_Check_FolderPath"
    [String]$MyFolderPath = $FolderPath

    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
    [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -JtIoFolder $MyJtIoFolder

    
    [Int16]$MyIntProblems = 0

    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
    foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File
        [Boolean]$MyResult = $MyJtTemplateFile.DoCheckFile($MyJtIoFile)
        if (!($MyResult)) {
            $MyIntProblems ++
        }
    }
    if ($MyIntProblems -gt 0) {
        Write-JtError -Where $MyFunctionName -Text "Number of problems found: $MyIntProblems"
    }

    return $MyIntProblems
}


Function Get-JtCheck_Folder_Recurse {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput
    )

    [String]$MyFunctionName = "Get-JtCheck_Folder_Recurse"
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $FolderPathInput

    [String]$MyExtension = [JtIo]::FileExtension_Folder
    [String]$MyFilter = -join ("*", $MyExtension)
    [System.Collections.ArrayList]$MyAlJtIoFiles_Folder = Get-JtChildItem $MyJtIoFolder -Filter $MyFilter -Recurse

    [Int16]$MyIntProblems = 0
    foreach ($File in $MyAlJtIoFiles_Folder) {
        [JtIoFile]$MyJtIoFile = $File
        [JtIoFolder]$MyJtIoFolderParent = $MyJtIoFile.GetJtIoFolder_Parent()

        [Int16]$MyIntFolderSum = Get-JtTemplateFile_Check_FolderPath -FolderPath $MyJtIoFolderParent
        $MyIntProblems = $MyIntProblems + $MyIntFolderSum
    }

    if ($MyIntProblems -gt 0) {
        Write-JtError -Where $MyFunctionName -Text "Number of problems found: $MyIntProblems"
    }
}



Export-ModuleMember -Function Get-JtTemplateFile
Export-ModuleMember -Function Get-JtTemplateFile_Check_FolderPath
Export-ModuleMember -Function Get-JtCheck_Folder_Recurse