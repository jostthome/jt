using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareVray : JtRep {

    JtRep_SoftwareVray() : Base("software.vray") {
        $This.ClassName = "JtRep_SoftwareVray"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Max_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRay3ds)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Revit_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRayRevit)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Rhino_6)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRayRhino)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Sketchup)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRaySketchup)

        return $MyJtTblRow
    }
}

Function New-JtRep_SoftwareVray {

    [JtRep_SoftwareVray]::new() 

}


