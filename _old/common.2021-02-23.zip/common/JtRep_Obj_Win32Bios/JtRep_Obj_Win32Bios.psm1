using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32Bios : JtRep {

    JtRep_Obj_Win32Bios() : Base("obj.win32_bios") {
        $This.ClassName = "JtRep_Obj_Win32Bios"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().Hersteller) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().Sn) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().BIOSVersion) | Out-Null 
        return $MyJtTblRow
    }

}


Function New-JtRep_Obj_Win32Bios {

    [JtRep_Obj_Win32Bios]::new() 

}

