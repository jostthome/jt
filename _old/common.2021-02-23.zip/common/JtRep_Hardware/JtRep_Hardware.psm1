using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Hardware : JtRep {

    JtRep_Hardware() : Base("report.hardware") {
        $This.ClassName = "JtRep_Hardware"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Herst) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Modell) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Ram) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Cpu) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Processor().Ghz) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32VideoController().Grafikkarte) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C_Capacity) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D_Capacity) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().Sn) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32Bios().BIOSVersion) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Mac) | Out-Null
        return $MyJtTblRow
    }
}

Function New-JtRep_Hardware {

    [JtRep_Hardware]::new() 

}

