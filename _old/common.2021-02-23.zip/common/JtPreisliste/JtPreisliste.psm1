using module Jt  
using module JtIo

using module JtTbl

class JtPreisliste : JtClass {

    [System.Data.Datatable]$DataTable = $Null
    
    [String]$Title = ""
    [String]$ColId_Price = "PREIS_ID"
    [String]$ColLabel_Paper = "PAPIER"
    [String]$ColLabel_Ink = "TINTE"
    [String]$ColBasePrice_Ink = "BASIS_TINTE"
    [String]$ColBasePrice_Paper = "BASIS_PAPIER"
    [String]$FilenameTemplate = "BASIS_PAPIER"

    JtPreisliste([String]$MyTitle) {
        $This.ClassName = "JtPreisliste"
        $This.Title = $MyTitle
        $This.FilenameTemplate = -join ("_NACHNAME.VORNAME.LABEL.PAPIER.BxH", [JtIo]::FileExtension_Folder)


        $This.DataTable = New-Object System.Data.Datatable

        $This.DataTable.Columns.Add($This.ColId_Price, "String")
        $This.DataTable.Columns.Add($This.ColLabel_Paper, "String")
        $This.DataTable.Columns.Add($This.ColLabel_Ink, "String")
        $This.DataTable.Columns.Add($This.ColBasePrice_Paper, "String")
        $This.DataTable.Columns.Add($This.ColBasePrice_Ink, "String")
    }

    AddRow([String]$PreisId, [String]$PapierLabel, [String]$TinteLabel, [String]$PapierGrundpreis, [String]$TinteGrundpreis) {
        $Row = $This.DataTable.NewRow()

        [String]$Label = ""
        [String]$MyValue = ""

        $Label = $This.ColId_Price
        $MyValue = $PreisId
        $Row.($Label) = $MyValue

        $Label = $This.ColLabel_Paper
        $MyValue = $PapierLabel
        $Row.($Label) = $MyValue

        $Label = $This.ColLabel_Ink
        $MyValue = $TinteLabel
        $Row.($Label) = $MyValue

        $Label = $This.ColBasePrice_Paper
        $MyValue = $PapierGrundpreis
        $Row.($Label) = $MyValue

        $Label = $This.ColBasePrice_Ink
        $MyValue = $TinteGrundpreis
        $Row.($Label) = $MyValue

        $This.DataTable.Rows.Add($Row)
    }

    [String]GetTitle() {
        return $This.Title
    }

    [System.Object]GetRow([String]$TheLabel) {
        [String]$MyLabel = $TheLabel
        [System.Data.DataRow]$MyRow = $This.DataTable.Rows | Where-Object {$_.PREIS_ID -eq $MyLabel}

        if($Null -eq $MyRow) {
            return $Null
        } else {
            return $MyRow
        }
    }

    [Decimal]GetDecBasePrice_Paper([String]$TheLabel) {
        [String]$MyLabel = $TheLabel
        [System.Object]$MyRow = $This.GetRow($MyLabel)

        if ($Null -eq $MyRow) {
            Write-JtError -Where $This.ClassName -Text "GetDecBasePrice_Paper. MyRow is NULL for MyLabel $MyLabel"
            return 999
        }
        else {
            [String]$MyValue = $MyRow.($This.ColBasePrice_Paper)
            
            [Decimal]$MyDecValue = Convert-JtString_To_Decimal -Text $MyValue
            return $MyDecValue
        }
    }
    
    [Decimal]GetDecBasePrice_Ink([String]$TheLabel) {
        [String]$MyLabel = $TheLabel
        [System.Object]$MyRow = $This.GetRow($MyLabel)
        
        if ($Null -eq $MyRow) {
            Write-JtError -Where $This.ClassName -Text "GetDecBasePrice_Ink. MyRow is NULL for MyLabel $MyLabel"
            return 999
        }
        else {
            [String]$MyValue = $MyRow.($This.ColBasePrice_Ink)
            
            [Decimal]$MyDecValue = Convert-JtString_To_Decimal -Text $MyValue
            return $MyDecValue
        }
    }
}

Function New-JtPreisliste_Plotten_2020_07_01 {

    [String]$MyTarif_Papier_Normal = "1.25"
    [String]$MyTarif_Papier_Spezial = "2.50"

    [String]$MyTarif_Tinte_Normal = "6.50"
    [String]$MyTarif_Tinte_Minimal = "1.00"

    [JtPreisliste]$MyJtPreisliste = [JtPreisliste]::new("Plotten_2020_07_01")

    $MyJtPreisliste.AddRow("fabriano", "FABRIANO", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("fabriano_minimal", "FABRIANO", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("semi", "Fotopapier, matt", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("semi_minimal", "Fotopapier, matt", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("glossy", "Fotopapier, glanz", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("glossy_minimal", "Fotopapier, glanz", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("trans", "Transparent-Papier", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("trans_minimal", "Transparent-Papier", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("180g", "180g-Papier", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("180g_minimal", "180g-Papier", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("90g", "90g-Papier", "NORMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("90g_minimal", "90g-Papier", "MINIMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("own", "Eigenes Papier", "NORMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("own_minimal", "Eigenes Papier", "MINIMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Minimal)
    [JtPreisliste]$MyJtPreisliste
}


Function New-JtPreisliste_Plotten_2022_01_01 {

    [String]$MyTarif_Papier_Normal = "1.25"
    [String]$MyTarif_Papier_Spezial = "3.00"

    [String]$MyTarif_Tinte_Normal = "7.50"
    [String]$MyTarif_Tinte_Minimal = "1.00"

    [JtPreisliste]$MyJtPreisliste = [JtPreisliste]::new("Plotten_2021_01_01")

    $MyJtPreisliste.AddRow("fabriano", "FABRIANO", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("fabriano_minimal", "FABRIANO", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("semi", "Fotopapier, matt", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("semi_minimal", "Fotopapier, matt", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("glossy", "Fotopapier, glanz", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("glossy_minimal", "Fotopapier, glanz", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("trans", "Transparent-Papier", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("trans_minimal", "Transparent-Papier", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("180g", "180g-Papier", "NORMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("180g_minimal", "180g-Papier", "MINIMAL", $MyTarif_Papier_Spezial, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("90g", "90g-Papier", "NORMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("90g_minimal", "90g-Papier", "MINIMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Minimal)

    $MyJtPreisliste.AddRow("own", "Eigenes Papier", "NORMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Normal)
    $MyJtPreisliste.AddRow("own_minimal", "Eigenes Papier", "MINIMAL", $MyTarif_Papier_Normal, $MyTarif_Tinte_Minimal)
    [JtPreisliste]$MyJtPreisliste
}


