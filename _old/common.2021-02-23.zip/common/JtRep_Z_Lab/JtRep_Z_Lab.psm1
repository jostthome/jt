using module JtTbl
using module JtInf_Soft
using module JtInfi
using module JtRep

class JtRep_Z_Lab : JtRep {

    JtRep_Z_Lab() : Base("z.lab") {
        $This.ClassName = "JtRep_Z_Lab"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Unity)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().UnityHub)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().CreativeSuite_CS6)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AutoCAD_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Max_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Revit_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().ArchiCAD)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Vectorworks)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Cinema4D)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().SketchUp)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Rhino_6)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRay3ds)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRayRevit)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRayRhino)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().vRaySketchup)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().GoogleEarth)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Arduino)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().LibreOffice)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AcrobatReader)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AntiVirus)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Chrome)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Firefox64)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Java)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().PDF24)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellCommand)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellSuppAs)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seafile)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seadrive)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Sumatra)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().VLC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().WibuKey)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Zip7)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32VideoController().Grafikkarte)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32VideoController().TreiberVersion) 
    
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Get_WinVersion())

        return $MyJtTblRow
    }


}


Function New-JtRep_Z_Lab {

    [JtRep_Z_Lab]::new() 

}

