using module JtInf
using module JtIo
using module JtTbl


class JtInf_Win32LogicalDisk : JtInf { 

    [JtFld]$C
    [JtFld]$C_Capacity
    [JtFld]$C_Free
    [JtFld]$C_FreePercent
    [JtFld]$D
    [JtFld]$D_Capacity
    [JtFld]$D_Free
    [JtFld]$D_FreePercent
    [JtFld]$E
    [JtFld]$E_Capacity
    [JtFld]$E_Free
    [JtFld]$E_FreePercent

    JtInf_Win32LogicalDisk() {
        $This.C = New-JtFld -Label "C"
        $This.C_Capacity = New-JtFld -Label "C_Capacity"
        $This.C_Free = New-JtFld -Label "C_Free"
        $This.C_FreePercent = New-JtFld -Label "C_FreePercent"
        $This.D = New-JtFld -Label "D"
        $This.D_Capacity = New-JtFld -Label "D_Capacity"
        $This.D_Free = New-JtFld -Label "D_Free"
        $This.D_FreePercent = New-JtFld -Label "D_FreePercent"
        $This.E = New-JtFld -Label "E"
        $This.E_Capacity = New-JtFld -Label "E_Capacity"
        $This.E_Free = New-JtFld -Label "E_Free"
        $This.E_FreePercent = New-JtFld -Label "E_FreePercent"
    }
    
}
Function New-JtInf_Win32LogicalDisk {
    [JtInf_Win32LogicalDisk]::new()
}



Function Get-JtInf_Win32LogicalDisk {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [String]$MyFunctionName = "Get-JtInf_Win32LogicalDisk"
    [JtInf_Win32LogicalDisk]$MyJtInf = New-JtInf_Win32LogicalDisk

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

    [String]$MyName = "Win32_LogicalDisk"
    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if ($MyObj) {
        $MyAlLetters = @("C", "D", "E")
        foreach ($MyLetter in $MyAlLetters) {
            $MyField1 = $MyLetter
            $MyValue1 = ""
            $MyField2 = -join ($MyLetter, "_", "Capacity")
            $MyValue2 = ""
            $MyField3 = -join ($MyLetter, "_", "Free")
            $MyValue3 = ""
            $MyField4 = -join ($MyLetter, "_", "FreePercent")
            $MyValue4 = ""

            # mediatype ssd hd ... GetMediaTypeForValue.....

            # try {
                $MyTestValue = -join ($MyLetter, ":")
                $MyObj2 = $MyObj | Where-Object -Property DeviceId -eq -Value $MyTestValue
                $MyObj3 = $MyObj2 | Select-Object -Property DeviceID, VolumeName, @{L = "Capacity"; E = { "{0:N2}" -f ($_.Size / 1GB) } }, @{L = 'FreeSpaceGB'; E = { "{0:N2}" -f ($_.FreeSpace / 1GB) } }
     
                foreach ($Line in $MyObj3) {
                    $MyDriveLetter = $Line.DeviceID.Replace(":", "")
                    $MyValue1 = $MyDriveLetter
                    $MyJtInf.$MyField1.SetValue($MyValue1)
    
                    $MyCapacity = $Line.Capacity
                    $MyValue2 = $MyCapacity
                    $MyJtInf.$MyField2.SetValue($MyValue2)
     
                    $MyFreeSpaceGB = $Line.FreeSpaceGB
                    $MyValue3 = $MyFreeSpaceGB
                    $MyJtInf.$MyField3.SetValue($MyValue3)

                    [Decimal]$MyDecCapacity = Convert-JtString_To_Decimal -Text $MyCapacity
                    [Decimal]$MyDecFreeSpaceGB = Convert-JtString_To_Decimal -Text $MyFreeSpaceGB

                    [Decimal]$MyDecFree = $MyDecFreeSpaceGB / $MyDecCapacity * 100
                    $MyValue4 = $MyDecFree -as [int32]
                    $MyJtInf.$MyField4.SetValue($MyValue4)
    
                } 
            # }
            # catch {
            #     Write-JtError -Where $MyFunctionName -Text "Obj is NULL for letter MyLetter: $MyLetter in MyName: $MyName"
            # } 
        }
    }
    return [JtInf_Win32LogicalDisk]$MyJtInf
} 


Export-ModuleMember -Function Get-JtInf_Win32LogicalDisk
Export-ModuleMember -Function New-JtInf_Win32LogicalDisk