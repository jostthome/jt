using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Bitlocker : JtRep {

    JtRep_Bitlocker() : Base("report.bitlocker") {
        $This.ClassName = "JtRep_Bitlocker"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().C_CapacityGB)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().C_VolumeType)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().C_EncryptionMethod)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().C_ProtectionStatus)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().D_CapacityGB)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().D_VolumeType)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().D_EncryptionMethod)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Bitlocker().D_ProtectionStatus)

        return $MyJtTblRow
    }

}

Function New-JtRep_Bitlocker {

    [JtRep_Bitlocker]::new() 

}



