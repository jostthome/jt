using module JtInf
using module JtIo
using module JtTbl


class JtInf_Win32Processor : JtInf {

    [JtFld]$Cpu
    [JtFld]$Ghz
    [JtFld]$Cores
    [JtFld]$CoresH

    JtInf_Win32Processor () {
        $This.Cpu = New-JtFld -Label "Cpu"
        $This.Ghz = New-JtFld -Label "Ghz"
        $This.Cores = New-JtFld -Label "Cores"
        $This.CoresH = New-JtFld -Label "CoresH"
    }
}

Function New-JtInf_Win32Processor {
    [JtInf_Win32Processor]::new()
}

Function Get-JtInf_Win32Processor {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Win32Processor]$MyJtInf = New-JtInf_Win32Processor
    
    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [String]$MyName = "Win32_Processor"

    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if ($MyObj) {
        $MyJtInf.Cpu.SetValue($MyObj.Name)
        # [String]$MaxClockSpeed = $MyObj.Get_MaxClockSpeed.ToString("0,0")
        # $MyJtInf.SetObjValue($MyObj, $MyJtInf.Get_Ghz(), $MaxClockSpeed )
        $MyJtInf.Ghz.SetValue($MyObj.MaxClockSpeed)   
        $MyJtInf.Cores.SetValue($MyObj.NumberOfCores)
        $MyJtInf.CoresH.SetValue($MyObj.NumberOfLogicalProcessors)
    }
    return [JtInf_Win32Processor]$MyJtInf
}



Export-ModuleMember -Function Get-JtInf_Win32Processor
Export-ModuleMember -Function New-JtInf_Win32Processor


