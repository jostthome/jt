using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32Computersystem : JtRep {

    JtRep_Obj_Win32Computersystem() : Base("obj.win32_computersystem") {
        $This.ClassName = "JtRep_Obj_Win32Computersystem"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsManu) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsSerial) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion) | Out-Null 
        
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Herst) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Modell) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Ram) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Computername) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Owner) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Domain) | Out-Null 

        return $MyJtTblRow
    }

}

Function New-JtRep_Obj_Win32ComputerSystem {

    [JtRep_Obj_Win32ComputerSystem]::new() 

}


