using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareAdobe : JtRep {

    JtRep_SoftwareAdobe () : Base("software.adobe") {
        $This.ClassName = "JtRep_SoftwareAdobe"
        $This.BlnHideSpezial = $True
    }
    
    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().CreativeSuite_CS6)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Acrobat_DC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Photoshop_CC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Indesign_CC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Illustrator_CC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AfterEffects_CC)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Flash)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Air)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AcrobatReader)
        
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)

        return $MyJtTblRow
    }
}


Function New-JtRep_SoftwareAdobe {

    [JtRep_SoftwareAdobe]::new() 

}


