using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSecurity : JtRep {

    JtRep_SoftwareSecurity() : Base("software.security") {
        $This.ClassName = "JtRep_SoftwareSecurity"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Flash)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Java)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Opsi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AntiVirus)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().CiscoAnyConnect)

        return $MyJtTblRow
    }
}


Function New-JtRep_SoftwareSecurity {

    [JtRep_SoftwareSecurity]::new() 

}


