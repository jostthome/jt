using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Folder : JtRep {

    JtRep_Folder () : Base("report.folders") {
        $This.ClassName = "JtRep_Folder"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = New-JtTblRow
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().SystemId) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Org) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Org1) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Org2) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Type) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Computername) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Alias) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Name) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().LabelC) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().DaysAgo) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().JtVersion) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Timestamp) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinGen) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinBuild) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().KlonVersion) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Ip) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Timestamp) | Out-Null
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().User) | Out-Null
        return $MyJtTblRow
    }
}


Function New-JtRep_Folder {

    [JtRep_Folder]::new() 

}
