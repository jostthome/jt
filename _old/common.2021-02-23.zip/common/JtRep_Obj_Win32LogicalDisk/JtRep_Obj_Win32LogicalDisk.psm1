using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32LogicalDisk : JtRep {

    JtRep_Obj_Win32LogicalDisk() : Base("obj.win32_logicaldisk") {
        $This.ClassName = "JtRep_Win32LogicalDisk"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C_Capacity) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C_Free) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().C_FreePercent) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D_Capacity) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D_Free) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().D_FreePercent) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().E) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().E_Capacity) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().E_Free) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32LogicalDisk().E_FreePercent) | Out-Null 

        return $MyJtTblRow
    }

}

Function New-JtRep_Obj_Win32LogicalDisk {

    [JtRep_Obj_Win32LogicalDisk]::new() 

}


