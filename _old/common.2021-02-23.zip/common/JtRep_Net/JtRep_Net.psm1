using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Net : JtRep {

    JtRep_Net() : Base("report.net") {
        $This.ClassName = "JtRep_Net"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
        
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Ip)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().Ip3)
        # $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Ip3)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32NetworkAdapter().Mac)

        return $MyJtTblRow
    }
}

Function New-JtRep_Net {

    [JtRep_Net]::new() 

}
