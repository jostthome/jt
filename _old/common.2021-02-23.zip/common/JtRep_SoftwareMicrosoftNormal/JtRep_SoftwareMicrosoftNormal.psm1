using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareMicrosoftNormal : JtRep {
    
    JtRep_SoftwareMicrosoftNormal() : Base("software.microsoft.normal") {
        $This.ClassName = "JtRep_SoftwareMicrosoftNormal"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
    
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinGen)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinBuild)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office365)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().OfficeTxt)

        return $MyJtTblRow
    }
    
}




Function New-JtRep_SoftwareMicrosoftNormal {

    [JtRep_SoftwareMicrosoftNormal]::new() 

}
