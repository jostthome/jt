using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32OperatingSystem : JtRep {

    JtRep_Obj_Win32OperatingSystem() : Base("obj.win32_operatingsystem") {
        $This.ClassName = "JtRep_Obj_Win32OperatingSystem"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsManu) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsSerial) | Out-Null 
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion) | Out-Null 
        return $MyJtTblRow
    }

}

Function New-JtRep_Obj_Win32OperatingSystem {

    [JtRep_Obj_Win32OperatingSystem]::new() 

}

