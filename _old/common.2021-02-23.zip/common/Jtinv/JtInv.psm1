using module Jt 
using module JtConfig
using module JtCsv
using module JtIo
using module JtIndex
using module JtMd
using module JtPreisliste
using module JtSnapshot
using module JtTbl
using module JtTemplateFile

class JtInv : JtClass {

    [JtIoFolder]$JtIoFolder_Base
    [JtIoFolder]$JtIoFolderReport
    [String]$SystemId = ""

    JtInv() {
        [JtConfig]$MyJtConfig = New-JtConfig
        $This.ClassName = "JtInv"
        $This.JtIoFolderReport = $MyJtConfig.Get_JtIoFolder_Report()
        $This.JtIoFolder_Base = $MyJtConfig.Get_JtIoFolder_Base()


        $This.DoIt()
    }
    
    DoLogRepoInit() {
        [String]$MyReportLabel = $This.GetReportLabel()
        Write-JtLog -Where $This.ClassName -Text "INIT. REPORT: $MyReportLabel"
    }
    
    DoLogRepoStart() {
        [String]$MyReportLabel = $This.GetReportLabel()
        Write-JtLog -Where $This.ClassName -Text "Starting in REPORT: $MyReportLabel"
    }
    
    [String]GetConfigName() {
        Write-JtError -Where $This.ClassName -Text "GetConfigName. Should be overwritten!!!"
        Throw "GetConfigName. Should be overwritten!!!"
        return ""
    }
    
    [JtIoFolder]GetFolderPathOutput() {
        [JtIoFolder]$MyJtIoFolderReport = $This.JtIoFolderReport
        [JtIoFolder]$MyJtIoFolderOutput = $Null
        
        [String]$MyLabelReport = $This.GetReportLabel()
        if ($MyLabelReport.Length -gt 0) {
            $MyJtIoFolderOutput = $MyJtIoFolderReport.GetJtIoFolder_Sub($MyLabelReport, $True)
        }
        return $MyJtIoFolderOutput
    }

    [String]GetReportLabel() {
        Throw "GetReportLabel should be overwritten!!!"
        return "GetReportLabel is not defined!"
    }

    [Xml]GetConfigXml() {
        [String]$MyConfigName = $This.GetConfigName()
        if ($MyConfigName.Length -lt 1) {
            Write-JtError -Where $This.ClassName -Text "ConfigFolderName not set!"
            Throw "This should not happen."
            return $Null
        }
        
        [String]$MyFileName_Xml = -join ($MyConfigName, ".xml")
        [String]$MyFilePath_Xml = $This.JtIoFolder_Base.GetFilePath($MyFileName_Xml)
        Write-JtLog -Where $This.ClassName -Text "GetConfigXml; FilePathXml: $MyFilePath_Xml"    
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $MyFilePath_Xml
        if ($MyJtIoFile.IsExisting()) {
            [FileElementXml]$MyFileElementXml = [FileElementXml]::new($MyJtIoFile)

            [Xml]$MyXmlContent = $MyFileElementXml.GetXml()
            return $MyXmlContent
        }
        else {
            return $Null
        }
    }

    [Boolean]DoIt() {
        Throw "Report. The method DoIt should be overwritten."
        return $False
    }
}

Function New-JtInvClient {

    New-JtInvClientObjects
    New-JtInvClientSoftware
    New-JtInvClientReport
    New-JtInvClientCsvs
    New-JtInvClientExport
    
    New-JtInvClientTimestamp  -Label "report"
}

class JtInvClientChoco : JtInv {

    JtInvClientChoco() : Base() {
        $This.ClassName = "JtInvClientChoco"
        # Output goes directly to "c:\_inventory\report"
    }
    
    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        
        [String]$MyCommand = ""

        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, [JtIo]::FileExtension_Meta_Choco)
        [JtIoFolder]$MyJtIoFolderOutput = $This.JtIoFolderReport.GetJtIoFolder_Sub("choco", $True)
        [String]$MyOut = $MyJtIoFolderOutput.GetFilePath($MyFilename)
        if ($env:ChocolateyInstall -eq "c:\ProgramData\chocolatey" ) {
            $MyCommand = -join ('cmd.exe /C ', '"', 'choco list -li', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand  
        }
        else {
            $MyCommand = -join ('cmd.exe /C ', '"', 'echo choco is not installed', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand  
        }
        return $True
    }
 
    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "choco"
    }
}

Function New-JtInvClientChoco {



    [JtInvClientChoco]::new()
}

class JtInvClientClean : JtInv {


    JtInvClientClean() : Base() {
        $This.ClassName = "JtInvClientClean"
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [String]$MyFolderPath_C_Inventory_Report = [JtLog]::FolderPath_C_inventory_Report
        If ($This.JtIoFolderReport.IsExisting()) {
            if ($This.JtIoFolderReport.GetPath() -eq $MyFolderPath_C_Inventory_Report) {
                $This.JtIoFolderReport.DoRemoveEverything()
                Write-JtLog -Where $This.ClassName -Text "# LOG Starting client..."
            }
            else {
                [String]$MyMsg = -join ("This should not happen. Illegal path for local report. Should be: ", $MyFolderPath_C_Inventory_Report)
                Write-JtError -Where $This.ClassName -Text $MyMsg
                Throw $MyMsg
            }
            return $True  
        }
        else {
            Throw "This should not happen. c:\_inventory\report is missing."
            return $False
        }
    }
    
    [String]GetConfigName() {
        return ""
    }
    
    [String]GetReportLabel() {
        return "clean"
    }
}

Function New-JtInvClientClean {
    

    [JtInvClientClean]::new()

    New-JtInvClientTimestamp  -Label "clean"
}

class JtInvClientConfig : JtInv {

    [String]$Out = ""
    [String]$XmlFiles = ""

    JtInvClientConfig() : Base() {
        $This.ClassName = "JtInvClientConfig"
    }
    
    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        return $True
    }
    
    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "config"
    }
}

Function New-JtInvClientConfig {

    [JtInvClientConfig]::new()

    New-JtInvClientTimestamp  -Label "config"
}

class JtInvClientCsvs : JtInv {

    JtInvClientCsvs() : Base() {
        $This.ClassName = "JtInvClientCsvs"
        # output goes directly to c:\_inventory\report
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [JtIoFolder]$MyJtIoFolder = $This.JtIoFolderReport
        New-JtCsvGenerator -FolderPath $MyJtIoFolder -Label $This.ClassName

        return $True
    }

    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "csv"
    }
}

Function New-JtInvClientCsvs {

    [JtInvClientCsvs]::new()

    New-JtInvClientTimestamp  -Label "csv"
}

class JtInvClientErrors : JtInv {

    JtInvClientErrors() : Base() {
        $This.ClassName = "JtInvClientErrors"
        # Output goes directly to c:\_inventory\report
    }

    [Boolean]DoCleanErrorFiles() {
        [String]$MyFilter = -join ("*", [JtIo]::FileExtension_Meta_Errors)
        $This.JtIoFolderReport.DoRemoveFiles_All($MyFilter)
        return $True
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        $This.DoCleanErrorFiles()

        [String]$MyLabel = [JtLog]::CounterError
        [String]$MyContent = $MyLabel
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, ".", $MyLabel, [JtIo]::FileExtension_Meta_Errors)
        [String]$MyFolderPath_Output = $This.GetFolderPathOutput().GetPath()
        New-JtIoFile_Meta -FolderPath $MyFolderPath_Output -Filename $MyFilename -Content $MyContent

        return $True
    }


    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "errors"
    }
}

Function New-JtInvClientErrors {


    [JtInvClientErrors]::new()

    New-JtInvClientTimestamp  -Label "errors"
}

class JtInvClientExport  : JtInv {

    JtInvClientExport () : Base() {
        $This.ClassName = "JtInvClientExport"
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [Xml]$MyConfigXml = $This.GetConfigXml()

        if ($Null -eq $MyConfigXml) {
            return $False
        }
        foreach ($entity in $MyConfigXml.getElementsByTagName("export")) {
            [JtIoFolder]$MyJtIoFolderExport = $Null
            [String]$MyTarget = $Entity.target

            if ($MyTarget.Length -gt 0) {
                [JtIoFolder]$MyJtIoFolderExport = [JtIoFolder]::new($MyTarget, $True)
            }
            else {
                [JtIoFolder]$MyJtIoFolderExport = $This.GetFolderPathOutput()
            }
            Write-JtLog -Where $This.ClassName -Text "... Exporting results to: $MyJtIoFolderExport"

            If ($False -eq $MyJtIoFolderExport.IsExisting()) {
                Write-JtError -Where $This.ClassName -Text "Path is missing; MyJtIoFolderExport: $MyJtIoFolderExport"
                return $False
            } 

            [String]$MySystemId = [JtIo]::GetSystemId()
            [JtIoFolder]$MyJtIoFolderOutputSys = $MyJtIoFolderExport.GetJtIoFolder_Sub($MySystemId, $True)
            [String]$MyFolderPath_Output = $MyJtIoFolderOutputSys.GetPath()
            
            [String]$MyInfo = "DoExport in $This.ClassName"
            
            [String]$MyFolderPath_Input = $This.JtIoFolderReport.GetPath()
            New-JtRobocopy -FolderPathInput $MyFolderPath_Input -FolderPathOutput $MyFolderPath_Output -Info $MyInfo
        }
        return $True
    }

    [String]GetConfigName() {
        return "JtInvCLIENT"
    }

    [String]GetReportLabel() {
        return "Export"
    }
}

Function New-JtInvClientExport {


    [JtInvClientExport]::new()
    
    New-JtInvClientTimestamp  -Label "export"
}

class JtInvClientObjects : JtInv {

    JtInvClientObjects() : Base() {
        $This.ClassName = "JtInvClientObjects"
        # output goes directly to c:\_inventory\report
    }

    hidden [Boolean]DoWriteObjectToXml([String]$TheLabel, $TheJtObject) {
        [String]$MyLabel = $TheLabel
        $MyObject = $TheJtObject
        [String]$MyFilename_Xml = -join ($MyLabel.ToLower(), [JtIo]::FileExtension_Xml)

        [String]$MyFilePath_Xml = $This.GetFolderPathOutput().GetFilePath($MyFilename_Xml)
        Write-JtIoFile -Where $This.ClassName -Text "Writing: $MyLabel in FilePathXml" -FilePath $MyFilePath_Xml
        Export-Clixml -InputObject  $MyObject -Path $MyFilePath_Xml
        return $True
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        $MyClass = "Win32_BIOS"
        $MyObject = Get-CimInstance -ClassName Win32_BIOS
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_ComputerSystem"
        $MyObject = Get-CimInstance -ClassName Win32_ComputerSystem
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_Desktop"
        $MyObject = Get-CimInstance -ClassName Win32_Desktop
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_LocalTime"
        $MyObject = Get-CimInstance -ClassName Win32_LocalTime
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_LogicalDisk"
        $MyObject = Get-CimInstance -ClassName Win32_LogicalDisk
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_LogonSession"
        $MyObject = Get-CimInstance -ClassName Win32_LogonSession
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_NetworkAdapter"
        $MyObject = Get-CimInstance -ClassName Win32_NetworkAdapter
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_OperatingSystem"
        $MyObject = Get-CimInstance -ClassName Win32_OperatingSystem
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_Processor"
        $MyObject = Get-CimInstance -ClassName Win32_Processor
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_QuickFixEngineering"
        $MyObject = Get-CimInstance -ClassName Win32_QuickFixEngineering
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_Service"
        $MyObject = Get-CimInstance -ClassName Win32_Service
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "Win32_VideoController"
        $MyObject = Get-CimInstance -ClassName Win32_VideoController
        $This.DoWriteObjectToXml($MyClass, $MyObject)

        $MyClass = "BitLocker"
        [String]$MyLabelCsv = $MyClass.ToLower()
        [String]$MyExtension = [JtIo]::FileExtension_Xml
        [String]$MyFilename_Xml = -join ($MyLabelCsv, $MyExtension)
        [String]$MyFilePath_Xml = $This.GetFolderPathOutput().GetFilePath($MyFilename_Xml)    
        try {
            $MyAlObject = Get-BitLockerVolume

            $MyAlObject | Sort-Object -Property MountPoint | Format-Table -Property * 
        
            [String]$MyFolderPath_Output = $This.GetFolderPathOutput()
            Convert-JtAl_to_FileCsv -ArrayList $MyAlObject -FolderPathOutput $MyFolderPath_Output -Label $MyLabelCsv

            $This.DoWriteObjectToXml($MyClass, $MyAlObject)
            Export-Clixml -InputObject $MyAlObject -Path $MyFilePath_Xml
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "Problems with: BitLockerVolume -> Need admin rights...?"
        }

        return $True
    }

    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "objects"
    }
}

Function New-JtInvClientObjects {


    [JtInvClientObjects]::new()

    New-JtInvClientTimestamp  -Label "objects"
}

class JtInvClientReport : JtInv {
    
    [JtIoFolder]$JtIoFolderOutput

    JtInvClientReport() : Base() {
        $This.ClassName = "JtInvClientReport"
    }

    [Boolean]DoCreateBcdeditMeta() {
        [String]$MyCommand = ""
        # [String]$MyLabel = "systemid"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', 'bcdedit', [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('bcdedit.exe /enum ', ' > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        return $True
    }

    [Boolean]DoCreateDirMetas() {
        [String]$MyFolderPathTest = ""
        [String]$MyCommand = ""
        
        $MyFolderPathTest = "c:\."
        if (Test-JtIoFolderPath -FolderPath $MyFolderPathTest) {
            $MyCommand = $This.GetDirCommand($MyFolderPathTest)
            Invoke-Expression -Command:$MyCommand
        }

        $MyFolderPathTest = "c:\users\."
        if (Test-JtIoFolderPath -FolderPath $MyFolderPathTest) {
            $MyCommand = $This.GetDirCommand($MyFolderPathTest)
            Invoke-Expression -Command:$MyCommand
        }
        
        $MyFolderPathTest = "d:\."
        if (Test-JtIoFolderPath -FolderPath $MyFolderPathTest) {        
            $MyCommand = $This.GetDirCommand($MyFolderPathTest)
            Invoke-Expression -Command:$MyCommand
        }

        $MyFolderPathTest = "e:\."
        if (Test-JtIoFolderPath -FolderPath $MyFolderPathTest) {        
            $MyCommand = $This.GetDirCommand($MyFolderPathTest)
            Invoke-Expression -Command:$MyCommand
        }
        return $True
    }
    
    [Boolean]DoCreateMetas() {
        [String]$MyCommand = ""
        [String]$MyLabel = ""

        [String]$MyContent = "hello world!"
        [String]$MyFolderPath_C_inventory_Report = $This.JtIoFolderReport.GetPath()

        [String]$MyLabel = "version"
        [String]$MyVersion = $This.GetVersion()
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyVersion, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyFilterVersion = -join ("*", '.', $MyLabel, [JtIo]::FileExtension_Meta)
        $This.JtIoFolderReport.DoRemoveFiles_All($MyFilterVersion)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        Set-Content -Path $MyOut -Value $MyContent

        $MyIpInfo = (Get-WmiObject -Class Win32_NetworkAdapterConfiguration | Where-Object { $null -ne $_.DefaultIPGateway }).IPAddress | select-object -first 1 
        [String]$MyIp = $MyIpInfo
        [String]$MyContent = $MyIP
        [String]$MyLabel = "ip"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        Set-Content -Path $MyOut -Value $MyContent

        [String]$MyLabel = "obj"
        [String]$MyIp3 = $MyIp
        [String]$MyContent = $MyIP
        [String]$MyFilename = -join ('ip', '.', $MyIp3, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        Set-Content -Path $MyOut -Value $MyContent

        [String]$MyLabel = "set"
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'set', '"', ' > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "win"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'ver', '"', ' > ' , '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "user"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'echo %username%', '"', ' > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "systemid"
        [String]$MySystemId = [JtIo]::GetSystemId()
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MySystemId, ".", $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'echo %username%', '"', ' > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "obj"
        [String]$MyComputername = [JtIo]::GetComputername()
        [String]$MyFilename = -join ("computer", '.', $MyComputername, ".", $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'echo ', $MyComputername, '"', ' > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "ipconfig"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'ipconfig /all', '"', '   > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "w32tm"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        $MyCommand = -join ('cmd.exe /C ', '"', 'w32tm /stripchart /computer:130.75.1.32 /samples:1', '"', '   > ', '"', $MyOut, '"')
        Invoke-Expression -Command:$MyCommand

        [String]$MyLabel = "wsus"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        try {
            $MyCommand = -join ('reg query ', '"', 'hklm\software\policies\microsoft\windows\windowsupdate', '"', ' /v ', '"', 'wuserver', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand   
        }
        catch {
            $MyCommand = -join ('cmd.exe /C ', '"', 'echo wsus cannot be reported', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand   
        }

        [String]$MyLabel = "choco"
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, [JtIo]::FileExtension_Meta)
        [String]$MyOut = $This.JtIoFolderReport.GetFilePath($MyFilename)
        if ($env:ChocolateyInstall -eq "c:\ProgramData\chocolatey" ) {
            $MyCommand = -join ('cmd.exe /C ', '"', 'choco list -li', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand  
        }
        else {
            $MyCommand = -join ('cmd.exe /C ', '"', 'echo choco is not installed', '"', ' > ', '"', $MyOut, '"')
            Invoke-Expression -Command:$MyCommand  
        }

        [String]$PathPublicDesktop = "c:\users\public\desktop"
        [String]$MyVersionMeta = -join ($PathPublicDesktop, "\*", [JtIo]::FileExtension_Meta)
        if (Test-JtIoFolderPath -FolderPath $MyVersionMeta) {
            $MyCommand = -join ('cmd.exe /C ', '"', 'copy ', $PathPublicDesktop, '\*', [JtIo]::FileExtension_Meta, ' ', $MyFolderPath_C_inventory_Report, '\.', '"')   
            Invoke-Expression -Command:$MyCommand    
        }
        return $True
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        $This.DoCreateMetas()
        $This.DoCreateDirMetas()
        $This.DoCreateBcdeditMeta()
        return $True
    }


    [String]GetConfigName() {
        return "JtInvClientReport"
    }

    [String]GetReportLabel() {
        return "report"
    }

    [String]GetDirCommand([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyResult = ""
        [String]$MyLabel = [JtIo]::ConvertPathToLabel($MyFolderPath)
        [String]$MyFilename = -join ([JtIo]::FilePrefix_Report, '.', $MyLabel, '.', 'dir', [JtIo]::FileExtension_Meta)
        [String]$MyFilePathOutput = $This.JtIoFolderReport.GetFilePath($MyFilename)
        [String]$MyResult = -join ('cmd.exe /C ', '"', 'dir ', $MyFolderPath, ' > ', $MyFilePathOutput, '"')
        return $MyResult
    }
}

Function New-JtInvClientReport {


    [JtInvClientReport]::new()

    New-JtInvClientTimestamp  -Label "report"
}

class JtInvClientSoftware : JtInv {

    JtInvClientSoftware() : Base() {
        $This.ClassName = "JtInvClientSoftware"
        # output goes directly to c:\_inventory\report
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        $MyObject = $NUll
        $MyObject = Get-ItemProperty HKLM:\Software\Microsoft\Windows\CurrentVersion\Uninstall\* | Sort-Object DisplayName 
        $MyClass = "Uninstall64"
        [String]$MyFileName_Xml = -join ($MyClass.ToLower(), ".xml")
        [String]$MyFileNameTxt = -join ($MyClass.ToLower(), ".txt")

        $MyFilePath_Xml = $This.GetFolderPathOutput().GetFilePath($MyFileName_Xml)
        $MyFilePathTxt = $This.GetFolderPathOutput().GetFilePath($MyFileNameTxt)

        Write-JtIoFile -Where $This.ClassName -Text "Writing TXT-File." -FilePath $MyFilePathTxt
        $MyObject | Sort-Object -Property DisplayName | Format-Table -Property DisplayName, DisplayVersion | Out-File -FilePath $MyFilePathTxt

        Write-JtIoFile -Where $This.ClassName -Text "Writing XML-File." -FilePath $MyFilePath_Xml
        Export-Clixml -InputObject  $MyObject -Path $MyFilePath_Xml
        
        $MyObject = Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | Sort-Object DisplayName 	
        $MyClass = "Uninstall32"
        [String]$MyFileName_Xml = -join ($MyClass.ToLower(), ".xml")
        [String]$MyFileNameTxt = -join ($MyClass.ToLower(), ".txt")
        
        $MyFilePath_Xml = $This.GetFolderPathOutput().GetFilePath($MyFileName_Xml)
        $MyFilePathTxt = $This.GetFolderPathOutput().GetFilePath($MyFileNameTxt)

        Write-JtIoFile -Where $This.ClassName -Text "Writing TXT-File." -FilePath $MyFilePathTxt
        $MyObject | Sort-Object -Property DisplayName | Format-Table -Property DisplayName, DisplayVersion | Out-File -FilePath $MyFilePathTxt

        Write-JtIoFile -Where $This.ClassName -Text "Writing XML-File." -FilePath $MyFilePath_Xml
        Export-Clixml -InputObject  $MyObject -Path $MyFilePath_Xml

        return $True
    }


    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "software"
    }
}

Function New-JtInvClientSoftware {


    [JtInvClientSoftware]::new()
    
    New-JtInvClientTimestamp  -Label "software"
}

class JtInvClientTimestamp : JtInv {
    
    [String]$MetaLabel
    
    JtInvClientTimestamp([String]$TheLabel) : Base() {
        $This.ClassName = "JtInvClientTimestamp"
        $This.MetaLabel = $TheLabel
        # Output goes directly to c:\_inventory\report

    }
    
    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        $This.DoCreateMetaFile()
        return $True
    }
    
    [Boolean]DoCreateMetaFile() {
        [String]$MyTimestamp = Get-JtTimestamp
        
        [String]$MyContent = "Hello world!"
        [String]$MyLabelTimestamp = -Join ($MyTimestamp, ".", $This.MetaLabel)
        [String]$MyFilename = Get-JtIoFilename_Meta_Time -Label $MyLabelTimestamp

        [JtIoFolder]$MyJtIoFolderReportTimestamp = $This.JtIoFolderReport.GetJtIoFolder_Sub("timestamp", $True)
        [String]$MyFolderPath_Output = $MyJtIoFolderReportTimestamp.GetPath()

        New-JtIoFile_Meta -FolderPath $MyFolderPath_Output -Filename $MyFilename -Content $MyContent
        return $True
    }
 
    [Boolean]DoCleanTimestamps() {
        [String]$MyFilter = -join ("*", ".", $This.MetaLabel, [JtIo]::FileExtension_Meta_Time)
        Write-Host "DoCleanTimestamps"        
        $This.JtIoFolderReport.DoRemoveFiles_All($MyFilter)
        return $True
    }

    [String]GetConfigName() {
        return ""
    }

    [String]GetReportLabel() {
        return "timestamp"
    }
}

Function New-JtInvClientTimestamp {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [String]$MyLabel = $Label


    [JtInvClientTimestamp]::new($MyLabel)
}

# $mySoftware = Get-JtInstalledSoftware $env:COMPUTERNAME

class JtInvData : JtInv {
    
    [String]$Out = ""
    [String]$Computer
    
    JtInvData() : Base() {
        $This.ClassName = "JtInvData"
        $This.Computer = $env:COMPUTERNAME
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "data"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable

            [String]$MyProperty = "source"
            [String]$MyValue = $Entity.($MyProperty)
            if ($Null -eq $MyValue) { 
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is NULL"
                return $False
            }
            elseif ("" -eq $MyValue) {
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is EMPTY"
                return $False
            }
            elseif (!(Test-JtIoFolderPath -FolderPath $MyValue)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. $MyProperty : $MyValue"
                return $False
            }
            else {
                $MyItem.($MyProperty) = $MyValue
            }

            [String]$MyProperty = "target"
            [String]$MyValue = $Entity.($MyProperty)
            if ($Null -eq $MyValue) { 
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is NULL"
                return $False
            }
            elseif ("" -eq $MyValue) {
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is EMPTY"
                return $False
            }
            elseif (!(Test-JtIoFolderPath -FolderPath $MyValue)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. $MyProperty : $MyValue"
                return $False
            }
            else {
                $MyItem.($MyProperty) = $MyValue
            }
            
            [String]$MyProperty = "target"
            [String]$MyValue = $Entity.($MyProperty)
            if ($Null -eq $MyValue) { 
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is NULL"
                return $False
            }
            elseif ("" -eq $MyValue) {
                Write-JtError -Where $This.ClassName -Text "Error!!! $MyProperty is EMPTY"
                return $False
            }
            else {
                $MyItem.($MyProperty) = $MyValue
            }
            $MyArrayList.Add($MyItem)
        }

        foreach ($MyItem in $MyArrayList) {
            $This.DoWriteTheReport($MyItem.source, $MyItem.target, $MyItem.label)
        }
        return $True
    }

    hidden [Boolean]DoWriteTheReport([String]$TheFolderPathInput, [String]$TheFolderPathOutput, [String]$TheLabel) {
        Write-JtLog -Where $This.ClassName -Text "DoWriteTheReport. TheFolderPathInput: $TheFolderPathInput, TheFolderPathOutput: $TheFolderPathOutput, LABEL: $TheLabel"
        [JtIoFolder]$MyJtIoFolderInput = New-JtIoFolder -FolderPath $TheFolderPathInput
        [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $TheFolderPathOutput
        [String]$MyLabel = $TheLabel
        [String]$MyReportName = -join ("data", ".", $env:COMPUTERNAME.ToLower(), ".", $MyLabel)
        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label $MyReportName

        $MyAlJtIoFoldersFoldersSub = $MyJtIoFolderInput.GetAlJtIoFolders_Sub($False)
        foreach ($Folder in $MyAlJtIoFoldersFoldersSub) {
            [JtIoFolder]$MyJtIoFolder = $Folder
            [JtTblRow]$MyJtTblRow = $This.GetDataLine($MyJtIoFolder.GetPath())
            $MyJtTblTable.AddRow($MyJtTblRow)
        }
        [String]$MyLabel = $MyJtTblTable.GetLabel() 
        [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
        Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel
        return $True
    }

    hidden [JtTblRow]GetDataLine([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        Write-JtLog -Where $This.ClassName -Text "-- GetDataLine, MyFolderPath: $MyFolderPath"
        [JtTblRow]$MyJtTblRow = New-JtTblRow
        $MyResult = $Null
        try {
            $MyResult = Get-ChildItem -Recurse $MyFolderPath | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "GetDataLine. Problem ith MyFolderPath: $MyFolderPath"
        }
    
        $MyJtTblRow.Add("Path", $MyFolderPath)
        if ($Null -eq $MyResult) {
            $MyJtTblRow.Add("Computer", $This.Computer)
    
            $MyJtTblRow.Add("Size", 0)
            $MyJtTblRow.Add("SizeGB", 0)
            $MyJtTblRow.Add("Files", 0)
            $MyJtTblRow.Add("OK", 0)
        }    
        else {
            $MyJtTblRow.Add("Computer", $This.Computer)
            
            $MyJtTblRow.Add("Size", $MyResult.Sum)
            [String]$SizeGb = Convert-JtString_To_Gb -Text $MyResult.Sum
            $MyJtTblRow.Add("SizeGB", $SizeGB)
            $MyJtTblRow.Add("Files", $MyResult.Count)
            $MyJtTblRow.Add("OK", 1)
        }    
        return $MyJtTblRow
    }    

    [String]GetConfigName() {
        return "JtInvDATA"
    }

    [String]GetReportLabel() {
        return "data"
    }
}

Function New-JtInvData {


    [JtInvData]::new()
    
    New-JtInvClientTimestamp -Label "data"
}

class JtInvDownload : JtInv {

    [JtIoFolder]$JtIoFolderDownload

    JtInvDownload() : Base() {
        $This.ClassName = "JtInvDownload"
        $This.JtIoFolderDownload = New-JtIoFolder -FolderPath "C:\_inventory\download" -Force
    }

    hidden [Boolean]DoCleanJtIoFolderDownload() {
        $This.JtIoFolderDownload().DoRemoveFiles_All()
        return $True
    }
    
    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        
        [String]$MyFolderPath = $This.JtIoFolderDownload.GetPath()
        Write-JtLog -Where $This.ClassName -Text "Downloading to: $MyFolderPath"

        # * Download: [apps.exe](https://seafile.projekt.uni-hannover.de/f/b74545092bc24a9c9101/?dl=1)
        # * Download: [apps.zip](https://seafile.projekt.uni-hannover.de/f/d31bffa68e0b445c9194/?dl=1)

        [String]$MyDownloadUrlAppsZip = "https://seafile.projekt.uni-hannover.de/f/d31bffa68e0b445c9194/?dl=1"
        [String]$MyFilenameZip = "apps.zip"
        [String]$MyFolderPath_OutputFileZip = $This.JtIoFolderDownload.GetFilePath($MyFilenameZip)

        (new-object System.Net.WebClient).DownloadFile($MyDownloadUrlAppsZip, $MyFolderPath_OutputFileZip)
        return $True
    }

    [String]GetConfigName() {
        return "JtInvDOWNLOAD"
    }

    [String]GetReportLabel() {
        return "download"
    }

}

Function New-JtInvDownload {


    [JtInvDownload]::new()
    
    New-JtInvClientTimestamp -Label "download"
}

class JtTblFilelist : JtClass {

    #  "NAME.EXTENSION.PATH.PARENT_NAME"


    static [JtTblRow] GetRowForFile2([JtIoFile]$TheJtIoFile) {
        #  "NAME.EXTENSION.PATH.PARENT_NAME"
        [JtIoFile]$MyJtIoFile = $TheJtIoFile
                
        [JtTblRow]$MyJtTblRow = New-JtTblRow
        
        [String]$MyFilename = $MyJtIoFile.GetName()
        $MyJtTblRow.Add("NAME", $MyFileName)
        
        [String]$MyExtension = $MyJtIoFile.GetExtension()
        $MyJtTblRow.Add("EXTENSION", $MyExtension)

        [String]$MyFilePath = $MyJtIoFile.GetPath()
        $MyJtTblRow.Add("PATH", $MyFilePath)

        [JtIoFolder]$MyJtIoFolderParent = $MyJtIoFile.GetJtIoFolder_Parent()
        [String]$MyFoldernameParent = $MyJtIoFolderParent.GetName()
        $MyJtTblRow.Add("PARENT_NAME", $MyFoldernameParent)

        return $MyJtTblRow
    }

    static [JtTblRow] GetRowForFileUsingTemplate([JtIoFile]$TheJtIoFile, [String]$TheFilenameTemplate) {
        [JtTblRow]$MyJtTblRowAll = Convert-JtIoFile_To_JtTblRow -FilePath $TheJtIoFile

        [JtTblRow]$MyJtTblRow = New-JtTblRow
        [String[]]$AlParts = $TheFilenameTemplate.Split(".")

        foreach ($Element in $AlParts) {
            [String]$MyPart = $Element

            [String]$MyValue = $MyJtTblRowAll.GetValue($MyPart)
            $MyJtTblRow.Add($MyPart, $MyValue)
        }
        return $MyJtTblRow
    }


}

class JtInvFiles : JtInv {

    JtInvFiles () : Base() {
        $This.ClassName = "JtInvFiles"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList
        }
        
        [String]$MyTagName = "files"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source = $Entity.source
                target = $Entity.target
                label  = $Entity.label
                filter = $Entity.filter
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid. Problem with item."
                $MyItem
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }
        
        $MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($MyItem in $MyArrayList) {
            [String]$MySource = $MyItem.source
            [String]$MyLabel = $MyItem.label
            [String]$MyTarget = $MyItem.target
            [String]$MyFilter = $MyItem.filter
            
            [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MySource
            [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyTarget -Force
            [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()

            [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter -Recurse

            [Int16]$MyIntCount = $MyAlJtIoFiles.Count
            if ($MyIntCount -gt 0) {
                Write-JtLog -Where $This.ClassName -Text "DoIt... Number of files: $MyIntCount in MyJtIoFolder: $MyJtIoFolder"
                
                [JtTblTable]$MyJtTblTable = Convert-JtAlJtIoFiles_to_JtTblTable -ArrayList $MyAlJtIoFiles -Label $MyLabel
                
                Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel
            }
            else {
                Write-JtError -Where $This.ClassName -Text "DoIt... Nothing to do. Number of files: $MyIntCount in MyJtIoFolder: $MyJtIoFolder"
            }
        }
        return $True
    }


    [String]GetConfigName() {
        return "JtInvFILES"
    }


    [String]GetReportLabel() {
        return "files"
    }
}

Function New-JtInvFiles {


    [JtInvFiles]::new()

    New-JtInvClientTimestamp  -Label "files"
}

class JtInvFolder : JtInv {

    JtInvFolder () : Base() {
        $This.ClassName = "JtInvFolder"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList 
        }

        [String]$MyTagName = "folder"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source  = $Entity.source
                pattern = $Entity.pattern
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList     
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()

        if ($Null -eq $MyConfigXml) {
            Write-JtError -Where $This.ClassName -Text "ConfigXml is NULL"
            return $False
        }

        [System.Collections.ArrayList]$MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($MyItem in $MyArrayList) {
            # [String]$MyJtInfo = $Entity.'#text'

            [JtIoFolder]$MyJtIoFolderInput = New-JtIoFolder -FolderPath $MyItem.source


            [System.Collections.ArrayList]$MyAlFolderTypes = Get-JtIoAlFolderTypes -FolderPath $MyJtIoFolderInput
            Write-JtLog -Where $This.ClassName -Text "Finding Foldertypes"
            $MyAlFolderTypes

            [String]$MyFilter = -join ("*", [JtIo]::FileExtension_Folder)
            [System.Collections.ArrayList]$MyAlJtIoFiles_Folder = Get-JtChildItem -FolderPath $MyJtIoFolderInput -Filter $MyFilter -Recurse 

            [Int16]$MyIntCount = $MyAlJtIoFiles_Folder.Count
            Write-JtLog -Where $This.ClassName -Text "Finding Files. Number of files found MyIntCount: $MyIntCount"

            foreach ($File in $MyAlJtIoFiles_Folder) {
                [JtIoFile]$MyJtIoFile = $File

                Write-JtLog -Where $This.ClassName -Text "Path of *.folder file: $MyJtIoFile"

                [JtFacFolderRen]$MyJtFacFolderRen = [JtFacFolderRen]::new($MyJtIoFile)
                [JtIndex]$MyJtIndex = $MyJtFacFolderRen.GetJtIndex()

                [JtIoFolder]$MyJtIoFolder = $MyJtIoFile.GetJtIoFolder_Parent()
                $MyJtIndex.DoIt($MyJtIoFolder)
            }
        } 
        return $True
    }


    [String]GetConfigName() {
        return "JtInvFolder"
    }

    [String]GetReportLabel() {
        return "folders"
    }


}

Function New-JtInvFolder {


    [JtInvFolder]::new()

    New-JtInvClientTimestamp  -Label "folder"

}

class JtInvLengths : JtInv {

    JtInvLengths() : Base() {
        $This.ClassName = "JtInvLengths"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList 
        }

        [String]$MyTagName = "lengths"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source = $Entity.source
                label  = $Entity.label
                target = $Entity.target
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList     
    }


    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }
        
        [System.Collections.ArrayList]$MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($Item in $MyArrayList) {
            $MyItem = $Item
            [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyItem.source
            [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyItem.target
            [JtTblTable]$MyJtTblTable = $This.GetTable($MyJtIoFolder_Input)
            
            [String]$MyLabel = $MyItem.label
            Write-JtLog -Where $This.ClassName -Text "Label: $MyItem.label, SOURCE: $MyItem.source"
            [String]$MyFolderPath_Output = $MyJtIoFolder_Output.GetPath()
            Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel 
        }
        return $True
    }


    [String]GetConfigName() {
        return "JtInvLENGTHS"
    }

    [String]GetReportLabel() {
        return "lengths"
    }

    [JtTblTable]GetTable([JtIoFolder]$TheJtIoFolder) {
        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label "Lengths"
    
        [JtIoFolder]$MyJtIoFolder = $TheJtIoFolder
        $MyAlJtIoFolders = $MyJtIoFolder.GetAlJtIoFolders_Sub($True)
    
        foreach ($Folder in $MyAlJtIoFolders) {
            [JtIoFolder]$MyJtIoFolder = $Folder
            
            [JtTblRow]$MyJtTblRow = New-JtTblRow
            $MyJtTblRow.Add("Foldername", $MyJtIoFolder.GetName()) | Out-Null
            $MyJtTblRow.Add("Path", $MyJtIoFolder.GetPath()) | Out-Null
            $MyJtTblRow.Add("Length", $MyJtIoFolder.GetPath().Length) | Out-Null
    
            $MyJtTblTable.AddRow($MyJtTblRow) | Out-Null
        }
        return $MyJtTblTable
    }
}

Function New-JtInvLengths {


    [JtInvLengths]::new()
    
    New-JtInvClientTimestamp -Label "lengths"
}

class JtInvLines : JtInv {

    JtInvLines () : Base() {
        $This.ClassName = "JtInvLines"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList 
        }

        [String]$MyTagName = "files"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source = $Entity.source
                target = $Entity.target
                filter = $Entity.filter
                label  = $Entity.label
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList     
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [System.Collections.ArrayList]$MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($MyItem in $MyArrayList) {
            [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyItem.source
            [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyItem.target

            [JtMd]::DoWriteJtMdCsv($MyJtIoFolder, $MyJtIoFolderOutput, $MyItem.label, $MyItem.filter, $MyItem.pattern)
        } 
        return $True
    }

    [String]GetConfigName() {
        return "JtInvLINES"
    }

    [String]GetReportLabel() {
        return "lines"
    }
}

Function New-JtInvLines {


    [JtInvLines]::new()
    
    New-JtInvClientTimestamp  -Label "lines"

}

class JtInvMd : JtInv {

    JtInvMd () : Base() {
        $This.ClassName = "JtInvMd"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList 
        }

        [String]$MyTagName = "md"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source  = $Entity.source
                pattern = $Entity.pattern
                label   = $Entity.label
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList     
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [System.Collections.ArrayList]$MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($MyItem in $MyArrayList) {
            [JtIoFolder]$MyJtIoFolderInput = New-JtIoFolder -FolderPath $MyItem.source
            [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyItem.target

            # <path filter="*.web.md" label="support_index_az" pattern="[\[]({FILELABEL})[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))">D:\Seafile\al-public\SUPPORT</path>
            [String]$Filter = "*.md"
            Write-JtLog -Where $This.ClassName -Text "Filter: $Filter"
            [String]$MyLabel = "JtMd.az"
            Write-JtLog -Where $This.ClassName -Text "Label: $MyItem.label"
            [String]$Pattern = "[\[]({FILELABEL})[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))"
            Write-JtLog -Where $This.ClassName -Text "Pattern: $MyItem.Pattern"
            [JtMd]::DoWriteJtMdCsv($MyJtIoFolderInput, $MyJtIoFolderOutput, $MyItem.label, $MyItem.filter, $MyItem.pattern)
                
            # <path filter="*.web.md" label="support_links" pattern="[\[][A-Za-z0-9_]*[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))">D:\Seafile\al-public</path>
            [String]$MyLabel = "JtMd.links"
            Write-JtLog -Where $This.ClassName -Text "Label: $MyLabel"
            [String]$Pattern = "[\[][A-Za-z0-9_]*[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))"
            Write-JtLog -Where $This.ClassName -Text "Pattern: $Pattern"
            [JtMd]::DoWriteJtMdCsv($MyJtIoFolderInput, $MyJtIoFolderOutput, $MyItem.label, $MyItem.filter, $MyItem.pattern)
        }
        return $True
    }


    [String]GetConfigName() {
        return "JtInvMD"
    }

    [String]GetReportLabel() {
        return "JtMd"
    }
}

Function New-JtInvMd {


    [JtInvMd]::new()
    
    New-JtInvClientTimestamp  -Label "JtMd"
}

class JtInvMirror : JtInv {

    JtInvMirror () : Base() {
        $This.ClassName = "JtInvMirror"
    }

    [System.Collections.ArrayList]GetAlItems() {
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $MyArrayList
        }
        
        [String]$MyTagName = "mirror"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            $MyParams = @{
                source = $Entity.source
                target = $Entity.target
            }
            [HashTable]$MyItem = New-JtConfigItem @MyParams

            if ($MyItem.valid) {
                $MyArrayList.Add($MyItem)
                return $MyArrayList
            }
            else {
                Write-JtError -Where $This.ClassName -Text "Config not valid"
                Throw "Problem with config."
            }
        }
        return $MyArrayList
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [System.Collections.ArrayList]$MyArrayList = $This.GetAlItems()
        [Int]$MyIntCount = $MyArrayList.count
        Write-JtLog -Where $This.ClassName -Text "DoIt. Number of items. MyIntCount: $MyIntCount"
        foreach ($MyItem in $MyArrayList) {
            New-JtRobocopy -FolderPathInput $MyItem.source -FolderPathOutput $MyItem.target
        }
        return $True
    }


    [String]GetConfigName() {
        return "JtInvMIRROR"
    }

        
    [String]GetReportLabel() {
        return "mirror"
    }


}

Function New-JtInvMirror {


    [JtInvMirror]::new()
    
    New-JtInvClientTimestamp  -Label "mirror"
}

class JtInvPoster : JtInv {

    [String]$ExtensionFolder = ".job"

    JtInvPoster () : Base() {
        $This.ClassName = "JtInvPoster"
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "lengths"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable
            
            $MyItem.source = $Entity.source
            if (!(Test-JtIoFolderPath -FolderPath $MyItem.source)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. SOURCE: $MyItem.source"
                return $False
            }
            $MyArrayList.Add($MyItem)
        }
        foreach ($MyItem in $MyArrayList) {
            [JtIoFolder]$MyFolderPath_Input = New-JtIoFolder -FolderPath $MyItem.source
            foreach ($Folder in $MyFolderPath_Input.GetAlJtIoFolders_Sub()) {
                [JtIoFolder]$MyJtIoFolderSub = $Folder
                New-JtIndex_BxH -FolderPath $MyJtIoFolderSub.GetPath()        
            }
        } 
        return $True
    }

    [String]GetConfigName() {
        return "JtInvPOSTER"
    }

    [String]GetReportLabel() {
        return "poster"
    }


}

Function New-JtInvPoster {


    [JtInvPoster]::new()

    New-JtInvClientTimestamp  -Label "poster"
}

class JtInvRecover : JtInv {

    [JtIoFolder]$Folder_C_Inv

    JtInvRecover() : Base() {
        $This.ClassName = "JtInvRecover"
    }
    
    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()

        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "folder"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable
            
            $MyItem.source = $Entity.source
            if (!(Test-JtIoFolderPath -FolderPath $MyItem.source)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. SOURCE: $MyItem.source"
                return $False
            }
            $MyArrayList.Add($MyItem)
        }
        foreach ($MyItem in $MyArrayList) {
            [JtIoFile]$MyJtIoFile_Sna = [JtIoFile]::new($MyItem.source)
            if (!($MyJtIoFile_Sna.IsExisting())) {
                Write-JtError -Where $This.ClassName -Text "Error!!! File missing; please edit XML for MyJtIoFile_Sna: $MyJtIoFile_Sna"
                return $False
            }
            Write-JtLog -Where $This.ClassName -Text "MyJtIoFile_Sna: $MyJtIoFile_Sna"
                        
            [Int32]$MyDisk = $entity.disk
            [Int32]$MyPartition = $entity.partition
            [String]$MyComputer = $entity.computer
            [String]$MySystem = $entity.system
            [Boolean]$MyBlnSystem = $False
            if (("true").Equals($MySystem)) {
                $MyBlnSystem = $True
            }
                    
            Write-JtLog -Where $This.ClassName -Text "Recover JtSnapshot. MyDisk: $MyDisk, MyPartition: $MyPartition, MyComputer: $MyComputer, Local folder: $This.JtIoFolderInput"

            [JtSnap_Recover]$MyJtSnap_Recover = [JtSnap_Recover]::new($MyJtIoFile_Sna, $MyDisk, $MyPartition, $MyComputer, $MyBlnSystem)
            $MyJtSnap_Recover.DoIt()
        }
        return $True
    }

    
    [String]GetConfigName() {
        return "JtInvRECOVER"
    }

    [String]GetReportLabel() {
        return "recover"
    }
}

Function New-JtInvRecover {


    [JtInvRecover]::new()

    New-JtInvClientTimestamp  -Label "recover"
}

class JtInvSnapshot : JtInv {

    JtInvSnapshot() : Base() {
        $This.ClassName = "JtInvSnapshot"
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList

        [Xml]$MyConfigXml = $This.GetConfigXml()

        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "snapshot"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable
            
            $MyItem.target = $Entity.target
            if (!(Test-JtIoFolderPath -FolderPath $MyItem.target)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. TARGET: $MyItem.target"
                return $False
            }
            
            [Int32]$Disk = $Entity.disk
            $MyItem.Disk = $Disk
            
            [Int32]$Partition = $Entity.partition
            $MyItem.Partition = $Partition

            $MyArrayList.Add($MyItem)
        }
        foreach ($MyItem in $MyArrayList) {
            [Int32]$Disk = $entity.disk
            [Int32]$Partition = $entity.partition

            Write-JtLog -Where $This.ClassName -Text "Creating JtSnapshot. Drive: $Disk, Partition: $Partition, Local folder: $MyItem.target"

            [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyItem.target

            [JtSnapshot]$MyJtSnapshot = [JtSnapshot]::new($MyJtIoFolderOutput)
            $MyJtSnapshot.DoJtSnapPart($Disk, $Partition)
        }
        return $True
    }



    [String]GetConfigName() {
        return "JtInvSNAPSHOT"
    }

    [String]GetReportLabel() {
        return "Snapshot"
    }
}

Function New-JtInvSnapshot {


    [JtInvSnapshot]::new()
    
    New-JtInvClientTimestamp  -Label "JtSnapshot"
}

class JtInvWol : JtInv {

    [String]$FilePath_Wol_Exe = "C:\apps\al\archland\tasks\_wol\wol.exe"

    JtInvWol() : Base() {
        $This.ClassName = "JtInvWol"
        # Output goes directly to "c:\_inventory\report"
    }
    
    [Boolean]DoWol($TheName, $TheMac) {
        [String]$MyCommand = ""
        $MyCommand = -join ($This.FilePath_Wol_Exe, ' ', $TheMac)
        Write-JtLog -Where $This.ClassName -Text "Trying to wake device $TheName with MAC:  $TheMac ..."
        Invoke-Expression -Command:$MyCommand

        return $True
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "wol"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable

            $MyItem.device = $entity.'#text'
            if ($Null -eq $MyItem.device) {
                Write-JtError -Where $This.ClassName -Text "Error!!! device is NULL. device: $MyItem.device"
                return $False
            }
            if ($MyItem.device.length -lt 1) {
                Write-JtError -Where $This.ClassName -Text "Error!!! device is "". device: $MyItem.device"
                return $False
            }
        }
        foreach ($MyItem in $MyArrayList) {

            $MyItem.name = $entity.name
            $MyItem.mac = $entity.mac
            $MyItem.ip = $entity.ip

            Write-JtLog -Where $This.ClassName -Text "Name: $MyItem.name, Mac: $MyItem.mac, IP: $MyItem.ip, ... DEVICE: $MyItem.device"
            $This.DoWol($MyItem.Name, $MyItem.Mac)
        }
        return $True
    }
 

    [String]GetConfigName() {
        return "JtInvWOL"
    }

    [String]GetReportLabel() {
        return "wol"
    }



}

Function New-JtInvWol {

    [JtInvWol]::new()

    New-JtInvClientTimestamp  -Label "wol"
}

class JtInvClientCombine : JtInv {

    
    JtInvClientCombine() : Base() {
        $This.ClassName = "JtInvClientCombine"
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            Write-JtLog -Where $This.ClassName -Text "DoIt. No config. Nothing to do."
            return $False
        }

        [String]$MyTagName = "combine"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable
            
            $MyItem.source = $Entity.source
            if (!(Test-JtIoFolderPath -FolderPath $MyItem.source)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. SOURCE: $MyItem.source"
                return $False
            }
            
            $MyItem.target = $Entity.target

            New-JtIoFolder -FolderPath $MyItem.target -Force
            if (!(Test-JtIoFolderPath -FolderPath $MyItem.target)) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing. TARGET: $MyItem.target"
                return $False
            }

            $MyArrayList.Add($MyItem)
        }
        foreach ($MyItem in $MyArrayList) {
            [JtIoFolder]$MyFolderPath_Input = New-JtIoFolder -FolderPath $MyItem.source
            Write-JtLog -Where $This.ClassName -Text "Source: $MyFolderPath_Input"
            [JtIoFolder]$MyJtIoFolderOutput = New-JtIoFolder -FolderPath $MyItem.target
            
            [JtIoFolder]$MyJtIoFolder_Base = $This.JtIoFolder_Base
            [String]$MyFilter = -Join ("*", [JtIo]::FileExtension_Csv)
            [System.Collections.ArrayList]$MyAlSelectionFiles = Get-JtChildItem -FolderPath $MyJtIoFolder_Base -Filter $MyFilter
            if ($MyAlSelectionFiles.Count -gt 0) {
                ForEach ($File in $MyAlSelectionFiles) {
                    [JtIoFile]$MyJtIoFile = $File
                        
                    Write-JtLog -Where $This.ClassName -Text "MyJtIoFile: $MyJtIoFile"
                        
                    [String]$MyColumnName = "SystemId"
                        
                    [JtIoFileCsv]$MyJtIoFileCsv = New-JtIoFile_Csv -FilePath $MyJtIoFile.GetPath()
                    [System.Collections.ArrayList]$MyAlElements = $MyJtIoFileCsv.GetSelection($MyColumnName)
                    $MyAlElements
                        
                    # [String]$SelectionFilename = [System.IO.Path]::GetFileName($SelectionFilePath)
                    [String]$MySelectionFilename = $MyJtIoFileCsv.GetName()
                    $MySelectionNameParts = $MySelectionFilename.Split(".")
                        
                    [String]$MyLabelSelection = $MySelectionNameParts[0]
                        
                    [JtCsvTool]$MyJtCsvTool = [JtCsvTool]::new($MyFolderPath_Input, $MyJtIoFolderOutput, $MyLabelSelection, $MyAlElements)
                    $MyJtCsvTool.DoIt()
                }
            }
            else {
                Write-JtLog -Where $This.ClassName -Text "No selection files."
            }
        
            [JtCsvTool]$MyJtCsvTool = [JtCsvTool]::new($MyFolderPath_Input, $MyJtIoFolderOutput)
            $MyJtCsvTool.DoIt()
        }
        return $False
    }

    [String]GetConfigName() {
        return "JtInvClientCombine"
    }

    [String]GetReportLabel() {
        return "combine"
    }
}

Function New-JtInvClientCombine {

    [JtInvClientCombine]::new()
}

class JtInvClientReports : JtInv {

    JtInvClientReports() : Base() {
        $This.ClassName = "JtInvClientReports"
        $This.DoIt()
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()
        [System.Collections.ArrayList]$MyArrayList = New-Object System.Collections.ArrayList
        
        [Xml]$MyConfigXml = $This.GetConfigXml()
        if ($Null -eq $MyConfigXml) {
            return $False
        }

        [String]$MyTagName = "reports"
        foreach ($Entity in $MyConfigXml.getElementsByTagName($MyTagName)) {
            [HashTable]$MyItem = New-Object HashTable

            $MyItem.source = $Entity.source
            [JtIoFolder]$MyFolderPath_Input = New-JtIoFolder -FolderPath $MyItem.source
            if (!($MyFolderPath_Input.IsExisting())) {
                Write-JtError -Where $This.ClassName -Text "Error!!! Folder missing; please edit XML for MyFolderPathInput: $MyFolderPath_Input"
                return $False
            }
            $MyArrayList.Add($MyItem)
        }

        foreach ($Item in $MyArrayList) {
            [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $Item.source

            $MyAlJtIoSubfolders = $MyFolderPath_Input.GetAlJtIoFolders_Sub()
            foreach ($Folder in $MyAlJtIoSubfolders) {
                [JtIoFolder]$MyJtIoFolder = $Folder
                Write-JtLog -Where $This.ClassName -Text "DoIt for report. MyJtIoFolder: $MyJtIoFolder"
                New-JtCsvGenerator -FolderPath $MyJtIoFolder
            }
        }
        return $True
    }

    [String]GetConfigName() {
        return "JtInvClientReports"
    }
  
    [String]GetReportLabel() {
        return "reports"
    }
}

Function New-JtInvClientReports {

    [JtInvClientReports]::new()

}

class FileElementXml : JtClass {

    hidden [xml]$Xml = $Null
    
    FileElementXml([JtIoFile]$TheJtIoFile) {
        [String]$MyFilePath_Xml = $TheJtIoFile.GetPath()
        [xml]$This.Xml = Get-Content $MyFilePath_Xml -Encoding UTF8
    } 

    [String]GetValuePath() {
        [String]$MyTagName = "path"
        [String]$MyPath = ""
        [xml]$MyXmlContent = $This.GetXml()
        ForEach ($Entity in $MyXmlContent.getElementsByTagName($MyTagName)) {
            [String]$MyPath = $Entity.'#text'
            $MyPath = Convert-JtEnvironmentVariables -Text $MyPath
            return $MyPath
        }
        return $MyPath
    }

    [System.Collections.ArrayList]GetValueListPaths() {
        [System.Collections.ArrayList]$MyAl = [System.Collections.ArrayList]::new()
        [String]$MyTagName = "path"
        [String]$MyPath = ""
        [Xml]$MyXmlContent = $This.GetXml()
        ForEach ($entity in $MyXmlContent.getElementsByTagName($MyTagName)) {
            [String]$MyPath = $entity.'#text'
                
            $MyPath = Convert-JtEnvironmentVariables -Text $MyPath
            $MyAl.Add($MyPath)
        }
        return $MyAl
    }


    [Xml]GetXml() {
        return $This.Xml
    } 
} 

class Gen_Csvs_To_CsvsAll : JtClass {

    [JtIoFolder]$JtIoFolderInput

    static hidden [Boolean]DoJoinCsvs([System.Collections.ArrayList]$TheAlCsvFiles, [JtIoFolder]$TheJtIoFolderOutput, [String]$TheLabel) {

        [JtIoFolder]$MyJtIoFolderOutput = $TheJtIoFolderOutput
        [String]$MyLabel = $TheLabel
        [JtTblTable]$MyJtTblTable = New-JtTblTable -Label $MyLabel
        foreach ($File in $TheAlCsvFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName() 
            if (! ($MyFilename.StartsWith("all"))) {
                $MyFilePathCsv = $MyJtIoFile.GetPath()
                $MyContent = Import-Csv -Path $MyFilePathCsv -Delimiter ([JtClass]::Delimiter)
                $MyContent
                
                [JtTblRow]$MyJtTblRow = New-JtTblRow
                foreach ($Field in $MyContent) {
                    foreach ($Element in $Field | Get-Member) {
                        if ($element.MemberType -eq "NoteProperty") {
                            $Name = $element.Name   
                            [String]$MyFieldLabel = $Element.Name
                            [String]$MyFieldValue = $Field.$Name
    
                            [JtFld]$MyJtFld = New-JtFld -Label $MyFieldLabel
                            $MyJtFld.SetValue($MyFieldValue)
    
                            $MyJtTblRow.Add($MyJtFld)
                        }
                    }
                }
                $MyJtTblTable.AddRow($MyJtTblRow) | Out-Null
            }
        }
        [String]$MyFolderPath_Output = $MyJtIoFolderOutput.GetPath()
        Convert-JtTblTable_To_FileCsv -JtTblTable $MyJtTblTable -FolderPathOutput $MyFolderPath_Output -Label $MyLabel 
        return $True
    }  


    Gen_Csvs_To_CsvsAll([JtIoFolder]$TheJtIoFolderInput) {
        $This.ClassName = "Gen_Csvs_To_CsvsAll"
        $This.JtIoFolderInput = $TheJtIoFolderInput
    }

    [Boolean]DoIt() {
        $This.DoLogRepoStart()

        [JtIoFolder]$MyJtIoFolderCsv = $This.JtIoFolderInput.GetJtIoFolder_Sub("csv")
        [System.Collections.ArrayList]$MyAlCsvFiles = Get-JtChildItem -FolderPath $MyJtIoFolderCsv

        [String]$MyLabel = "all"

        [JtIoFolder]$MyJtIoFolderOutput = $This.JtIoFolderInput
        [Gen_Csvs_To_CsvsAll]::DoJoinCsvs($MyAlCsvFiles, $MyJtIoFolderOutput, $MyLabel)

        return $True
    }
}

Function Get-JtInstalledSoftware {
    Param(
        [Alias('Computer', 'ComputerName', 'HostName')]
        [Parameter(ValueFromPipeline = $True, ValueFromPipelineByPropertyName = $True, Mandatory = $True, Position = 1)]
        [String[]]$Name
    )
    Begin {

        if (!($Name)) {
            $Name = $env:COMPUTERNAME
        }
        $lmKeys = "Software\Microsoft\Windows\CurrentVersion\Uninstall", "SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall"
        $lmReg = [Microsoft.Win32.RegistryHive]::LocalMachine
        $cuKeys = "Software\Microsoft\Windows\CurrentVersion\Uninstall"
        $cuReg = [Microsoft.Win32.RegistryHive]::CurrentUser
    }
    Process {
        if (!(Test-Connection -ComputerName $Name -count 1 -quiet)) {
            Write-JtError -Text "Unable to contact $Name. Please verify its network connectivity and try again." -Category ObjectNotFound -TargetObject $Computer
            Break
        }
        $masterKeys = @()
        $remoteCURegKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($cuReg, $Name)
        $remoteLMRegKey = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey($lmReg, $Name)
        foreach ($key in $lmKeys) {
            $regKey = $remoteLMRegKey.OpenSubkey($key)
            foreach ($subName in $regKey.GetSubkeyNames()) {
                foreach ($sub in $regKey.OpenSubkey($subName)) {
                    $masterKeys += (New-Object PSObject -Property @{
                            "ComputerName"     = $Name
                            "Name"             = $sub.GetValue("displayname")
                            "SystemComponent"  = $sub.GetValue("systemcomponent")
                            "ParentKeyName"    = $sub.GetValue("parentkeyname")
                            "Version"          = $sub.GetValue("DisplayVersion")
                            "UninstallCommand" = $sub.GetValue("UninstallString")
                            "InstallDate"      = $sub.GetValue("InstallDate")
                            "RegPath"          = $sub.ToString()
                        })
                }
            }
        }
        foreach ($key in $cuKeys) {
            $regKey = $remoteCURegKey.OpenSubkey($key)
            if ($Null -ne $regKey) {
                foreach ($subName in $regKey.getsubkeynames()) {
                    foreach ($sub in $regKey.opensubkey($subName)) {
                        $masterKeys += (New-Object PSObject -Property @{
                                "ComputerName"     = $Computer
                                "Name"             = $sub.GetValue("displayname")
                                "SystemComponent"  = $sub.GetValue("systemcomponent")
                                "ParentKeyName"    = $sub.GetValue("parentkeyname")
                                "Version"          = $sub.GetValue("DisplayVersion")
                                "UninstallCommand" = $sub.GetValue("UninstallString")
                                "InstallDate"      = $sub.GetValue("InstallDate")
                                "RegPath"          = $sub.ToString()
                            })
                    }
                }
            }
        }
        $woFilter = { $null -ne $_.name -AND $_.SystemComponent -ne "1" -AND $null -eq $_.ParentKeyName }
        $props = 'Name', 'Version', 'ComputerName', 'Installdate', 'UninstallCommand', 'RegPath'
        $masterKeys = ($masterKeys | Where-Object $woFilter | Select-Object $props | Sort-Object Name)
        $masterKeys
    }
    End { }
}

Function New-JtInvVersion {
    New-JtRobocopy -FolderPathInput "%OneDrive%\0.INVENTORY\common" -FolderPathOutput "D:\Seafile\al-apps\apps\inventory\common"

    [String]$MyLabel = Get-JtTimestamp
    New-JtIoFile_Meta -FolderPath "%OneDrive%\0.INVENTORY\common" -Label $MyLabe
}


Function Get-JtTblRowForFile {
        
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FilePath
    )#  "NAME.EXTENSION.PATH.PARENT_NAME"

    [JtTblRow]$MyJtIoFile = New-JtIoFile -Filepath $FilePath
    [JtTblRow]$MyJtTblRow = New-JtTblRow
            
    [String]$MyFilename = $MyJtIoFile.GetName()
    Write-JtLog -Text "---------------Filename: $MyFilename"
    $MyContent = Get-Content $MyJtIoFile.GetPath()
    
    [String]$MyFolderPath = $MyContent
    if (($MyFolderPath.length -gt 0) -and (Test-JtIoFolderPath -FolderPath $MyFolderPath)) {
        [String]$MyExtension = $MyJtIoFile.GetExtension()
        [String]$MyFilePath = $MyJtIoFile.GetPath()
        [JtIoFolder]$MyJtIoParentFolder = New-JtIofolder -FolderPath $MyFolderPath 
        [String]$MyFoldernameParent = $MyJtIoParentFolder.GetName()
        # [String]$MyParentId = Convert-JtDotter -Text $MyFoldernameParent -PatternOut "1"
            
        # $MyJtTblRow.Add("PARENT_ID", $MyParentId)
    
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "2"
        $MyValue = $Mypart
        $MyJtTblRow.Add("ID1", $MyValue)
                 
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "3"
        $MyValue = $Mypart
        $MyJtTblRow.Add("ID2", $MyValue)
    
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "4"
        $MyValue = $Mypart
        $MyJtTblRow.Add("JAHR", $MyValue)
    
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "5"
        $MyValue = $Mypart
        $MyValue = $MyPart.Replace("_", ",")
        $MyJtTblRow.Add("BETRAG", $MyValue)
    
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "6"
        $MyValue = $Mypart
        $MyJtTblRow.Add("JAHR", $MyValue)
    
        [String]$MyPart = Convert-JtDotter -Text $MyFilename -PatternOut "7"
        $MyValue = $Mypart
        $MyJtTblRow.Add("JAHR", $MyValue)
    
        $MyJtTblRow.Add("NAME", $MyFileName)
        $MyJtTblRow.Add("PARENT_NAME", $MyFoldernameParent)
        
        $MyJtTblRow.Add("EXTENSION", $MyExtension)
        $MyJtTblRow.Add("PATH", $MyFilePath)
    }
    else {
        return $Null
    }
    return $MyJtTblRow
}
    


# https://github.com/ThePoShWolf/Utilities/blob/master/Misc/Get-JtInstalledSoftware.ps1
<#
.SYNOPSIS
	Get-JtInstalledSoftware retrieves a list of installed software
.DESCRIPTION
	Get-JtInstalledSoftware opens up the specified (remote) registry and scours it for installed software. When found it returns a list of the software and it's version.
.PARAMETER ComputerName
	The computer from which you want to get a list of installed software. Defaults to the local host.
.EXAMPLE
	Get-JtInstalledSoftware DC1
	
	This will return a list of software from DC1. Like:
	Name			Version		Computer  UninstallCommand
	----			-------     --------  ----------------
	7-Zip 			9.20.00.0	DC1       MsiExec.exe /I{23170F69-40C1-2702-0920-000001000000}
	Google Chrome	65.119.95	DC1       MsiExec.exe /X{6B50D4E7-A873-3102-A1F9-CD5B17976208}
	Opera			12.16		DC1		  "C:\Program Files (x86)\Opera\Opera.exe" /uninstall
.EXAMPLE
	Import-Module ActiveDirectory
	Get-ADComputer -filter 'name -like "DC*"' | Get-JtInstalledSoftware
	
	This will get a list of installed software on every AD computer that matches the AD filter (So all computers with names starting with DC)
.INPUTS
	[string[]]Computername
.OUTPUTS
	PSObject with properties: Name,Version,Computer,UninstallCommand
.NOTES
	Author: ThePoShWolf
	
	To add registry directories, add to the lmKeys (LocalMachine)
.LINK
	[Microsoft.Win32.RegistryHive]
    [Microsoft.Win32.RegistryKey]
    https://github.com/theposhwolf/utilities
#>


Function New-JtConfigItem {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Source,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Target,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Filter,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Pattern
    )

    [String]$MyFunctionName = "New-JtConfigItem"

    [HashTable]$MyItem = New-Object HashTable
    $MyItem.valid = $True

    if ($source) {
        $MyItem.source = $source
        if (!(Test-JtIoFolderPath -FolderPath $MyItem.source)) {
            Write-JtError -Where $MyFunctionName -Text "Error!!! Folder missing. SOURCE: $MyItem.source"
            $MyItem.valid = $False
            return $MyItem
        }
    }

    
    if ($target) {
        $MyItem.target = $target

        [String]$MyFolderPath_Output = $MyItem.target
        [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
        if (!($MyJtIoFolder_Output.IsExisting())) {
            Write-JtError -Where $MyFunctionName -Text "Error!!! Folder missing. TARGET: $MyItem.target"
            $MyItem.valid = $False
            return $MyItem
        }
    }

    if ($pattern) {
        $MyItem.pattern = $pattern
        if ($pattern.length -lt 1) {
            Write-JtError -Where $MyFunctionName -Text "Error!!! PATTERN is empty."
            $MyItem.valid = $False
            return $MyItem
        }
    }

    if ($label) {
        $MyItem.label = $label
        if ($label.length -lt 1) {
            Write-JtError -Where $MyFunctionName -Text "Error!!! LABEL is EMPTY."
            $MyItem.valid = $False
            return $MyItem
        }
    }

    if ($filter) {
        $MyItem.filter = $filter
        if ($filter.length -lt 1) {
            Write-JtError -Where $MyFunctionName -Text "Error!!! FILTER is EMPTY."
            $MyItem.valid = $False
            return $MyItem
        }
    }

    return $MyItem
}



Function Get-JtXmlReportObject {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Name
    )


    [String]$MyFunctionName = "Get-JtXmlReportObject"

    if (!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $Null
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [JtIoFolder]$MyName = $Name

    [System.Object]$MyObject = $Null

    Write-JtLog -Where $MyFunctionName -Text "MyJtIoFolder: $MyJtIoFolder - MyName: $MyName"
    
    [JtIoFolder]$MyJtIoFolder_Xml = $MyJtIoFolder.GetJtIoFolder_Sub("objects")
    if (!($MyJtIoFolder_Xml.IsExisting())) {
        Write-JtError -Where $MyFunctionName -Text "MyName: $MyName - Object is missing in MyJtIoFolder_Xml: $MyJtIoFolder_Xml"
        return $Null
    }
    
    [String]$MyExtension = [JtIo]::FileExtension_Xml
    [String]$MyFilename_Xml = -Join ($MyName, $MyExtension)
    [String]$MyFilePath_Xml = $MyJtIoFolder_Xml.GetFilePath($MyFilename_Xml)
    
    Write-JtLog -Where $MyFunctionName -Text "MyName: $MyName - MyFilePath_Xml: $MyFilePath_Xml"
    if (!(Test-JtIoFilePath -FilePath $MyFilePath_Xml)) {
        Write-JtError -Where $MyFunctionName -Text "MyName: $MyName - Xml file is missing in MyFilePath_Xml: $MyFilePath_Xml"
        return $Null
    }
    [System.Object]$MyObject = $Null
    try {
        $MyObject = Import-Clixml $MyFilePath_Xml
    }
    catch {
        Write-JtError -Where $MyFunctionName -Text "MyName: $MyName - Problem while reading MyFilePath_Xml: $MyFilePath_Xml"
        return $Null
    }
    return [System.Object]$MyObject
}





Export-ModuleMember -Function Get-JtInstalledSoftware
Export-ModuleMember -Function Get-JtXmlReportObject

Export-ModuleMember -Function New-JtConfigItem

Export-ModuleMember -Function New-JtInvClient
Export-ModuleMember -Function New-JtInvClientChoco 
Export-ModuleMember -Function New-JtInvClientClean
Export-ModuleMember -Function New-JtInvClientCombine
Export-ModuleMember -Function New-JtInvClientConfig
Export-ModuleMember -Function New-JtInvClientCsvs
Export-ModuleMember -Function New-JtInvClientErrors
Export-ModuleMember -Function New-JtInvClientExport
Export-ModuleMember -Function New-JtInvClientObjects
Export-ModuleMember -Function New-JtInvClientReport
Export-ModuleMember -Function New-JtInvClientReports
Export-ModuleMember -Function New-JtInvClientSoftware
Export-ModuleMember -Function New-JtInvClientTimestamp
Export-ModuleMember -Function New-JtInvData
Export-ModuleMember -Function New-JtInvDownload
Export-ModuleMember -Function New-JtInvFiles
Export-ModuleMember -Function New-JtInvFolder
Export-ModuleMember -Function New-JtInvLengths
Export-ModuleMember -Function New-JtInvLines
Export-ModuleMember -Function New-JtInvMd
Export-ModuleMember -Function New-JtInvMirror
Export-ModuleMember -Function New-JtInvPoster
Export-ModuleMember -Function New-JtInvRecover
Export-ModuleMember -Function New-JtInvSnapshot
Export-ModuleMember -Function New-JtInvWol
Export-ModuleMember -Function New-JtInvVersion