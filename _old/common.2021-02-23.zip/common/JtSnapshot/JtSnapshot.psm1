using module Jt  
using module JtIo

class JtSnap : JtClass {
    
    hidden [String]$FolderPathToolsSource = "\\oslo\Snap$\_archland\tools"
    hidden [String]$FolderPathTools = "C:\_archland\tools"
    hidden [String]$FilePath_Exe_Snapshot = "C:\_archland\tools\Snapshot64.exe"
    hidden [String]$ShutdownExe = "C:\Windows\System32\shutdown.exe"

    JtSnap () {
        $This.ClassName = "JtSnap"
    }

    [Boolean]DoPrepareTools() {
        [String]$MyFolderPath_Input = $This.FolderPathToolsSource
        [String]$MyFolderPath_Output = $This.FolderPathTools

        New-JtRobocopy -FolderPathInput $MyFolderPath_Input -FolderPathOutput $MyFolderPath_Output

        [JtIoFile]$MyJtIoFile_SnaphotExe = [JtIoFile]::new($This.FilePath_Exe_Snapshot)
        if ($False -eq $MyJtIoFile_SnaphotExe.IsExisting()) {
            Write-JtError -Where $This.ClassName -Text "Snapshot64.exe does not exist at MyJtIoFile_SnaphotExe: $MyJtIoFile_SnaphotExe"
            return $False
        }
        return $True
    }
}

class JtSnap_Partition : JtSnap {

    [String]$MyName
    [String]$MyPartition

    JtSnap_Partition([Int32]$Disk, [Int32]$Part, [String]$Comment) {
        $This.ClassName = "JtSnap_Partition"
        $This.MyName = $Comment
        
        # $MyPartition = "HD2:1"
        $This.MyPartition = -join ("HD", $Disk, ":", $Part)
    }
    
    JtSnap_Partition([Int32]$Disk, [Int32]$Part) {
        $This.ClassName = "JtSnap_Partition"
        $This.MyName = -join ("HD", $Disk, "", $Part)

        # $MyPartition = "HD2:1"
        $This.MyPartition = -join ("HD", $Disk, ":", $Part)
    }

    

    [Boolean]DoIt([JtIoFolder]$TheJtIoFolderSnap) {
        [JtIoFolder]$MyJtIoFolderSnap = $TheJtIoFolderSnap
        [String]$MySnapshotExe = $This.FilePath_Exe_Snapshot

        [Boolean]$MyBlnToolsPrepared = $This.DoPrepareTools()
        if (! ($MyBlnToolsPrepared)) {
            return $False
        }


        [JtTimer]$MyJtTimer = [JtTimer]::new( -Join ("JtSnap", $This.MyName))

        if ($False -eq $MyJtIoFolderSnap.IsExisting()) {
            Write-JtError -Where $This.ClassName -Text "Folder does not exist MyJtIoFolderSnap: $MyJtIoFolderSnap"
            return $False
        }
        
        [JtIoFolder]$MyJtIoFolder_SnapComputer = $MyJtIoFolderSnap.GetJtIoFolder_Sub($env:COMPUTERNAME)
        [JtIoFolder]$MyJtIoFolder_SnapComputerPart = $MyJtIoFolder_SnapComputer.GetJtIoFolder_Sub($This.MyName)
        $MyJtIoFolder_SnapComputerPart.DoRemoveFiles_All()
        
        [String]$MyFilename_Image = -join ($This.MyName, ".sna")
        [String]$MyFilePath_Image = $MyJtIoFolder_SnapComputerPart.GetFilePath($MyFilename_Image)
    
        $MyCommand = -Join ($This.MyPartition, " ", $MyFilePath_Image, " -Go -R")
        if (Get-JtDevMode) {
            Write-JtLog -Where $This.ClassName -Text "Snapshot.exe: $MySnapshotExe, Command: $MyCommand"
        }
        else {
            Start-Process -FilePath $MySnapshotExe -ArgumentList $MyCommand -NoNewWindow -Wait
        }
        
        $MyTstamp = Get-Date -Format yyyy-MM-dd
        [String]$MyFilename_Tstamp = -join ("JtSnapshot.", $MyTstamp, ".tstamp", [JtIo]::FileExtension_Meta)
        [String]$MyFilePath_Tstamp = $MyJtIoFolder_SnapComputerPart.GetFilePath($MyFilename_Tstamp)
        Out-File -FilePath $MyFilePath_Tstamp
        
        [String]$MySize = $MyJtIoFolder_SnapComputerPart.GetFolderSize()
        $MySize = $MySize.replace('.', '_')
        $MySize = $MySize.replace(',', '_')
        $MySize = $MySize.replace(' ', '')
        [String]$MyFilename_Size = -join ("JtSnapshot.", $MySize, ".size", [JtIo]::FileExtension_Meta)
        [String]$MyFilePath_Size = $MyJtIoFolder_SnapComputerPart.GetFilePath($MyFilename_Size)
        Out-File -FilePath $MyFilePath_Size
    
        $MyJtTimer.Report()
        return $True
    }
}

class JtSnap_Recover : JtSnap {
    
    [JtIofile]$SnaFile = $Null
    [String]$Computer = ""
    [String]$MyName = ""
    [Int32]$Disk = 0
    [Int32]$Part = 0
    # [String]$MyPartition
    [Boolean]$System = $False

    JtSnap_Recover([JtIoFile]$MySnaFile, [Int32]$MyDisk, [Int32]$MyPart, [String]$TheComputer) {
        $This.ClassName = "JtSnap_Partition"
        $This.Disk = $MyDisk
        $This.Part = $MyPart
        $This.Computer = $TheComputer
        $This.MyName = -join ("HD", $This.Disk, "", $This.Part)

        $This.SnaFile = $MySnaFile
        $This.System = $False
        
        # $MyPartition = "HD2:1"
        # $This.MyPartition = -join ("HD", $Disk, ":", $Part)
    }
    
    JtSnap_Recover([JtIoFile]$MySnaFile, [Int32]$MyDisk, [Int32]$MyPart, [String]$TheComputer, [Boolean]$IsSystem) {
        $This.ClassName = "JtSnap_Partition"
        $This.Disk = $MyDisk
        $This.Part = $MyPart
        $This.Computer = $TheComputer
        $This.MyName = -join ("HD", $This.Disk, "", $This.Part)

        $This.SnaFile = $MySnaFile
        $This.System = $IsSystem

        # $MyPartition = "HD2:1"
        # $This.MyPartition = -join ("HD", $Disk, ":", $Part)
    }

    [Boolean]DoIt() {
        [String]$TheSnapshotExe = $This.FilePath_Exe_Snapshot
        if ($False -eq $This.DoPrepareTools()) {
            return $False
        }

        [String]$ImageFilePath = $This.SnaFile.GetPath()

        [String]$TheCommandNormal = -Join (" ", $ImageFilePath, " ", "hd", $This.Disk, ":", $This.Part, " ", "-y")
        [String]$TheCommandSystem = -Join (" ", "C:", " ", $ImageFilePath, " ", "--schedule", " ", "--autoreboot:success")

        [String]$TheCommand = ""
        if ($True -eq $This.System) {
            $TheCommand = $TheCommandSystem
        }
        else {
            $TheCommand = $TheCommandNormal
        }
        Write-JtLog -Where $This.ClassName -Text "Snapshot.exe: $TheSnapshotExe, Command: $TheCommand"
        if (Get-JtDevMode) {
            Write-JtLog -Where $This.ClassName -Text "Doing nothing. This is a dev system."
        }
        else {
            Start-Process -FilePath $This.FilePath_Exe_Snapshot -ArgumentList $TheCommand -NoNewWindow -Wait
            if ($True -eq $This.System) {
                $TheCommand = -join ('/c', ' ', '"', 'Computer wird neu gestartet. System wird recovered.', '"', ' ', '/r')
                #                Start-Process -FilePath $This.ShutdownExe -ArgumentList $TheCommand -NoNewWindow -Wait
            }
        }
        return $True
    }
}

class JtSnapshot : JtClass {

    [JtIoFolder]$JtIoFolderOutput
    [String]$ServerShare = '\\al-its-se-oslo\Snap$'

    JtSnapshot([JtIoFolder]$TheJtIoFolderOutput) : Base() {
        $This.ClassName = "JtSnapshot"
        $This.JtIoFolderOutput = $TheJtIoFolderOutput
    }

    [Boolean]DoJtSnapPart([Int32]$TheDisk, [Int32]$ThePart) {
        [JtSnap_Partition]$MyJtSnap_Partition = [JtSnap_Partition]::new($TheDisk, $ThePart)
        $MyJtSnap_Partition.DoIt($This.JtIoFolderOutput)
        return $True
    }
}

