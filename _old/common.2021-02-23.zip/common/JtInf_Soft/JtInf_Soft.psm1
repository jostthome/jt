using module Jt  
using module JtInf
using module JtIo
using module JtTbl

enum JtSoftSrc {
    InstalledSoftware = 0
    Un32 = 32
    Un64 = 64
}


class JtFldSoft : JtFld {

    hidden [JtSoftSrc]$JtSoftSrc
    hidden [String]$Search = ""

    JtFldSoft([String]$MyLabel, [JtSoftSrc]$TheJtSoftSrc, [String]$TheSearch) : base($MyLabel) {
        $This.Label = $MyLabel
        switch ($TheJtSoftSrc) {
            ([JtSoftSrc]::InstalledSoftware) { 
                $This.JtSoftSrc = [JtSoftSrc]::InstalledSoftware
            } 
            ([JtSoftSrc]::Un32) { 
                $This.JtSoftSrc = [JtSoftSrc]::Un32
            } 
            ([JtSoftSrc]::Un64) { 
                $This.JtSoftSrc = [JtSoftSrc]::Un64
            } 
            default {
                Write-Host "This should not happen! Error with JtFldSoft"
                Exit
            }
        }
        $This.Search = $TheSearch
    }

    SetJtSoftSrc([JtSoftSrc]$TheJtSoftSrc) {
        $This.JtSoftSrc = $TheJtSoftSrc
    } 

    [String]GetSearch() {
        return $This.Search
    } 

    [JtSoftSrc]GetJtSoftSrc() {
        return $This.JtSoftSrc
    } 
 

    SetValue([String]$TheValue) {
        $This.Value = $TheValue
    } 
    
    [String]GetLabel() {
        return $This.Label
    } 
    
    [String]GetValue() {
        return $This.Value
    } 
}

Function New-JtFldSoft {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtSoftSrc]$JtSoftSrc,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Search
    )

    [String]$MyLabel = $Label
    [JtSoftSrc]$MyJtSoftSrc = $JtSoftSrc
    [String]$MySearch = $Search
    
    [JtFldSoft]::new($MyLabel, $MyJtSoftSrc, $MySearch)
}


class JtInf_Soft : JtInf {

    [String]$ClassName = "JtInf_Soft"

    [JtFldSoft]$Acrobat_DC
    [JtFldSoft]$AcrobatReader
    [JtFldSoft]$AdobeCreativeCloud
    [JtFldSoft]$AfterEffects_CC
    [JtFldSoft]$AffinityDesigner
    [JtFldSoft]$AffinityPhoto
    [JtFldSoft]$AffinityPublisher
    [JtFldSoft]$Air
    # [JtFldSoft]$Allplan_2012
    [JtFldSoft]$Allplan_2019
    [JtFldSoft]$AntiVirus
    [JtFldSoft]$ArchiCAD
    [JtFldSoft]$Arduino
    # [JtFldSoft]$ASBwin
    [JtFldSoft]$AutoCAD_2021
    [JtFldSoft]$Bacula
    [JtFldSoft]$BkiKosten
    [JtFldSoft]$BkiPos
    [JtFldSoft]$Chrome
    [JtFldSoft]$Chromium
    [JtFldSoft]$Cinema4D
    [JtFldSoft]$CiscoAnyConnect
    [JtFldSoft]$CorelDRAW
    [JtFldSoft]$CreativeSuite_CS6
    [JtFldSoft]$DellCommand
    [JtFldSoft]$DellSuppAs
    [JtFldSoft]$DokanLibrary
    [JtFldSoft]$DriveFs
    [JtFldSoft]$Firefox32
    [JtFldSoft]$Firefox64
    [JtFldSoft]$Flash
    [JtFldSoft]$Foxit
    [JtFldSoft]$Gimp
    [JtFldSoft]$GoogleEarth
    [JtFldSoft]$Grafiktreiber
    [JtFldSoft]$IbpHighend
    [JtFldSoft]$Illustrator_CC
    [JtFldSoft]$Indesign_CC
    [JtFldSoft]$Inkscape
    [JtFldSoft]$IntelME
    [JtFldSoft]$IntelNET
    [JtFldSoft]$IrfanView
    [JtFldSoft]$Java
    [JtFldSoft]$Krita
    [JtFldSoft]$Laubwerk
    [JtFldSoft]$LenovoSysUp
    [JtFldSoft]$LibreOffice
    [JtFldSoft]$Lightroom_CC
    [JtFldSoft]$LUH_Rotis
    [JtFldSoft]$Max_2021
    [JtFldSoft]$NotepadPP
    [JtFldSoft]$OBS
    [JtFldSoft]$Office
    [JtFldSoft]$Office365
    [JtFldSoft]$OfficeStandard
    [JtFldSoft]$OfficeTxt
    [JtFldSoft]$OPSI
    [JtFldSoft]$Orca
    [JtFldSoft]$PDF24
    [JtFldSoft]$Photoshop_CC
    [JtFldSoft]$Powertoys
    [JtFldSoft]$Premiere_CC
    [JtFldSoft]$Project
    [JtFldSoft]$RawTherapee
    [JtFldSoft]$Revit_2020
    [JtFldSoft]$Revit_2021
    [JtFldSoft]$Rhino_6
    [JtFldSoft]$Seadrive
    [JtFldSoft]$Seafile
    [JtFldSoft]$ServerViewAgents
    [JtFldSoft]$Silverlight
    [JtFldSoft]$Sketchup
    [JtFldSoft]$Sumatra
    [JtFldSoft]$Thunderbird32
    [JtFldSoft]$Thunderbird64
    [JtFldSoft]$Unity
    [JtFldSoft]$UnityHub
    [JtFldSoft]$Vectorworks
    [JtFldSoft]$VLC
    [JtFldSoft]$vRay3ds
    [JtFldSoft]$vRayRevit
    [JtFldSoft]$vRayRhino
    [JtFldSoft]$vRaySketchup
    [JtFldSoft]$VSCodium
    [JtFldSoft]$VSCode
    [JtFldSoft]$WebEx
    [JtFldSoft]$WibuKey
    [JtFldSoft]$Zip7

    [JtFldSoft]$prn_4201_000_b006_1 
    [JtFldSoft]$prn_4201_001_a113_1 
    [JtFldSoft]$prn_4201_001_a133_1 
    [JtFldSoft]$prn_4201_u01_bu150_1
    [JtFldSoft]$prn_4201_u01_bu177_1
    
    
    static [String]GetLabelForOffice([String]$Version) {
        [String]$MyResult = ""
        if ($Null -eq $Version) {
            
        }
        else {
            [String[]]$Parts = $Version.Split(".")
            if ($Parts.Count -gt 2) {
                [String]$Part = $Parts[0]
                # [String]$Part2 = $Parts[1]
                [String]$Part3 = $Parts[2]
                switch ($Part) {
                    "v12" { 
                        $MyResult = "Office2007"
                    } 
                    "v13" { 
                        $MyResult = "Office2010"
                    } 
                    "v15" { 
                        $MyResult = "Office2013"
                    } 
                    "v16" { 
                        if ($Part3 -eq "4266") {
                            $MyResult = "Office2016"
                        }
                        elseif ($Part3 -eq "10370") {
                            $MyResult = "Office2019"
                        }
                        elseif ($Part3 -eq "10827") {
                            $MyResult = "Office2019"
                        }
                        elseif ($Part3 -eq "10349") {
                            $MyResult = "Office365"
                        }
                        else {
                            $MyResult = "OfficeXXX"
                            Write-JtError -Text "GetLabelForOffice. Cannot detect Office Version. VERSION: $Version"
                        }
                    } 
                    default {
                        $MyResult = $Version
                    }
                }
            }
        }
        return $MyResult
    }


    static [System.Collections.ArrayList]GetFilteredArrayList([System.Collections.ArrayList]$MyArray, [String]$FilterProperty) {
        [System.Collections.ArrayList]$Re = [System.Collections.ArrayList]::new()
 
        if ($Null -eq $MyArray) {
            Write-Host "GetFilteredArrayList;  ArrayList is null ------------------------------------"
            return $Re
        }
        # [Int32]$h = $MyArray.Count
        [Int32]$i = 0
        [Int32]$j = 0
 
        foreach ($MySys in $MyArray) {
            $El = $MySys | Get-Member | Where-Object { $_.name -like $FilterProperty }
            if ($Null -ne $El) {
                $Re.add($MySys)
                $j = $j + 1
            }
            $i = $i + 1
        }
        return $re
    }

    JtInf_Soft() {
        $This.ClassName = "JtInf_Soft"
        $This.Acrobat_DC = New-JtFldSoft -Label "Acrobat_DC" -JtSoftSrc Un32 -Search "Adobe Acrobat DC*"
        $This.AcrobatReader = New-JtFldSoft -Label "AcrobatReader" -JtSoftSrc Un32 -Search "Adobe Acrobat Reader *"
        $This.AdobeCreativeCloud = New-JtFldSoft -Label "AdobeCreativeCloud" -JtSoftSrc Un32 -Search "Adobe Creative Cloud*"
        $This.AfterEffects_CC = New-JtFldSoft -Label "AfterEffects_CC" -JtSoftSrc Un32 -Search "Adobe After Effects 2020*"
        $This.AffinityDesigner = New-JtFldSoft -Label "AffinityDesigner" -JtSoftSrc Un64 -Search "Affinity Designer*"
        $This.AffinityPhoto = New-JtFldSoft -Label "AffinityPhoto" -JtSoftSrc Un64 -Search "Affinity Photo*"
        $This.AffinityPublisher = New-JtFldSoft -Label "AffinityPublisher" -JtSoftSrc Un64 -Search "Affinity Publisher*"
        $This.Air = New-JtFldSoft -Label "Air" -JtSoftSrc Un32 -Search "Adobe AIR*"
        # $This.Allplan_2012 = New-JtFldSoft -Label "Allplan_2012" -JtSoftSrc Un32 -Search "Allplan 2012*"
        $This.Allplan_2019 = New-JtFldSoft -Label "Allplan_2019" -JtSoftSrc Un32 -Search "Allplan 2019*"
        $This.AntiVirus = New-JtFldSoft -Label "AntiVirus" -JtSoftSrc Un32 -Search "Sophos Anti-Virus*"
        $This.ArchiCAD = New-JtFldSoft -Label "ArchiCAD" -JtSoftSrc Un64 -Search "ARCHICAD *"
        $This.Arduino = New-JtFldSoft -Label "Arduino" -JtSoftSrc Un32 -Search "Arduino*"
        # $This.ASBwin = New-JtFldSoft -Label "ASBwin" -JtSoftSrc Un32 -Search "ASBwin*"
        $This.AutoCAD_2021 = New-JtFldSoft -Label "AutoCAD_2021" -JtSoftSrc Un64 -Search "Autodesk AutoCAD Jtecture 2021*"
        $This.Bacula = New-JtFldSoft -Label "Bacula" -JtSoftSrc Un32 -Search "Bacula Systems*"
        $This.BkiKosten = New-JtFldSoft -Label "BkiKosten" -JtSoftSrc Un32 -Search "BKI Kostenplaner*"
        $This.BkiPos = New-JtFldSoft -Label "BkiPos" -JtSoftSrc Un32 -Search "BKI Positionen*"
        $This.Chrome = New-JtFldSoft -Label "Chrome" -JtSoftSrc Un64 -Search "Google Chrome*"
        $This.Chromium = New-JtFldSoft -Label "Chromium" -JtSoftSrc Un32 -Search "Chromium*"
        $This.Cinema4D = New-JtFldSoft -Label "Cinema4D" -JtSoftSrc Un64 -Search "Cinema 4D *"
        $This.CiscoAnyConnect = New-JtFldSoft -Label "CiscoAnyConnect" -JtSoftSrc Un32 -Search "Cisco AnyConnect*"
        $This.CorelDRAW = New-JtFldSoft -Label "CorelDRAW" -JtSoftSrc Un64 -Search "CorelDRAW Graphics Suite*"
        $This.CreativeSuite_CS6 = New-JtFldSoft -Label "CreativeSuite_CS6" -JtSoftSrc Un32 -Search "Adobe Creative Suite 6 Design Standard*"
        $This.DellCommand = New-JtFldSoft -Label "DellCommand" -JtSoftSrc Un32 -Search "Dell Command*"
        $This.DellSuppAs = New-JtFldSoft -Label "DellSuppAs" -JtSoftSrc Un64 -Search "Dell SupportAssist*"
        $This.DokanLibrary = New-JtFldSoft -Label "DokanLibrary" -JtSoftSrc Un64 -Search "Dokan Library*"
        $This.DriveFs = New-JtFldSoft -Label "DriveFs" -JtSoftSrc Un64 -Search "Google Drive File Stream*"
        $This.Firefox32 = New-JtFldSoft -Label "Firefox32" -JtSoftSrc Un32 -Search "Mozilla Firefox*"
        $This.Firefox64 = New-JtFldSoft -Label "Firefox64" -JtSoftSrc Un64 -Search "Mozilla Firefox*"
        $This.Flash = New-JtFldSoft -Label "Flash" -JtSoftSrc Un32 -Search "Adobe Flash Player*"
        $This.Foxit = New-JtFldSoft -Label "Foxit" -JtSoftSrc Un32 -Search "Foxit Reader*"
        $This.Gimp = New-JtFldSoft -Label "Gimp" -JtSoftSrc Un64 -Search "GIMP*"
        $This.GoogleEarth = New-JtFldSoft -Label "GoogleEarth" -JtSoftSrc Un32 -Search "Google Earth *"
        $This.Grafiktreiber = New-JtFldSoft -Label "Grafiktreiber" -JtSoftSrc Un64 -Search "NVIDIA Grafiktreiber*"
        $This.IbpHighend = New-JtFldSoft -Label "IbpHighend" -JtSoftSrc Un32 -Search "IBP18599 HighEnd*"
        $This.Illustrator_CC = New-JtFldSoft -Label "Illustrator_CC" -JtSoftSrc Un32 -Search "Adobe Illustrator 2020*"
        $This.Indesign_CC = New-JtFldSoft -Label "Indesign_CC" -JtSoftSrc Un32 -Search "Adobe InDesign 2020*"
        $This.Inkscape = New-JtFldSoft -Label "Inkscape" -JtSoftSrc Un64 -Search "Inkscape*"
        $This.IntelME = New-JtFldSoft -Label "IntelME" -JtSoftSrc Un64 -Search "Intel (R) Management Engine Components*"
        $This.IntelNET = New-JtFldSoft -Label "IntelNET" -JtSoftSrc Un64 -Search "Intel (R) Network *"
        $This.IrfanView = New-JtFldSoft -Label "IrfanView" -JtSoftSrc Un64 -Search "IrfanView *"
        $This.Java = New-JtFldSoft -Label "Java" -JtSoftSrc Un64 -Search "Java 8*"
        $This.Krita = New-JtFldSoft -Label "Krita" -JtSoftSrc Un64 -Search "Krita (x64)*"
        $This.Laubwerk = New-JtFldSoft -Label "Laubwerk" -JtSoftSrc Un64 -Search "Laubwerk Plants*"
        $This.LenovoSysUp = New-JtFldSoft -Label "LenovoSysUp" -JtSoftSrc Un32 -Search "Lenovo System Update*"
        $This.LibreOffice = New-JtFldSoft -Label "LibreOffice" -JtSoftSrc Un64 -Search "LibreOffice*"
        $This.Lightroom_CC = New-JtFldSoft -Label "Lightroom_CC" -JtSoftSrc Un32 -Search "Adobe Lightroom Classic 2020*"
        $This.LUH_Rotis = New-JtFldSoft -Label "LUH_Rotis" -JtSoftSrc Un32 -Search "LUH-Rotis-Font*"
        $This.Max_2021 = New-JtFldSoft -Label "Max_2021" -JtSoftSrc Un64 -Search "Autodesk 3ds Max 2021*"
        $This.NotepadPP = New-JtFldSoft -Label "NotepadPP" -JtSoftSrc Un64 -Search "Notepad++*"
        $This.OBS = New-JtFldSoft -Label "OBS" -JtSoftSrc Un32 -Search "OBS Studio*"
        $This.Office = New-JtFldSoft -Label "Office" -JtSoftSrc Un64 -Search "Microsoft Office Standard*"
        $This.Office365 = New-JtFldSoft -Label "Office365" -JtSoftSrc Un64 -Search "Microsoft 365*"
        $This.OfficeStandard = New-JtFldSoft -Label "OfficeStandard" -JtSoftSrc Un64 -Search "Microsoft Office Standard*"
        $This.OfficeTxt = New-JtFldSoft -Label "OfficeTxt" -JtSoftSrc Un64 -Search "Microsoft Office Standard*"
        $This.OPSI = New-JtFldSoft -Label "OPSI" -JtSoftSrc Un32 -Search "opsi-client-agent*"
        $This.Orca = New-JtFldSoft -Label "Orca" -JtSoftSrc Un32 -Search "ORCA AVA*"
        $This.PDF24 = New-JtFldSoft -Label "PDF24" -JtSoftSrc Un64 -Search "PDF24 Creator*"
        $This.Photoshop_CC = New-JtFldSoft -Label "Photoshop_CC" -JtSoftSrc Un32 -Search "Adobe Photoshop 2020*"
        $This.Premiere_CC = New-JtFldSoft -Label "Premiere_CC" -JtSoftSrc Un32 -Search "Adobe Premiere Pro 2020*"
        $This.Project = New-JtFldSoft -Label "Project" -JtSoftSrc Un64 -Search "Microsoft Project MUI*"
        $This.Powertoys = New-JtFldSoft -Label "Powertoys" -JtSoftSrc Un64 -Search "PowerToys*"
        $This.RawTherapee = New-JtFldSoft -Label "RawTherapee" -JtSoftSrc Un64 -Search "RawTherapee Version*"
        $This.Revit_2020 = New-JtFldSoft -Label "Revit_2020" -JtSoftSrc Un64 -Search "Autodesk Revit 2020*"
        $This.Revit_2021 = New-JtFldSoft -Label "Revit_2021" -JtSoftSrc Un64 -Search "Autodesk Revit 2021*"
        $This.Rhino_6 = New-JtFldSoft -Label "Rhino_6" -JtSoftSrc Un64 -Search "Rhinoceros 6*"
        $This.Seadrive = New-JtFldSoft -Label "Seadrive" -JtSoftSrc Un64 -Search "SeaDrive*"
        $This.Seafile = New-JtFldSoft -Label "Seafile" -JtSoftSrc Un32 -Search "Seafile*"
        $This.ServerViewAgents = New-JtFldSoft -Label "ServerViewAgents" -JtSoftSrc Un64 -Search "FUJITSU Software ServerView Agents x64*"
        $This.Silverlight = New-JtFldSoft -Label "Silverlight" -JtSoftSrc Un64 -Search "Microsoft Silverlight*"
        $This.Sketchup = New-JtFldSoft -Label "Sketchup" -JtSoftSrc Un64 -Search "SketchUp*"
        $This.Sumatra = New-JtFldSoft -Label "Sumatra" -JtSoftSrc Un64 -Search "SumatraPDF*"
        $This.Thunderbird32 = New-JtFldSoft -Label "Thunderbird32" -JtSoftSrc Un32 -Search "Mozilla Thunderbird*"
        $This.Thunderbird64 = New-JtFldSoft -Label "Thunderbird64" -JtSoftSrc Un64 -Search "Mozilla Thunderbird*"
        $This.Unity = New-JtFldSoft -Label "Unity" -JtSoftSrc Un32 -Search "Unity"
        $This.UnityHub = New-JtFldSoft -Label "UnityHub" -JtSoftSrc Un64 -Search "Unity Hub*"
        $This.Vectorworks = New-JtFldSoft -Label "Vectorworks" -JtSoftSrc Un64 -Search "Vectorworks*"
        $This.VLC = New-JtFldSoft -Label "VLC" -JtSoftSrc Un64 -Search "VLC media player*"
        $This.vRay3ds = New-JtFldSoft -Label "vRay3ds" -JtSoftSrc Un64 -Search "V-Ray for 3dsmax 2020*"
        $This.vRayRevit = New-JtFldSoft -Label "vRayRevit" -JtSoftSrc Un64 -Search "V-Ray for Revit*"
        $This.vRayRhino = New-JtFldSoft -Label "vRayRhino" -JtSoftSrc Un64 -Search "V-Ray for Rhinoceros*"
        $This.vRaySketchup = New-JtFldSoft -Label "vRaySketchup" -JtSoftSrc Un64 -Search "V-Ray for SketchUp*"
        $This.VsCodium = New-JtFldSoft -Label "VsCodium" -JtSoftSrc Un64 -Search "VSCodium*"
        $This.VsCode = New-JtFldSoft -Label "VsCode" -JtSoftSrc Un64 -Search "Microsoft Visual Studio Code*"
        $This.WebEx = New-JtFldSoft -Label "WebEx" -JtSoftSrc Un32 -Search "Cisco Webex Meetings*"
        $This.WibuKey = New-JtFldSoft -Label "WibuKey" -JtSoftSrc Un64 -Search "WibuKey Setup*"
        $This.Zip7 = New-JtFldSoft -Label "Zip7" -JtSoftSrc Un64 -Search "7-Zip*"

        $This.prn_4201_000_b006_1 = New-JtFldSoft -Label "prn_4201_000_b006_1" -JtSoftSrc Un64 -Search "prn-4201-000-b006*"
        $This.prn_4201_001_a113_1 = New-JtFldSoft -Label "prn_4201_001_a113_1" -JtSoftSrc Un64 -Search "prn-4201-001-A113*"
        $This.prn_4201_001_a133_1 = New-JtFldSoft -Label "prn_4201_001_a133_1" -JtSoftSrc Un64 -Search "prn-4201-001-a133*"
        $This.prn_4201_u01_bu150_1 = New-JtFldSoft -Label "prn_4201_u01_bu150_1" -JtSoftSrc Un64 -Search "prn-4201-u01-bu150*"
        $This.prn_4201_u01_bu177_1 = New-JtFldSoft -Label "prn_4201_u01_bu177_1" -JtSoftSrc Un64 -Search "prn-4201-u01-bu177*"
    }
    
    [Object[]]GetFields() {
        [JtInf_Soft]$MyJtInf = [JtInf_Soft]::new()

        [Object[]]$MyResult = @()
        [System.Array]$Properties = $This.GetProperties()
        
        foreach ($Property in $Properties) {
            [String]$PropertyName = $Property.Name
            #            Write-Host "PropertyName:" $PropertyName
            
            $Field = $MyJtInf.($PropertyName)
            [String]$FieldType = $Field.GetType()
            # Write-Host "Field-Type:" $FieldType
            if ($FieldType.StartsWith("JtFldSoft")) {
                $MyResult += $Field
            }
        }
        # $MyResult
        return $MyResult
    }

    [System.Array]GetProperties() {
        [JtInf_Soft]$MyJtInf_Soft = [JtInf_Soft]::new()
        $Properties = $MyJtInf_Soft | Get-Member -MemberType Property
        return $Properties
    }

}

Function New-JtInf_Soft {
    
    [JtInf_Soft]::new()
}

Function Get-JtInf_Soft {

    [OutputType([JtInf_Soft])]
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [String]$MyFunctionName = "Get-JtInf_Soft"
    [JtInf_Soft]$MyJtInf = New-JtInf_Soft

    if (!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

    [String]$MyName = "soft"

    [String]$MyProperty_Filter32 = "DisplayName"
    [String]$MyProperty_Version32 = "DisplayVersion"

    [String]$MyProperty_Filter64 = "DisplayName"
    [String]$MyProperty_Version64 = "DisplayVersion"

    [System.Object]$MyObjXml32 = Get-JtXmlReportSoftware -JtIoFolder $MyJtIoFolder -Name "Uninstall32"
    [System.Object]$MyObjXml64 = Get-JtXmlReportSoftware -JtIoFolder $MyJtIoFolder -Name "Uninstall64"
    

    [System.Collections.ArrayList]$MyArray32 = [JtInf_Soft]::GetFilteredArrayList($MyObjXml32, $MyProperty_Filter32)
    [System.Collections.ArrayList]$MyArray64 = [JtInf_Soft]::GetFilteredArrayList($MyObjXml64, $MyProperty_Filter64)

    [Object[]]$MyAlFields = $MyJtInf.GetFields() 
    foreach ($Field in $MyAlFields) {
        [JtFldSoft]$MyField = $Field
        [String]$MyVersion = ""
        [String]$MyKeyword = $MyField.GetSearch()
        [JtSoftSrc]$MyJtSoftSrc = $MyField.GetJtSoftSrc()

        [System.Collections.ArrayList]$MyArray = $Null
        [String]$MyProperty_Filter = ""
        [String]$MyProperty_Version = ""
        if ($MyJtSoftSrc -eq ([JtSoftSrc]::Un32)) {
            $MyArray = $MyArray32
            $MyProperty_Filter = $MyProperty_Filter32
            $MyProperty_Version = $MyProperty_Version32
        }
        else {
            $MyArray = $MyArray64
            $MyProperty_Filter = $MyProperty_Filter64
            $MyProperty_Version = $MyProperty_Version64
        }

        # try {
        $MyResult = $MyArray | Where-Object { $_.($MyProperty_Filter) -like $MyKeyword }
        if ($Null -ne $MyResult) {
            $MyVersion = "v" + $MyResult[0].($MyProperty_Version)
            [String]$MyLabel = $MyField.GetLabel()
            # Write-JtLog -Where $This.ClassName -Text "Label: $MyLabel Version: $Version"
            $MyJtInf.($MyLabel).SetValue($MyVersion) | Out-Null
        }
        #$MyField.SetValue($Version)
    }

        
    [String]$MyValOff = [JtInf_Soft]::GetLabelForOffice($MyJtInf.Office.GetValue())
    $MyJtInf.OfficeTxt.SetValue($MyValOff) | Out-Null

    
    return , $MyJtInf
}

class JtObj : JtClass {

    hidden [String]$Name
}

class JtInf_Soft_InstalledSoftware : JtInf_Soft {

    static [Object[]]$Cache_Fields_InstalledSoftware = [Object[]]

    [Object[]]GetFieldsInstalledSoftware() {
        [Object[]]$MyAlFields = [JtInf_Soft_InstalledSoftware]::Cache_Fields_InstalledSoftware

        if ($Null -eq $MyAlFields) {
            [Object[]]$MyAlObjects = $This.GetFields()
            [Object[]]$MyResult = @()
            foreach ($Object in $MyAlObjects) {
                [JtFldSoft]$MyField = $Object
                [JtSoftSrc]$MyJtSoftSrc = $MyField.GetJtSoftSrc()
                if ($MyJtSoftSrc -eq ([JtSoftSrc]::InstalledSoftware)) {
                    $MyResult += $MyField
                }
            }
            $MyAlFields = $MyResult
            [JtInf_Soft_InstalledSoftware]::Cache_Fields_InstalledSoftware = $MyResult
        }
        return $MyAlFields
    }
}

Function New-JtInf_Soft_InstalledSoftware {

    [JtInf_Soft_InstalledSoftware]::new()
}

Function Get-JtInf_Soft_InstalledSoftware {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Soft_InstalledSoftware]$MyInf = New-JtInf_Soft_InstalledSoftware 

    if (!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

    [String]$MyName = "InstalledSoftware"

    #    [JtSoftSrc]$SoftSrc = [JtSoftSrc]::InstalledSoftware
    [String]$MyProperty_Filter = "Name"
    [String]$MyProperty_Version = "Version"
    
    [JtSearchSet_Software]$MyJtSearchSet = [JtSearchSet_Software]::new()
            
    $MyJtInf = [JtObj]::GetInit($MyInf, $MyName, $MyJtIoFolder, $MyJtSearchSet, $MyProperty_Filter, $MyProperty_Version)
    return [JtInf_Soft_InstalledSoftware]$MyJtInf
}


Function Get-JtXmlReportSoftware() {

    param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtIoFolder]$JtIoFolder, 
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Name
    )

    [JtIoFolder]$MyJtIoFolder = $JtIoFolder
    Write-JtLog -Text "GetXmlReportSoftware. MyJtIoFolder: $MyJtIoFolder"

    [System.Object]$MyObject = $Null
    [System.Object]$MyName = $Name

    Write-JtLog -Text "GetXmlReportSoftware. MyName: $MyName"
    

    if ($Null -eq $MyJtIoFolder) {
        Write-JtError -Text "Folder is NULL for MyName: $MyName"
        return $Null
    }
    
    [String]$MyFilename_Xml = -Join ($MyName, [JtIo]::FileExtension_Xml)
    [JtIoFolder]$MyJtIoFolder_Xml = [JtIoFolder]$MyJtIoFolder.GetJtIoFolder_Sub("software")
    if (!($MyJtIoFolder_Xml.IsExisting())) {
        Write-JtError -Text "MyJtIoFolder_Xml does not exist. MyName: $MyName  - MyJtIoFolder_Xml: $MyJtIoFolder_Xml"
        return $Null
    }

    [String]$MyFilePath_Xml = $MyJtIoFolder_Xml.GetFilePath($MyFilename_Xml)
    Write-JtLog -Text "Get-JtXmlReportSoftware. MyFilePath_Xml: $MyFilePath_Xml"
    if (Test-JtIoFilePath -FilePath $MyFilePath_Xml) {
        try {
            $MyObject = Import-Clixml $MyFilePath_Xml
        }
        catch {
            Write-JtError -Text "GetXmlReportSoftware. Problem while reading Xml: $MyFilePath_Xml"
            Throw "GetXmlReportSoftware. Problem while reading Xml: $MyFilePath_Xml"
        }
    }
    return [System.Object]$MyObject
}





Export-ModuleMember -Function Get-JtInf_Soft
Export-ModuleMember -Function Get-JtInf_Soft_InstalledSoftware
Export-ModuleMember -Function Get-JtXmlReportSoftware
Export-ModuleMember -Function New-JtFldSoft
Export-ModuleMember -Function New-JtInf_Soft
Export-ModuleMember -Function New-JtInf_Soft_InstalledSoftware
