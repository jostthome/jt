using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSupport : JtRep {

    JtRep_SoftwareSupport() : Base("software.support") {
        $This.ClassName = "JtRep_SoftwareSupport"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)

        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Herst)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32ComputerSystem().Modell)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().LenovoSysUp)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellCommand)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellSuppAs)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Opsi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seadrive)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seafile)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DokanLibrary)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().CiscoAnyConnect)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)

        return $MyJtTblRow
    }

}


Function New-JtRep_SoftwareSupport {

    [JtRep_SoftwareSupport]::new() 

}

