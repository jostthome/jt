using module JtInf
using module JtIo
using module JtTbl


class JtInf_Win32VideoController : JtInf {

    [JtFld]$Grafikkarte
    [JtFld]$TreiberVersion

    JtInf_Win32VideoController () {
        $This.Grafikkarte = New-JtFld -Label "Grafikkarte"
        $This.TreiberVersion = New-JtFld -Label "TreiberVersion"
    }
    
    [JtFld]Get_Grafikkarte() {
        return $This.Grafikkarte
    } 

    [JtFld]Get_TreiberVersion() {
        return $This.TreiberVersion
    } 
}


Function New-JtInf_Win32VideoController {

    [JtInf_Win32VideoController]::new()
}

Function Get-JtInf_Win32VideoController {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 
    
    [JtInf_Win32VideoController]$MyJtInf = New-JtInf_Win32VideoController

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [String]$MyName = "Win32_VideoController"
    
    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if (!($Null -eq $MyObj)) {
        $MyJtInf.Grafikkarte.SetValue($MyObj.Description)
        $MyJtInf.TreiberVersion.SetValue($MyObj.Driverversion)
    }
            
    return [JtInf_Win32VideoController]$MyJtInf
}


Export-ModuleMember -Function Get-JtInf_Win32VideoController
Export-ModuleMember -Function New-JtInf_Win32VideoController