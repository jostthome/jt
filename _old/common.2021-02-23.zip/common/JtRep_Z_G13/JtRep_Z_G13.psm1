using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_G13 : JtRep {

    JtRep_Z_G13() : Base("z.g13") {
        $This.ClassName = "JtRep_Z_G13"
        $This.BlnHideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AffinityDesigner)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AffinityPhoto)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AffinityPublisher)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Revit_2021)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office365)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seadrive)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Seafile)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().LibreOffice)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Firefox64)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Thunderbird64)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().AcrobatReader)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Inkscape)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellCommand)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DellSuppAs)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().DokanLibrary)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Flash)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        return $MyJtTblRow
    }
}

Function New-JtRep_Z_G13 {

    [JtRep_Z_G13]::new() 

}


