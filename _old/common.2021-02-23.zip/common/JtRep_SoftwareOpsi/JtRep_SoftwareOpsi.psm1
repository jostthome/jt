using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareOpsi : JtRep {
    
    JtRep_SoftwareOpsi() : Base("software.opsi") {
        $This.ClassName = "JtRep_SoftwareOpsi"
        $This.BlnHideSpezial = $True
    }
    
    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
    
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Opsi)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)

        return $MyJtTblRow
    }
    
}


Function New-JtRep_SoftwareOpsi {

    [JtRep_SoftwareOpsi]::new() 

}
