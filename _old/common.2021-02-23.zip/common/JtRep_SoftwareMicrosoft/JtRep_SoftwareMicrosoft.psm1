using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareMicrosoft : JtRep {
    
    JtRep_SoftwareMicrosoft () : Base("software.microsoft") {
        $This.ClassName = "JtRep_SoftwareMicrosoft"
        $This.BlnHideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$MyJtInfi) {
        [JtTblRow]$MyJtTblRow = $This.GetJtTblRowDefault($MyJtInfi)
    
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinVersion)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinGen)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_AFolder().WinBuild)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().Office365)
        $MyJtTblRow.Add($MyJtInfi.GetJtInf_Soft().OfficeTxt)
        return $MyJtTblRow
    }
    
}


Function New-JtRep_SoftwareMicrosoft {

    [JtRep_SoftwareMicrosoft]::new() 

}


