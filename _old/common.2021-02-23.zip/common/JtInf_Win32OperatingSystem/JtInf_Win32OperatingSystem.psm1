using module JtInf
using module JtIo
using module JtTbl


class JtInf_Win32OperatingSystem : JtInf {

    [JtFld]$OsCaption
    [JtFld]$OsManu
    [JtFld]$OsSerial
    [JtFld]$OsVersion

    JtInf_Win32OperatingSystem() {
        $This.OsCaption = New-JtFld -Label "OsCaption"
        $This.OsManu = New-JtFld -Label "OsManu"
        $This.OsSerial = New-JtFld -Label "OsSerial"
        $This.OsVersion = New-JtFld -Label "OsVersion"
    }

}

Function New-JtInf_Win32OperatingSystem {
    [JtInf_Win32OperatingSystem]::new()
}


Function Get-JtInf_Win32OperatingSystem {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [JtInf_Win32OperatingSystem]$MyJtInf = New-JtInf_Win32OperatingSystem    

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        return $MyJtInf
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath


    [String]$MyName = "Win32_OperatingSystem"

    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if ($MyObj) {
        $MyJtInf.OSCaption.SetValue($MyObj.Caption)
        $MyJtInf.OsManu.SetValue($MyObj.Manufacturer)
        $MyJtInf.OsSerial.SetValue($MyObj.SerialNumber)
        $MyJtInf.OsVersion.SetValue($MyObj.Version)
    }
    return [JtInf_Win32OperatingSystem]$MyJtInf
}    


Export-ModuleMember -Function Get-JtInf_Win32OperatingSystem
Export-ModuleMember -Function New-JtInf_Win32OperatingSystem

