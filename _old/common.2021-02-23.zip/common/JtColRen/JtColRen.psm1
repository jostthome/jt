using module Jt 
using module JtIo
using module JtPreisliste

class JtColRen : JtClass {

    [String]$Label = ""
    [String]$Header = ""

    static [JtColRen]GetJtColRen([String]$ThePart) {
        [String]$MyPart = $ThePart
        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label $MyPart
        if ($MyPart.ToLower() -eq "preis") {
            $MyJtColRen = New-JtColRenInputCurrencyPreis
        }
        elseif ($MyPart.ToLower() -eq "_____datum") {
            $MyJtColRen = New-JtColRenInputDatum 
        }
        elseif ($MyPart.ToLower() -eq "BxH") {
            $MyJtColRen = New-JtColRenInputText -Label "B x H"
        } 
        elseif ($MyPart.ToLower() -eq "_nachname") {
            $MyJtColRen = New-JtColRenInputText -Label "NACHNAME"
        } 
        elseif ($MyPart.ToLower() -eq "bxh") {
            $MyJtColRen = New-JtColRenInputText -Label "bxh" -Header "B x H"
        }         
        elseif ($MyPart.ToLower() -eq "anzahl") {
            $MyJtColRen = New-JtColRenInputAnzahl 
        }
        elseif ($MyPart.ToLower() -eq "betrag") {
            $MyJtColRen = New-JtColRenInputCurrencyBetrag
        }
        elseif ($MyPart.ToLower() -eq "gesamt") {
            $MyJtColRen = New-JtColRenInputCurrency -Label "GESAMT"
        }
        elseif ($MyPart.ToLower() -eq "miete") {
            $MyJtColRen = New-JtColRenInputCurrency -Label "MIETE"
        }
        elseif ($MyPart.ToLower() -eq "nebenkosten") {
            $MyJtColRen = New-JtColRenInputCurrency -Label "NEBENKOSTEN"
        }
        elseif ($MyPart.ToLower() -eq "stand") {
            $MyJtColRen = New-JtColRenInputStand
        }
        elseif ($MyPart.ToLower() -eq "euro") {
            $MyJtColRen = New-JtColRenInputCurrencyEuro
        }
        elseif ($MyPart.ToLower() -eq "0000-00") {
            $MyJtColRen = New-JtColRenInputMonthId
        }
        elseif ($MyPart.ToLower() -eq "zahlung") {
            $MyJtColRen = New-JtColRenInputCurrency -Label "ZAHLUNG"
        }
        return $MyJtColRen
    }


    JtColRen([String]$TheLabel) {
        $This.ClassName = "JtColRen"
        $This.Label = $TheLabel
        $This.Header = $TheLabel
    }

    JtColRen([String]$TheLabel, [String]$TheHeader) {
        $This.ClassName = "JtColRen"
        $This.Label = $TheLabel
        $This.Header = $TheHeader
        if (!($TheHeader)) {
            $This.Header = $TheLabel
        }
    }

    [Boolean]CheckValid([String]$TheValue) {
        return $True
    }

    [String]GetHeader() {
        return $This.Header
    }

    [String]GetLabel() {
        return $This.Label
    }

    [String]GetName() {
        return $This.ClassName
    }

    [String]GetOutput([String]$TheValue) {
        return $TheValue
    }


    
    [Boolean]IsEqual([JtColRen]$TheJtColRen) {
        [Boolean]$MyResult = $False
        $MyLabel = $TheJtColRen.GetLabel()
        if ($MyLabel.Equals($This.GetLabel())) {
            return $True
        }
        else {
            return $MyResult
        }
    }

    [Boolean]IsSummable() {
        return $False
    }
}

class JtColRenFileDim : JtColRen {

    JtColRenFileDim() : base("DIM") {
        $This.ClassName = "JtColRenFileDim"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath

        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyResult = Convert-JtFilename_To_Dim -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $True
    }
}


Function New-JtColRenFileDim {
    
    [JtColRenFileDim]::new()
}



class JtColRenFileAge : JtColRen {

    JtColRenFileAge() : Base("ALTER") {
        $This.ClassName = "JtColRenFileAge"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyResult = Convert-JtFilename_To_IntAlter -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenFileAge {
    

    [JtColRenFileAge]::new()
}


class JtColRenFileAnzahl : JtColRen {

    JtColRenFileAnzahl() : Base("ANZAHL") {
        $This.ClassName = "JtColRenFileAnzahl"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyResult = Convert-JtFilename_To_IntAnzahl -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }

}

Function New-JtColRenFileAnzahl {

    [JtColRenFileAnzahl]::new()
}


class JtColRenFileArea : JtColRen {

    
    JtColRenFileArea() : base("DIM") {
        $This.ClassName = "JtColRenFileArea"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()

        [String]$MyResult = Convert-JtFilename_To_DecQm -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColRenFileArea {
    [JtColRenFileArea]::new()
}



class JtColRenFileEuro : JtColRen {


    JtColRenFileEuro() : Base("EURO") {
        $This.ClassName = "JtColRenFileEuro"
    }


    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyResult = Convert-JtFilename_To_DecBetrag -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $True
    }

}

Function New-JtColRenFileEuro {
    
    [JtColRenFileEuro]::new()
}

class JtColRenFileName : JtColRen {

    JtColRenFileName() : base ("FILE") {
        $This.ClassName = "JtColRenFileName"
    }


    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyResult = $MyJtIoFile.GetName()
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColRenFileName {
    
    [JtColRenFileName]::new()
}




class JtColRenFilePath : JtColRen {

    JtColRenFilePath() : base ("PATH") {
        $This.ClassName = "JtColRenFilePath"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyResult = $MyJtIoFile.GetPath()
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenFilePath {
    
    [JtColRenFilePath]::new()
}



class JtColRenFileJtPreisliste : JtColRen {

    [JtPreisliste]$JtPreisliste
    
    JtColRenFileJtPreisliste([JtPreisliste]$TheJtPreisliste, [String]$TheLabel) : Base($TheLabel) {
        # Label = "PREISE"
        $This.ClassName = "JtColRenFileJtPreisliste"
        $This.JtPreisliste = $TheJtPreisliste
    }



    hidden [String]GetPaper([String]$TheFilename) {
        [String]$MyFilename = $TheFilename

        [String]$MyPaper = Convert-JtFilename_To_Papier -Filename $MyFilename
        return $MyPaper
    }

    hidden [Decimal]GetDecArea([String]$TheFilename) {
        [String]$MyFilename = $TheFilename
        
        [Decimal]$MyDecArea = Convert-JtFilename_To_DecQm -Filename $MyFilename
        return $MyDecArea
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()

        [Decimal]$MyDecQm = $This.GetDecArea($MyFilename)
        [String]$MyPaper = $This.GetPaper($MyFilename)

        [Decimal]$MyDecBasePrice_Paper = $This.JtPreisliste.GetDecBasePrice_Paper($MyPaper)

        [String]$MyResult = -join ($MyDecQm, " x ", $MyDecBasePrice_Paper)
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }

}



Function New-JtColRenFileJtPreisliste {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtPreisliste]$MyJtPreisliste
    )

    [JtColRenFileJtPreisliste]::new($MyJtPreisliste)
}

class JtColRenFileJtPreisliste_Ink : JtColRenFileJtPreisliste {

    JtColRenFileJtPreisliste_Ink([JtPreisliste]$TheJtPreisliste) : Base($TheJtPreisliste, "TINT.") {
        $This.ClassName = "JtColRenFileJtPreisliste_Ink"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()

        [String]$MyPaper = $This.GetPaper($MyFilename)
        [Decimal]$MyDecBasePrice_Ink = $This.JtPreisliste.GetDecBasePrice_Ink($MyPaper)
        [Decimal]$MyDecArea = $This.GetDecArea($MyFilename)

        [Decimal]$MyDecResult = $MyDecArea * $MyDecBasePrice_Ink
        
        [String]$MyResult = Convert-JtDecimal_To_String2 -Decimal $MyDecResult
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}



Function New-JtColRenFileJtPreisliste_Ink {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtPreisliste]$JtPreisliste
    )


[JtPreisliste]$MyJtPreisliste = $JtPreisliste
    [JtColRenFileJtPreisliste_Ink]::new($MyJtPreisliste)
}


class JtColRenFileJtPreisliste_Paper : JtColRenFileJtPreisliste {
    
    JtColRenFileJtPreisliste_Paper([JtPreisliste]$TheJtPreisliste) : Base($TheJtPreisliste, "PAP.") {
        $This.ClassName = "JtColRenFileJtPreisliste_Paper"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()

        [String]$MyPaper = $This.GetPaper($MyFilename)
        
        [Decimal]$MyDecArea = $This.GetDecArea($MyFilename)
        [Decimal]$MyDecBasePrice_Paper = $This.JtPreisliste.GetDecBasePrice_Paper($MyPaper)


        [Decimal]$MyDecResult = $MyDecBasePrice_Paper * $MyDecArea

        # [String]$MyResult = -join($Area, " x ", $Price, " = ", ($DecPrice * $DecArea))

        [String]$MyResult = Convert-JtDecimal_To_String2 $MyDecResult
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }

}


Function New-JtColRenFileJtPreisliste_Paper {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtPreisliste]$JtPreisliste
    )

    [JtPreisliste]$MyJtPreisliste = $JtPreisliste
    [JtColRenFileJtPreisliste_Paper]::new($MyJtPreisliste)
}


class JtColRenFileJtPreisliste_Price : JtColRenFileJtPreisliste {
    
    JtColRenFileJtPreisliste_Price([JtPreisliste]$TheJtPreisliste) : Base($TheJtPreisliste, "PREIS") {
        $This.ClassName = "JtColRenFileJtPreisliste_Price"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()


        [String]$MyPaper = $This.GetPaper($MyFilename)
        [Decimal]$MyDecArea = $This.GetDecArea($MyFilename)
        [Decimal]$MyDecBasePrice_Paper = $This.JtPreisliste.GetDecBasePrice_Paper($MyPaper)
        [Decimal]$MyDecBasePrice_Ink = $This.JtPreisliste.GetDecBasePrice_Ink($MyPaper)

        [Decimal]$MyDecResult = ($MyDecArea * $MyDecBasePrice_Ink) + ($MyDecArea * $MyDecBasePrice_Paper)
        
        [String]$MyResult = Convert-JtDecimal_To_String2 -Decimal $MyDecResult
        return $MyResult
    }
    
    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenFileJtPreisliste_Price {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][JtPreisliste]$JtPreisliste
    )

    [JtPreisliste]$MyJtPreisliste = $JtPreisliste
    [JtColRenFileJtPreisliste_Price]::new($MyJtPreisliste)
}



class JtColRenFileYear : JtColRen {

    JtColRenFileYear() : Base("JAHR") {
        $This.ClassName = "JtColRenFileYear"
    }

    [String]GetOutput([String]$TheFilePath) {
        [JtIoFile]$MyJtIoFile = New-JtIoFile -FilePath $TheFilePath
        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyResult = Convert-JtFilename_To_Jahr -Filename $MyFilename
        return $MyResult
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenFileYear {
    
    [JtColRenFileYear]::new()
}


class JtColRenInputAnzahl : JtColRen {
    
    
    JtColRenInputAnzahl() : Base("ANZAHL", "ANZAHL") {
        $This.ClassName = "JtColRenInputAnzahl"
    }
    
    [Boolean]IsSummable() {
        return $True
    }


    [String]GetOutput([String]$TheValue) {
        [String]$MyResult = $TheValue
        return $MyResult
    }
}


Function New-JtColRenInputAnzahl {

    [JtColRenInputText]::new("Anzahl", "Anzahl")
}


class JtColRenInput_Bxh : JtColRen {


    JtColRenInput_Bxh() : Base("BxH") {
        $This.ClassName = "JtColRenInput_Bxh"
    }

    [Boolean]CheckValid([String]$TheValue) {
        return $True
    }

    [String]GetOutput([String]$TheValue) {
        return $TheValue
    }
    

    
    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColRenInput_Bxh {

    [JtColRenInput_Bxh]::new()
}

class JtColRenInputCurrency : JtColRen {

    JtColRenInputCurrency([String]$TheLabel) : Base($TheLabel) {
        $This.ClassName = "JtColRenInputCurrency"
    }

    [Boolean]CheckValid([String]$TheValue) {
        return Test-JtIsValid_Betrag -Text $TheValue
    }

    [String]GetOutput([String]$TheValue) {
        return Convert-JtString_To_Betrag -Text $TheValue
    }

    [Boolean]IsSummable() {
        return $True
    }
}


Function New-JtColRenInputCurrency {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label
    )

    [JtColRenInputCurrency]::new($Label)
}

Function New-JtColRenInputCurrencyBetrag {
    New-JtColRenInputCurrency -Label "BETRAG"
}

Function New-JtColRenInputCurrencyEuro {
    [JtColRenInputCurrency]::new("EURO")
}    

Function New-JtColRenInputCurrencyGesamt {
    [JtColRenInputCurrency]::new("GESAMT")
}


Function New-JtColRenInputCurrencyPreis {
    [JtColRenInputCurrency]::new("PREIS")
}    



class JtColRenInputDatum : JtColRen {
    
    JtColRenInputDatum() : Base("DATUM") {
        $This.ClassName = "JtColRenInputDatum"
    }
    
    [Boolean]CheckValid([String]$TheValue) {
        return $True
    }
    
    [String]GetOutput([String]$TheValue) {
        return $TheValue
    }
    
    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenInputDatum {
    [JtColRenInputDatum]::new()
}


class JtColRenInputPrice: JtColRen {
    
    JtColRenInputPrice([String]$TheLabel) : Base($TheLabel) {
        $This.ClassName = "JtColRenInputPrice"
        $This.Header = "Preis"
    }
    
   
    [String]GetOutput([String]$TheValue) {
        [String]$MyResult = $TheValue
        
        $MyResult = $MyResult.Replace("_", "")
        $MyResult = $MyResult.Replace(".", "")
        $MyResult = $MyResult.Replace(",", "")
        
        try {
            [Int32]$MyInti = [Decimal]$MyResult
            # [Decimal]$Decimal = $Inti / 100
            [Decimal]$Decimal = $MyInti
            [String]$MyResult = $Decimal.ToString("N2")
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "Convert problem. TheValue: $TheValue"
            return [String]"0,00".ToString()
        }
        return $MyResult
    }
    
    [Boolean]IsSummable() {
        return $True
    }
}

class JtColRenInputStand : JtColRen {
    
    JtColRenInputStand() : Base("STAND") {
        $This.ClassName = "JtColRenInputStand"
    }
    
    [Boolean]CheckValid([String]$TheValue) {
        [String]$MyValue = $TheValue
        [String]$MyWithoutUnderscore = $MyValue.Replace("_", "")
        try {
            [Int32]$IntValue = [Int32]$MyWithoutUnderscore
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "CheckValid. Value is not valid (int check). Value: $MyValue"
            return $False
        }
        try {
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$MyDecValue = [Decimal]$MyValue
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "CheckValid. Value is not valid (decimal check). Value: $MyValue"
            return $False
        }
        try {
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$MyDecValue = [Decimal]$MyValue
            [Int32]$MyIntValue = [Int32]$MyWithoutUnderscore
            [Decimal]$MyValueThroughInt = $MyIntValue / 1000
            if (0 -ne ($MyValueThroughInt - $MyDecValue)) {
                Write-JtError -Where $This.ClassName -Text "CheckValid. Value is not valid (comma check). Value: $MyValue"
                return $False
            }
            
        }
        catch {
            Write-JtError -Where $This.ClassName -Text "CheckValid. Value is not valid (decimal check). Value: $MyValue"
            return $False
        }
        return $True
    }
    
    
    
    [String]GetOutput([String]$TheValue) {
        [String]$MyValue = $TheValue
        [String]$MyResult = $MyValue
        return $MyResult
    }
    
    [Boolean]IsSummable() {
        return $True
    }
}


class JtColRenInputSum : JtColRen {
    
    JtColRenInputSum() : Base("SUMME") {
        $This.ClassName = "JtColRenInputSum"
    }
    
    [String]GetOutput([String]$TheValue) {
        [String]$MyValue = $TheValue
        [String]$MyResult = $MyValue
        return $MyResult
    }
    
    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColRenInputMonthId {
    [JtColRenInputText]::new("Monat", "Monat")
}

Function New-JtColRenInputSum {
    [JtColRenInputSum]::new()
}


class JtColRenInputText : JtColRen {
    
    [String] hidden $Label
    
    JtColRenInputText([String]$TheLabel) : Base($TheLabel) {
        $This.ClassName = "JtColRenInputText"
    }

    JtColRenInputText([String]$TheLabel, [String]$TheHeader) : Base($TheLabel, $TheHeader) {
        $This.ClassName = "JtColRenInputText"
    }

    [String]GetOutput([String]$TheValue) {
        return $TheValue
    }

    [Boolean]IsSummable() {
        return $False
    }

}


Function New-JtColRen {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Header
    )

    [String]$MyLabel = $Label
    [String]$MyHeader = $Label
    if ($Header) {
        $MyHeader = $Header
    }

    [JtColRen]::new($MyLabel, $MyHeader)
}

Function New-JtColRenInputText {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Label,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][String]$Header
    )

    [String]$MyLabel = $Label
    [String]$MyHeader = $Label
    if ($Header) {
        $MyHeader = $Header
    }
    [JtColRenInputText]::new($MyLabel, $MyHeader)
}

Function New-JtColRenInputTextNr {

    [JtColRenInputText]::new("NR", "NR")
}

Function New-JtColRenInputStand {

    [JtColRenInputStand]::new()
}


Function Get-JtColRen {
    
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Name
    )
    
    [String]$MyPart = $Name
    [JtColRen]$MyJtColRen = New-JtColRenInputText -Label $MyPart
    if ($MyPart.ToLower() -eq "preis") {
        $MyJtColRen = New-JtColRenInputCurrencyPreis
    }
    elseif ($MyPart.ToLower() -eq "anzahl") {
        $MyJtColRen = New-JtColRenInputAnzahl 
    }
    elseif ($MyPart.ToLower() -eq "_____datum") {
        $MyJtColRen = New-JtColRenInputDatum 
    }
    elseif ($MyPart.ToLower() -eq "_nachname") {
        $MyJtColRen = New-JtColRenInputText -Label "NACHNAME"
    } 
    elseif ($MyPart.ToLower() -eq "bxh") {
        $MyJtColRen = New-JtColRenInput_BxH
    }         
    elseif ($MyPart.ToLower() -eq "betrag") {
        $MyJtColRen = New-JtColRenInputCurrencyBetrag
    }
    elseif ($MyPart.ToLower() -eq "gesamt") {
        $MyJtColRen = New-JtColRenInputCurrency -Label "GESAMT"
    }
    elseif ($MyPart.ToLower() -eq "miete") {
        $MyJtColRen = New-JtColRenInputCurrency -Label "MIETE"
    }
    elseif ($MyPart.ToLower() -eq "nebenkosten") {
        $MyJtColRen = New-JtColRenInputCurrency -Label "NEBENKOSTEN"
    }
    elseif ($MyPart.ToLower() -eq "stand") {
        $MyJtColRen = New-JtColRenInputStand
    }
    elseif ($MyPart.ToLower() -eq "euro") {
        $MyJtColRen = New-JtColRenInputCurrencyEuro
    }
    elseif ($MyPart.ToLower() -eq "0000-00") {
        $MyJtColRen = New-JtColRenInputMonthId
    }
    elseif ($MyPart.ToLower() -eq "zahlung") {
        $MyJtColRen = New-JtColRenInputCurrency -Label "ZAHLUNG"
    }
    return $MyJtColRen
}


Export-ModuleMember -Function Get-JtColRen
Export-ModuleMember -Function New-JtColRenFileDim
Export-ModuleMember -Function New-JtColRenFileAge
Export-ModuleMember -Function New-JtColRenFileAnzahl
Export-ModuleMember -Function New-JtColRenFileArea
Export-ModuleMember -Function New-JtColRenFileEuro
Export-ModuleMember -Function New-JtColRenFileName
Export-ModuleMember -Function New-JtColRenFilePath
Export-ModuleMember -Function New-JtColRenFileJtPreisliste
Export-ModuleMember -Function New-JtColRenFileJtPreisliste_Ink
Export-ModuleMember -Function New-JtColRenFileJtPreisliste_Paper
Export-ModuleMember -Function New-JtColRenFileJtPreisliste_Price
Export-ModuleMember -Function New-JtColRenFileYear
Export-ModuleMember -Function New-JtColRenInputAnzahl
Export-ModuleMember -Function New-JtColRenInput_Bxh
Export-ModuleMember -Function New-JtColRenInputCurrency
Export-ModuleMember -Function New-JtColRenInputCurrencyBetrag
Export-ModuleMember -Function New-JtColRenInputCurrencyEuro
Export-ModuleMember -Function New-JtColRenInputCurrencyPreis
Export-ModuleMember -Function New-JtColRenInputCurrencyGesamt
Export-ModuleMember -Function New-JtColRenInputDatum
Export-ModuleMember -Function New-JtColRenInputStand
Export-ModuleMember -Function New-JtColRenInputSum
Export-ModuleMember -Function New-JtColRenInputText
Export-ModuleMember -Function New-JtColRenInputTextNr
Export-ModuleMember -Function New-JtColRenInputMonthId