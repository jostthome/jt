using module JtInf
using module JtIo
using module JtTbl


class JtInf_Win32NetworkAdapter : JtInf {

    [JtFld]$Mac
    # [JtFld]$Ip
    # [JtFld]$Ip3

    JtInf_Win32NetworkAdapter () {
        $This.Mac = New-JtFld -Label "Mac"
        # $This.Ip = New-JtFld -Label "Ip"
        # $This.Ip3 = New-JtFld -Label "Ip3"
    }
}

Function New-JtInf_Win32NetworkAdapter {
    [JtInf_Win32NetworkAdapter]::new()
}



Function Get-JtInf_Win32NetworkAdapter {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    ) 

    [String]$MyFunctionName = "Get-JtInf_Win32NetworkAdapter"
    [JtInf_Win32NetworkAdapter]$MyJtInf = New-JtInf_Win32NetworkAdapter

    if(!(Test-JtIoFolder_Report -FolderPath $FolderPath)) {
        Return
    }
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
    [String]$MyName = "Win32_NetworkAdapter"

    [System.Object]$MyObj = Get-JtXmlReportObject -FolderPath $MyJtIoFolder -Name $MyName
    if ($MyObj) {
        [String]$MyMac = ""
        try {
            $MyAlCons = $MyObj | Where-Object -Property netconnectionstatus -Like "2" 
            $MyAlResult = $MyAlCons | Select-Object -Property MACAddress
    
            $MyMac = $MyAlResult[0].MACAddress 
        }
        catch {
            Write-JtError -Where $MyFunctionName -Text "Field: xxxx, Error in $MyName"
        }
        $MyJtInf.Mac.SetValue($MyMac)
    }

    return [JtInf_Win32NetworkAdapter]$MyJtInf
}

Export-ModuleMember -Function Get-JtInf_Win32NetworkAdapter
Export-ModuleMember -Function New-JtInf_Win32NetworkAdapter


