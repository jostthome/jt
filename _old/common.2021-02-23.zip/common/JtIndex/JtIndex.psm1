﻿using module Jt  
using module JtColRen
using module JtCsv
using module JtIo
using module JtMd
using module JtPreisliste
using module JtTbl
using module JtTemplateFile

class JtFolder : JtClass {


    [String]$FileExtensionTemplate
    

    JtFolder() {
        $This.ClassName = "JtFolder"

        Write-JtLog -Where $This.ClassName -Text "Init..."

        $This.FileExtensionTemplate = [JtIo]::FileExtensionFolder
    }

    DoCleanSpecialFiles([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        Remove-JtFilesSpecial -FolderPath $MyFolderPath
    }

    DoWriteFile_Meta([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        [String]$MyFilenameOutput = $This.GetFilenameSpecial($MyFolderPath)
        New-JtIoFile_Meta_Special -FolderPath $MyFolderPath -FilenameOutput $MyFilenameOutput
    }
    
    [String]GetFilenameSpecial([String]$TheFolderPath) {
        Throw "GetFilenameSpecial( ...) should be overwritten."
        return ""
    }

    GetInfo([String]$TheFolderPath) {
        Throw "GetInfo should be overwritten."
    }
}

class JtFolder_Csv_Files : JtFolder {

    JtFolder_Csv_Files() : base() {
        $This.ClassName = "JtFolder_Csv_Files"
        Write-JtLog -Where $This.ClassName -Text "Init..."
    }
    
    DoIt([String]$TheFolderPath) {
        Write-JtLog -Where $This.ClassName -Text "DoIt..."
        [String]$MyFolderPath = $TheFolderPath
        
        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWrite_Csv_Filelist_in_FolderPathInput($MyFolderPath)
        
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        Write-JtLog -Where $This.ClassName -Text "INFO: $MyInfo"
    }

    [Boolean]DoCheckFolder([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyFolderPath

        [Boolean]$MyResult = $True

        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal

        foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [Boolean]$BlnFileValid = $MyJtTemplateFile.DoCheckFile($MyJtIoFile)
            if (!($BlnFileValid)) {
                $MyResult = $False
            }
        }
        return $MyResult
    }

    [Boolean]DoWrite_Csv_Filelist_in_FolderPathInput([String]$TheFolderPath) {
        [String]$MyFolderPath_Input = $TheFolderPath
        [String]$MyFolderPath_Output = $TheFolderPath

        return $This.DoWrite_Csv_Filelist_in_FolderPathOutput($MyFolderPath_Input, $MyFolderPath_Output)
    }

    [Boolean]DoWrite_Csv_Filelist_in_FolderPathOutput([String]$TheFolderPathInput, [String]$TheFolderPathOutput) {
        [String]$MyMethodName = "DoWrite_Csv_Filelist_in_FolderPathOutput" 

        [String]$MyFolderPathInput = $TheFolderPathInput
        [String]$MyFolderPathOutput = $TheFolderPathOutput

        [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyFolderPathInput
        if (!($MyJtIoFolder_Input.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "$MyMethodName. Folder does not exist!!! MyJtIoFolder_Input: $MyJtIoFolder_Input"
            return $False
        }

        [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyFolderPathOutput -Force
        
        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyJtIoFolder_Input
        if (!($MyJtTemplateFile.IsValid())) {
            Write-JtError -Where $This.ClassName -Text "$MyMethodName. TemplateFile is not valid. MyJtTemplateFile: $MyJtTemplateFile"
            return $False
        }
        
        Write-JtLog -Where $This.ClassName -Text "$MyMethodName. Getting files..."
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder_Input -Normal
        if ($MyAlJtIoFiles.Count -gt 0) {
            Write-JtLog -Where $This.ClassName -Text "$MyMethodName. Getting DataTable..."
            [System.Data.Datatable]$MyDataTable = $This.GetDatatable($MyJtIoFolder_Input, $MyAlJtIoFiles)
            
            [String]$MyFoldername_Input = $MyJtIoFolder_Input.GetName()
            [String]$MyFilename_Output = Get-JtIoFilename_Csv_Filelist -FolderName $MyFoldername_Input
            Convert-JtDataTable_To_FileCsv -DataTable $MyDataTable -FolderPathOutput $MyJtIoFolder_Output -Filename $MyFilename_Output 
        }
        else {
            Write-JtError -Where $This.ClassName -Text "$MyMethodName. NoFiles found MyJtIofolder_Input: $MyJtIofolder_Input"

        }
        return $True
    }


    [String]GetInfo([String]$TheFolderPath) {
        return "info"
    }

    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyInfo = $This.GetInfo($MyFolderPath)

        [String]$MyLabel = $MyInfo
        [String]$MyExtension2 = [JtIo]::FileExtension_Csv_Files
        [String]$MyFilename = Get-JtIoFilename_Meta -Label $MyLabel -Extension2 $MyExtension2
        return $MyFilename
    }

    [System.Data.Datatable]GetDatatable([String]$TheFolderPath, [System.Collections.ArrayList]$TheAlJtIoFiles) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyFolderPath
        [String]$MyMethodName = "GetDatatable"

        [System.Collections.ArrayList]$MyAlJtIoFiles = $TheAlJtIoFiles
        [System.Data.Datatable]$MyDataTable = New-Object System.Data.Datatable
        [System.Collections.ArrayList]$MyAlJtColRens = $MyJtTemplateFile.GetJtColRens()

        if ($Null -eq $MyAlJtColRens) {
            Write-JtLog -Where $This.ClassName -Text "$MyMethodName. MyAlJtColRens is NULL. MyJtIoFolder: $MyJtIoFolder"
            return $MyDataTable
        }
        Write-JtLog -Where $This.ClassName -Text "$MyMethodName. Start. Adding Columns"

        foreach ($MyJtColRen in $MyAlJtColRens) {
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyDataTable.Columns.Add($MyLabel, "String")
        }

        Write-JtLog -Where $This.ClassName -Text "$MyMethodName. Start"

        [JtColRen]$MyJtColRen = New-JtColRenFileYear
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyDataTable.Columns.Add($MyLabel, "String")
            
        [JtColRen]$MyJtColRen = New-JtColRenFileAge
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyDataTable.Columns.Add($MyLabel, "String")

        foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName()
            Write-JtLog -Where $This.ClassName -Text "______FileName: $MyFilename"
    
            $MyFilenameParts = $MyFilename.Split(".")
            $MyRow = $MyDataTable.NewRow()
            for ([Int32]$j = 0; $j -lt $MyFilenameParts.Count; $j++) {
                [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
                [String]$MyHeader = $MyJtColRen.GetHeader()
                [String]$MyLabel = $MyJtColRen.GetLabel()
                # $MyDataTable.Columns.Add($MyLabel, "String")
                [String]$MyValue = $MyAlJtColRens[$j].GetOutput($MyFilenameParts[$j])

                $MyRow.($MyLabel) = $MyValue
            }

            [JtColRen]$MyJtColRen = New-JtColRenFileYear
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            $MyRow.($MyLabel) = $MyValue

            [JtColRen]$MyJtColRen = New-JtColRenFileAge
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            $MyRow.($MyLabel) = $MyValue

            $MyDataTable.Rows.Add($MyRow)
        }
        return $MyDataTable
    }


}

Function New-JtFolder_Csv_Files {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath

    [JtFolder_Csv_Files]$MyJtFolder_Csv_Files = New-Object JtFolder_Csv_Files
    $MyJtFolder_Csv_Files.DoIt($MyFolderPath)
}

class JtFolder_Csv_Files_Alter : JtFolder_Csv_Files {

    JtFolder_Csv_Files_Alter() : base() {
        $This.ClassName = "JtFolder_Csv_Files_Alter"
    }

    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyInfo = $This.GetInfo($MyFolderPath)

        [String]$MyLabel = $MyInfo
        [String]$MyExtension2 = [JtIo]::FileExtension_Csv_Files
        [String]$MyFilename = Get-JtIoFilename_Meta -Label $MyLabel -Extension2 $MyExtension2
        return $MyFilename
    }
}

Function New-JtFolder_Csv_Files_Alter {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtFolder_Csv_Files_Alter]$MyJtFolder_Csv_Files_Alter = New-Object JtFolder_Csv_Files_Alter
    $MyJtFolder_Csv_Files_Alter.DoIt($MyFolderPath)
}

class JtFolder_Meta_Betrag : JtFolder {

    JtFolder_Meta_Betrag() : base() {
        $This.ClassName = "JtFolder_Meta_Betrag"

    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteFile_MetasYears($MyFolderPath, $MyFolderPath)
    }

    DoWriteFile_MetasYears([String]$TheFolderPathInput, [String]$TheFolderPathOutput) {

        [String]$MyFolderPath_Input = $TheFolderPathInput
        [String]$MyFolderPath_Output = $TheFolderPathOutput

        [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyFolderPath_Input

        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyFolderPath_Input
        if (!($MyJtTemplateFile.IsValid())) {
            Write-JtError -Where $This.ClassName -Text "MyJtTemplateFile is not valid at MyFolderPath_Input: $MyFolderPath_Input"
            return
        }
        
        [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyFolderPath_Output -Force
        [String]$MyFolderPath_Output = $MyJtIoFolder_Output.GetPath()
        
        $MyAlYears = Get-JtFolderYears -FolderPath $MyFolderPath_Input
        ForEach ($Year in $MyAlYears) {
            [String]$MyYear = $Year
            [String]$MyFolderName_Input = $MyJtIoFolder_Input.GetName()

            [String]$MyBetrag = Convert-JtFolderPath_To_Betrag_For_Year -FolderPath $MyFolderPath_Input -Year $MyYear
            [String]$MyFilename = Get-JtIoFilename_Meta_Betrag -FolderName $MyFolderName_Input -Betrag $MyBetrag  -Year $MyYear
 
            New-JtIoFile_Meta_Special -FolderPath $MyFolderPath_Output -FilenameOutput $MyFilename
        }
    }

}

class JtFolder_Meta_Anzahl : JtFolder {

    JtFolder_Meta_Anzahl() : base() {
        $This.ClassName = "JtFolder_Meta_Anzahl"
        
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteFile_Meta($MyFolderPath)

        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        Write-JtLog -Where $This.ClassName -Text "INFO: $MyInfo"
    }

    [System.Data.Datatable]GetDatatable([String]$TheFolderPath, [System.Collections.ArrayList]$TheAlJtIoFiles) {
        [String]$MyFolderPath = $TheFolderPath
        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyFolderPath
        
        [System.Collections.ArrayList]$MyAlJtIoFiles = $TheAlJtIoFiles

        [System.Data.Datatable]$MyDataTable = New-Object System.Data.Datatable 
        [System.Collections.ArrayList]$MyAlJtColRens = $MyJtTemplateFile.GetJtColRens()

        foreach ($MyJtColRen in $MyAlJtColRens) {
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyDataTable.Columns.Add($MyLabel, "String")
        }

        [JtColRen]$MyJtColRen = New-JtColRenFileYear
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyDataTable.Columns.Add($MyLabel, "String")
            
        [JtColRen]$MyJtColRen = New-JtColRenFileAge
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyDataTable.Columns.Add($MyLabel, "String")

        foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName()
            Write-JtLog -Where $This.ClassName -Text "____MyFileName: $MyFilename"
    
            $MyAlFilenameParts = $MyFilename.Split(".")
            $MyRow = $MyDataTable.NewRow()
            for ([Int32]$j = 0; $j -lt $MyAlFilenameParts.Count; $j++) {
                [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
                [String]$MyHeader = $MyJtColRen.GetHeader()
                [String]$MyLabel = $MyJtColRen.GetLabel()
                [String]$MyValue = $MyAlJtColRens[$j].GetOutput($MyAlFilenameParts[$j])
                $MyRow.($MyLabel) = $MyValue
            }

            [JtColRen]$MyJtColRen = New-JtColRenFileYear
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            $MyRow.($MyLabel) = $MyValue
            
            [JtColRen]$MyJtColRen = New-JtColRenFileAge
            [String]$MyHeader = $MyJtColRen.GetHeader()
            [String]$MyLabel = $MyJtColRen.GetLabel()
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            $MyRow.($MyLabel) = $MyValue

            $MyDataTable.Rows.Add($MyRow)
        }
        return $MyDataTable
    }

    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        [String]$MyFoldername = $MyJtIoFolder.GetName()
        
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        [String]$MyFilename = Get-JtIoFilename_Meta_Anzahl -Anzahl $MyInfo -Foldername $MyFoldername
        return $MyFilename
    }

    [String]GetInfo([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        
        [Int16]$MyIntCount = 0
        
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        if (!($MyJtIoFolder.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "Error!!! Please edit XML for MyJtIoFolder: $MyJtIoFolder"
            return "ERROR"
        }

        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
        ForEach($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName()
            if (Test-JtFilename_Anzahl_IsValid -Filename $MyFilename) {
                [Int16]$MyIntAnz = Convert-JtFilename_To_IntAnzahl -Filename $MyFilename
                $MyIntCount = $MyIntCount + $MyIntAnz
            }
            else {
                [JtIoFolder]$MyJtIoFolder = $MyJtIoFile.GetJtIoFolder_Parent()
                    [String]$MyMsg = "GetInfo. Problem with file. MyFilename: $MyFilename"
                    [String]$MyFilePath = $MyJtIoFile.GetPath()
                    Write-JtFolder -Where $This.ClassName -Text $MyMsg -FilePath $MyFilePath
            }
        }
        [String]$MyCount = -Join("", $MyIntCount)
        return $MyCount
    }
}

Function New-JtFolder_Meta_Anzahl {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath

    [JtFolder_Meta_Anzahl]$MyJtFolder_Meta_Anzahl = New-Object JtFolder_Meta_Anzahl
    $MyJtFolder_Meta_Anzahl.DoIt($MyFolderPath)
}


Function New-JtFolder_Meta_Betrag {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtFolder_Meta_Betrag]$MyJtFolder_Meta_Betrag = New-Object JtFolder_Meta_Betrag
    $MyJtFolder_Meta_Betrag.DoIt($MyFolderPath)
}

class JtFolder_Md : JtFolder {
    
    JtFolder_Md() : base() {
        $This.ClassName = "JtFolder_Md"
    }
    
    [Boolean]DoWriteMdFileIn([JtIoFolder]$TheJtIoFolderOutput) {
        [JtIoFolder]$MyJtIoFolder_Output = $TheJtIoFolderOutput
        [String]$MyFolderPath_Output = $MyJtIoFolder_Output.GetPath()
        Write-JtLog -Where $This.ClassName -Text "Writing MD-Doc - BEGIN"
        [String]$MyMdDoc = $This.GetMdDoc($MyFolderPath_Output) 
        Write-JtLog -Where $This.ClassName -Text $MyMdDoc
        Write-JtLog -Where $This.ClassName -Text "Writing MD-Doc - END"
        
        [String]$MyFilename_Output = $This.GetMdFileName($MyFolderPath_Output)
        [String]$MyFilePath_Output = $MyJtIoFolder_Output.GetFilePath($MyFilename_Output)
        
        Write-JtIoFile -Where $This.ClassName -Text "Writing MD-Doc." -FilePath $MyFilePath_Output
        $MyMdDoc | Out-File -FilePath $MyFilePath_Output -Encoding UTF8
        
        return $True
    }

    [Boolean]DoWriteMdFile([String]$TheFolderPathOutput) {
        [String]$MyFolderPath_Output = $TheFolderPathOutput
        [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyFolderPath_Output
        return $This.DoWriteMdFileIn($MyJtIoFolder_Output)
    }


}
Function New-JtFolder_Md {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath

    [JtFolder_Md]$MyJtFolder_Md = New-Object JtFolder_Md
    $MyJtFolder_Md.DoIt($MyFolderPath)
}

class JtFolder_Md_Zahlung : JtFolder_Md {

    JtFolder_Md_Zahlung() : base() {
        $This.ClassName = "JtFolder_Md_Zahlung"
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        
        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteMdFile($MyFolderPath)

        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        Write-JtLog -Where $This.ClassName -Text "MyInfo: $MyInfo"
    }
    
    [System.Data.Datatable]GetDatatable([String]$TheFolderPath, [System.Collections.ArrayList]$TheAlJtIoFiles) {
        [String]$MyFolderPath_Input = $TheFolderPath
        [System.Collections.ArrayList]$MyAlJtIoFiles = $TheAlJtIoFiles
        
        [System.Data.Datatable]$MyDataTable = New-Object System.Data.Datatable

        [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyFolderPath_Input
        [System.Collections.ArrayList]$MyAlJtColRens = $MyJtTemplateFile.GetJtColRens()


        [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [Int32]$j = 0
        $j = 0
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        $j = 1
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        $j = 2
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        $j = 3
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        $j = 4
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        $j = 5
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        $j = 6
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")


        [Int32]$MyIntLine = 1
        foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName()
            [String]$MyValue = ""
            
            $MyAlFilenameParts = $MyFilename.Split(".")
            $MyRow = $MyDataTable.NewRow()

            for ([Int32]$j = 0; $j -lt ($MyAlFilenameParts.Count - 1); $j++) {
                
                [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
                [String]$MyHeader = $MyJtColRen.GetHeader()
                [String]$MyLabel = $MyJtColRen.GetLabel()
                $MyRow.($MyLabel) = $MyIntLine

                [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
                
                if ($Null -eq $MyJtColRen) {
                    Write-JtError -Where $This.ClassName -Text "This should not happen. JtColRen is NULL. MyJtIoFile: $MyJtIoFile"
                }
                else {
                    [String]$MyHeader = $MyJtColRen.GetHeader()
                    [String]$MyLabel = $MyJtColRen.GetLabel()
                    $MyValue = $MyAlJtColRens[$j].GetOutput($MyAlFilenameParts[$j])
                    $MyRow.($MyLabel) = $MyValue
                }
            }
            
            $MyDataTable.Rows.Add($MyRow)
            $MyIntLine = $MyIntLine + 1
        }
        
        $MyRow = $MyDataTable.NewRow()
        
        [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = "SUM:"
        
        [Int32]$j = 0
        $j = 0
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = "(Monat)"

        $j = 1
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = "(Art)"

        $j = 2
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = "(Objekt)"
        
        $j = 3
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = "(Mieter)"

        $j = 4
        [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "MIETE"
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        [String]$MyValue = $MyJtColRen.GetOutput($MySum)
        $MyRow.($MyLabel) = $MyValue
        
        $j = 5
        [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "NEBENKOSTEN"
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        [String]$MyValue = $MyJtColRen.GetOutput($MySum)
        $MyRow.($MyLabel) = $MyValue
        
        $j = 6
        [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "ZAHLUNG"
        [JtColRen]$MyJtColRen = $MyAlJtColRens[$j]
        [String]$MyLabel = $MyJtColRen.GetLabel()
        [String]$MyValue = $MyJtColRen.GetOutput($MySum)
        $MyRow.($MyLabel) = $MyValue

        $MyDataTable.Rows.Add($MyRow)

        return $MyDataTable
    }



    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        [String]$MyLabel = $MyInfo
        [String]$MyExtension2 = [JtIo]::FileExtension_Md_Zahlung
        [String]$MyFilename = Get-JtIoFilename_Meta -Label $MyLabel -Extension2 $MyExtension2
        return $MyFilename
    }
    
    
    [String]GetInfo([String]$TheFolderPath) {
        # [String]$MyFolderPath = $TheFolderPath
        return "zahlung_md"
    }

    [String]GetMdDoc([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

        $MyFolderName = $MyJtIoFolder.GetName()

        $MyAlFoldernameParts = $MyFolderName.split(".")
        [String]$Jahr = $MyAlFolderNameParts[$MyAlFoldernameParts.count - 1]
        [MdDocument]$MdDocument = [MdDocument]::new( -Join ("Zahlungen ", $Jahr))
        [String]$MyTimestamp = Get-JtTimestamp
        $MdDocument.AddLine( -join ("*", " ", "Stand: ", $MyTimestamp))
        $MdDocument.AddLine( -join ("*", " ", $MyJtIoFolder.GetJtIoFolder_Parent().GetPath()))

        # $MdDocument.AddLine("Hier werden die Pläne aufgelistet.")

        $MdDocument.AddH2("Miete und Nebenkosten")

        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
        $MyDataTable = $This.GetDatatable($MyFolderPath, $MyAlJtIoFiles)
        
        Write-JtLog -Where $This.ClassName -Text "GetMdDoc. Type of DataTable. $MyDataTable.GetType()"

        [MdTable]$MyTable = [MdTable]::new($MyDataTable)

        $MdDocument.AddLine($MyTable.GetOutput())
        $MdDocument.AddLine("---")

        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

        [String]$MyFilePrefix = "zzz.ABRECHNUNG"
        [String]$MyFileExtension = [JtIo]::FileExtension_Md_Zahlung
        
        [String]$MyFolderName = $MyJtIoFolder.GetName()
        [String]$MyFilenameOutput = -join ($MyFilePrefix, ".", $MyFolderName, $MyFileExtension)
        return $MyFilenameOutput
    }
}
Function New-JtFolder_Md_Zahlung {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtFolder_Md_Zahlung]$MyJtFolder_Md_Zahlung = New-Object JtFolder_Md_Zahlung
    $MyJtFolder_Md_Zahlung.DoIt($MyFolderPath)
}

class JtFolder_Md_BxH : JtFolder_Md {

    [JtPreisliste]$JtPreisliste
    [String]$Price

    JtFolder_Md_BxH() : base() {
        $This.ClassName = "JtFolder_Md_BxH"
        [JtPreisliste]$MyJtPreisliste = New-JtPreisliste_Plotten_2020_07_01
        $This.JtPreisliste = $MyJtPreisliste
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteMdFile($MyFolderPath)
        
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        Write-JtLog -Where $This.ClassName -Text "INFO: $MyInfo"
    }
    
    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        [String]$MyLabel = $MyInfo
        [String]$MyExtension2 = [JtIo]::FileExtension_Md_Bxh
        [String]$MyFilename = Get-JtIoFilename_Meta -Label $MyLabel -Extension2 $MyExtension2
        return $MyFilename
    }
    
    [String]GetInfo([String]$TheFolderPath) {
        # [String]$MyFolderPath = $TheFolderPath
        return "abrechnung"
    }
    
    [System.Data.Datatable]GetDatatable([String]$TheFolderPath, [System.Collections.ArrayList]$TheAlJtIoFiles) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyPrice = New-JtFolder_Meta_BxH -FolderPath $MyFolderPath

        [System.Collections.ArrayList]$MyAlJtIoFiles = $TheAlJtIoFiles
        [JtPreisliste]$MyJtPreisliste = $This.JtPreisliste

        [System.Data.Datatable]$MyDataTable = New-Object System.Data.Datatable

        [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Price -JtPreisliste $MyJtPreisliste
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "NACHNAME"
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "VORNAME"
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "LABEL"
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "PAPIER"
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "BxH"
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")

        [JtColRen]$MyJtColRen = New-JtColRenFileArea
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Paper -JtPreisliste $MyJtPreisliste
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Ink -JtPreisliste $MyJtPreisliste
        $MyDataTable.Columns.Add($MyJtColRen.GetLabel(), "String")
        
        [Int32]$MyIntLine = 1

        foreach ($File in $MyAlJtIoFiles) {
            $MyRow = $MyDataTable.NewRow()
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilename = $MyJtIoFile.GetName()
            
            [String]$MyValue = ""
            
            [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
            [String]$MyValue = $MyIntLine
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            
            $FilenameParts = $MyFilename.Split(".")

            [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Price -JtPreisliste $MyJtPreisliste
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            # Write-JtLog -Where $This.ClassName -Text "Preis: $MyValue"

            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "NACHNAME"
            $MyValue = $FilenameParts[0]
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
    
            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "VORNAME"
            $MyValue = $FilenameParts[1]
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            
            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "LABEL"
            $MyValue = $FilenameParts[2]
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
    
            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "PAPIER"
            $MyValue = $FilenameParts[3]
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue

            [JtColRen]$MyJtColRen = New-JtColRenInputText -Label "BxH"
            $MyValue = $FilenameParts[4]
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            
            [JtColRen]$MyJtColRen = New-JtColRenFileArea
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            
            [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Paper -JtPreisliste $MyJtPreisliste
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue
            
            [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Ink -JtPreisliste $MyJtPreisliste
            [String]$MyValue = $MyJtColRen.GetOutput($MyJtIoFile.GetPath())
            [String]$MyLabel = $MyJtColRen.GetLabel()
            $MyRow.($MyLabel) = $MyValue

            $MyDataTable.Rows.Add($MyRow)
            $MyIntLine = $MyIntLine + 1
        }
        
        $MyRow = $MyDataTable.NewRow()

        [JtColRen]$MyJtColRen = New-JtColRenInputTextNr
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyValue = "SUM:"
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = $MyValue

        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Price -JtPreisliste $MyJtPreisliste
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyValue = $MyPrice
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = $MyValue

        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Paper -JtPreisliste $MyJtPreisliste
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyValue = ""
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = $MyValue

        [JtColRen]$MyJtColRen = New-JtColRenFileJtPreisliste_Ink -JtPreisliste $MyJtPreisliste
        [String]$MyHeader = $MyJtColRen.GetHeader()
        [String]$MyValue = ""
        [String]$MyLabel = $MyJtColRen.GetLabel()
        $MyRow.($MyLabel) = $MyValue

        $MyDataTable.Rows.Add($MyRow)

        return $MyDataTable
    }

    [String]GetMdDoc([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtioFolder -FolderPath $MyFolderPath
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
        $MyDataTable = $This.GetDatatable($MyFolderPath, $MyAlJtIoFiles)

        if ($Null -eq $MyDataTable) {
            Write-JtError -Where $This.ClassName -Text "GetMdDoc. Datatable is NULL."
        }

        [JtPreisliste]$MyJtPreisliste = $This.JtPreisliste

        [MdDocument]$MdDocument = [MdDocument]::new("Fakultät für Architektur und Landschaft")
        $MdDocument.AddLine("https://www.archland.uni-hannover.de/de/fakultaet/ausstattung/plotservice/")
        $MdDocument.AddH2("Plot-Service - Abrechnung")
        
        [String]$MyTimestamp = Get-JtTimestamp
        $MdDocument.AddLine("* Stand: $MyTimestamp")
        
        [String]$MyPreislisteTitle = $MyJtPreisliste.GetTitle()
        $MdDocument.AddLine("* Preisliste: $MyPreislisteTitle")

        [String]$MyPath = $MyJtIoFolder.GetPath()
        $MdDocument.AddLine("* $MyPath")

        $MdDocument.AddH2("Pläne")

        [MdTable]$MyMdTable = [MdTable]::new($MyDataTable)
        $MdDocument.AddLine($MyMdTable.GetOutput())
        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Kunde")
        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Plot-Service")
        $MdDocument.AddLine("---")
        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        [String]$MyFolderName = $MyJtIoFolder.GetName()


        [String]$MyFilePrefix = "zzz.ABRECHNUNG"
        [String]$MyFileExtension = [JtIo]::FileExtension_Md_Bxh
        [String]$MyFilename_Output = -join ($MyFilePrefix, ".", $MyFolderName, $MyFileExtension)
        return $MyFilename_Output
    }
}

Function New-JtFolder_Md_BxH {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    
    [JtFolder_Md_BxH]$MyJtFolder_Md_BxH = New-Object JtFolder_Md_BxH 
    $MyJtFolder_Md_BxH.DoIt($MyFolderPath)
}

class JtFolder_Meta_Zahlung : JtFolder {

    JtFolder_Meta_Zahlung() : base() {
        $This.ClassName = "JtFolder_Meta_Zahlung"
    }

    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteFile_MetasYears($MyFolderPath)
    }

    DoWriteFile_MetasYears([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyFolderPath
        [String]$MyFolderPath_Input = $MyJtIoFolder_Input.GetPath()
        
        [JtIoFolder]$MyJtIoFolder_Output = $MyJtIoFolder_Input
        [String]$MyFolderPath_Output = $MyJtIoFolder_Output.GetPath()

        $MyAlYears = Get-JtFolderYears -FolderPath $MyFolderPath_Input
        [String]$MyFoldername_Input = $MyJtIoFolder_Input.GetName()
        ForEach ($MyYear in $MyAlYears) {
            [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "NEBENKOSTEN"
            [String]$MyFilename_Output = $This.GetFilename_Meta_Miete($MyFoldername_Input, $MyYear, $MySum)
            New-JtIoFile_Meta_Special -FolderPath $MyFolderPath_Output -FilenameOutput $MyFilename_Output

            [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "MIETE"
            [String]$MyFilename_Output = $This.GetFilename_Meta_Nebenkosten($MyFoldername_Input, $MyYear, $MySum)
            New-JtIoFile_Meta_Special -FolderPath $MyFolderPath_Output -FilenameOutput $MyFilename_Output

            [String]$MySum = Get-JtSum_From_FolderPath -FolderPath $MyFolderPath_Input -PartName "ZAHLUNG"
            [String]$MyFilename_Output = $This.GetFilename_Meta_Zahlung($MyFoldername_Input, $MyYear, $MySum)
            New-JtIoFile_Meta_Special -FolderPath $MyFolderPath_Output -FilenameOutput $MyFilename_Output
        }
    }

    [String]GetFilename_Meta_Nebenkosten([String]$TheFolderName, [String]$TheYear, [String]$TheSum) {
        [String]$MyFolderName = $TheFolderName
        [String]$MyBetrag = $TheSum
        [String]$MyYear = $TheYear
        
        [String]$MyFilename = Get-JtIoFilename_Meta_Betrag_Voraus -FolderName $MyFolderName -Betrag $MyBetrag -Year $MyYear 
        return $MyFilename
    }
    
    [String]GetFilename_Meta_Miete([String]$TheFolderName, [String]$TheYear, [String]$TheSum) {
        [String]$MyFolderName = $TheFolderName
        [String]$MyBetrag = $TheSum
        [String]$MyYear = $TheYear
        
        [String]$MyFilename = Get-JtIoFilename_Meta_Betrag_Miete -FolderName $MyFolderName -Betrag $MyBetrag -Year $MyYear
        return $MyFilename
    }
    
    [String]GetFilename_Meta_Zahlung([String]$TheFolderName, [String]$TheYear, [String]$TheSum) {
        [String]$MyFolderName = $TheFolderName
        [String]$MyBetrag = $TheSum
        [String]$MyYear = $TheYear
        
        [String]$MyFilename = Get-JtIoFilename_Meta_Betrag_Zahlung -FolderName $MyFolderName -Betrag $MyBetrag -Year $MyYear
        return $MyFilename
    }
}

Function New-JtFolder_Meta_Zahlung {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtFolder_Meta_Zahlung]$MyJtFolder_Meta_Zahlung = New-Object JtFolder_Meta_Zahlung
    $MyJtFolder_Meta_Zahlung.DoIt($MyFolderPath)
}

class JtFolder_Meta_BxH : JtFolder {

    [JtPreisliste]$JtPreisliste
    [String]$FilenameTemplate

    JtFolder_Meta_BxH() : base() {
        $This.ClassName = "JtFolder_Meta_BxH"

        Write-JtLog -Where $This.ClassName -Text "Init."        
        $This.JtPreisliste = New-JtPreisliste_Plotten_2020_07_01
        $This.FilenameTemplate = -join ("_NACHNAME.VORNAME.LABEL.PAPIER.BxH", [JtIo]::FileExtension_Folder)
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        Write-JtLog -Where $This.ClassName -Text "DoIt. ... for MyFolderPath: $MyFolderPath"

        $This.DoCleanSpecialFiles($MyFolderPath)
        $This.DoWriteFile_Meta($MyFolderPath)

        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        Write-JtLog -Where $This.ClassName -Text "MyInfo: $MyInfo"
    }

    [String]GetFilenameSpecial([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [String]$MyInfo = $This.GetInfo($MyFolderPath)
        [String]$MyLabel = $MyInfo
        [String]$MyExtension2 = [JtIo]::FileExtension_Meta_BxH
        [String]$MyResult = Get-JtIoFilename_Meta -Label $MyLabel -Extension2 $MyExtension2
        return $MyResult
    }

    [String]GetInfo([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

        [JtPreisliste]$MyJtPreisliste = $This.JtPreisliste
        [JtColRen]$MyJtColRenJtPreisliste_Price = New-JtColRenFileJtPreisliste_Price -JtPreisliste $MyJtPreisliste
        [Decimal]$MyDecPrice = 0
        if (!($MyJtIoFolder.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "Error!!! Please edit XML for TheJtIoFolder: $MyJtIoFolder"
            return 9990
        }
        
        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
        foreach ($File in $MyAlJtIoFiles) {
            [JtIoFile]$MyJtIoFile = $File
            [String]$MyFilePath = $MyJtIoFile.GetPath()
            [String]$MySheetPrice = $MyJtColRenJtPreisliste_Price.GetOutput($MyFilePath)
            [Decimal]$MyDecSheetPrice = Convert-JtString_To_Decimal -Text $MySheetPrice
    
            $MyDecPrice = $MyDecPrice + $MyDecSheetPrice
        }

        [String]$MyResult = Convert-JtDecimal_To_String2 -Decimal $MyDecPrice
        return $MyResult
    }
}

Function New-JtFolder_Meta_BxH {
    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtFolder_Meta_BxH]$MyJtFolder = New-Object JtFolder_Meta_BxH
    $MyJtFolder.DoIt($MyFolderPath)
    return $MyJtFolder.GetInfo($MyFolderPath)
}

class JtIndex : JtClass {

    JtIndex() {
        $This.ClassName = "JtIndex"
    }

    DoIt([String]$TheFolderPath) {
        Throw "DoIt in JtIndex should be overwritten."
    }
    
    [Boolean]DoWriteInFolder([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        if (!($MyJtIoFolder.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "Error!!! Please edit XML for MyJtIoFolder: $MyJtIoFolder"
            return $False
        }
        $This.DoRemoveFilesInFolder()
        $This.DoWriteFile_MetaInFolder()
        return $True
    }
    
    [Boolean]DoWriteFile_MetaIn([JtIoFolder]$TheJtIoFolderOutput) {
        [JtIoFolder]$MyJtIoFolderOutput = $TheJtIoFolderOutput

        [String]$MyFilenameOutput = $This.GetFilenameOutput()
        $MyFilenameOutput = Convert-JtLabel_To_Filename -Label $MyFilenameOutput
        
        if (!($MyJtIoFolderOutput.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "Folder does not exist!!! MyJtIoFolderOutput: $MyJtIoFolderOutput"
            return $False
        }
        
        [JtIoFolder]$MyJtIoFolder = $MyJtIoFolderOutput
        if (!($MyJtIoFolder.IsExisting())) {
            Write-JtError -Where $This.ClassName -Text "Folder does not exist!!! MyJtIoFolder: $MyJtIoFolder"
            return $False
        }

        [String]$MyFilePathOutput = $MyJtIoFolderOutput.GetFilePath($MyFilenameOutput)
        Write-JtIoFile -Where $This.ClassName -Text "DoWriteFile_MetaIn. WARNING. Creating MyFilenameOutput: $MyFilenameOutput" -FilePath $MyFilePathOutput
        $MyJtIoFolder.GetPath() | Out-File -FilePath $MyFilePathOutput -Encoding UTF8
        return $True
    }
    
    
    [String]GetLabel() {
        Throw "GetLabel should be overwritten"
        return $Null
    }
    
    [String]GetMdDoc([String]$TheFolderPath) {
        Throw "GetMdDoc should be overwritten"
        return $Null
    }
    
}

class JtIndex_Anzahl : JtIndex {

    JtIndex_Anzahl() {
        $This.ClassName = "JtIndex_Anzahl"
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        New-JtFolder_Csv_Files -FolderPath $MyFolderPath
        New-JtFolder_Meta_Anzahl -FolderPath $MyFolderPath
    }

    [String]GetLabel() {
        return "ANZAHL"
    }
}

Function New-JtIndex_Anzahl {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtIndex]$MyJtIndex = New-Object JtIndex_Anzahl
    $MyJtIndex.DoIt($MyFolderPath)
}

class JtIndex_Betrag : JtIndex {

    JtIndex_Betrag() {
        $This.ClassName = "JtIndex_Betrag"
    }

    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        New-JtFolder_Csv_Files_Alter -FolderPath $MyFolderPath
        New-JtFolder_Meta_Betrag -FolderPath $MyFolderPath
    }   

    [String]GetLabel() {
        return "BETRAG"
    }
}

Function New-JtIndex_Betrag {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtIndex]$MyJtIndex = New-Object JtIndex_Betrag
    $MyJtIndex.DoIt($MyFolderPath)
}

class JtIndex_BxH : JtIndex {

    [JtPreisliste]$JtPreisliste
    [String]$FilenameTemplate

    JtIndex_BxH() {
        $This.ClassName = "JtIndex_BxH"
        [JtPreisliste]$MyJtPreisliste = New-JtPreisliste_Plotten_2020_07_01
        $This.JtPreisliste = $MyJtPreisliste
    }

    DoCreateFileTemplate([String]$TheFolderPath) {
        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $TheFolderPath
        [String]$MyFilenameTemplate = $This.JtPreisliste.FilenameTemplate
        [String]$MyFilePathTemplate = $MyJtIoFolder.GetFilePath($MyFilenameTemplate)

        Write-JtError -Where $This.ClassName -Text "DoCreateFileTemplate. TemplateFile is missing. MyFilePathTemplate: $MyFilePathTemplate"
        Write-JtIoFile -Where $This.ClassName -Text "DoCreateFileTemplate. Creating file." -FilePath $MyFilePathTemplate
        Get-JtTimestamp | Out-File -FilePath $MyFilePathTemplate -Encoding utf8

    }

    DoCheckTemplateFile([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath

        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        [String]$MyFilter = -join ("*", [JtIo]::FileExtension_Folder)

        [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Filter $MyFilter
    
        if ($MyAlJtIoFiles.Count -eq 0) {
            $This.DoCreateFileTemplate($MyFolderPath)
        }
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        Write-JtLog -Where $This.ClassName -Text "DoIt. MyFolderPath: $MyFolderPath"

        [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
        [String]$MyFolderPath = $MyJtIoFolder.GetPath()

        Convert-JtIoFilenamesAtFolderPath -FolderPath $MyFolderPath
        

        New-JtFolder_Meta_BxH -FolderPath $MyFolderPath
        New-JtFolder_Md_BxH -FolderPath $MyFolderPath

        Write-JtLog -Where $This.ClassName -Text "DoIt. Calling New-JtFolder_Csv_Files ... for MyFolderPath: $MyFolderPath"
        New-JtFolder_Csv_Files -FolderPath $MyFolderPath
    }

    [String]GetLabel() {
        return "BxH"
    }
}

Function New-JtIndex_BxH {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtIndex]$MyJtIndex = New-Object JtIndex_BxH
    $MyJtIndex.DoIt($MyFolderPath)
}

class JtIndex_Default : JtIndex {

    JtIndex_Default() {
        $This.ClassName = "JtIndex_Default"
    }
    
    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        New-JtFolder_Csv_Files -FolderPath $MyFolderPath
    }

    [String]GetLabel() {
        return "DEFAULT"
    }
}

Function New-JtIndex_Default {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtIndex]$MyJtIndex = New-Object JtIndex_Default
    $MyJtIndex.DoIt($MyFolderPath)
}

class JtIndex_Zahlung : JtIndex {

    JtIndex_Zahlung() {
        $This.ClassName = "JtIndex_Zahlung"
    }

    DoIt([String]$TheFolderPath) {
        [String]$MyFolderPath = $TheFolderPath
        New-JtFolder_Csv_Files -FolderPath $MyFolderPath
        New-JtFolder_Meta_Zahlung -FolderPath $MyFolderPath
        New-JtFolder_Md_Zahlung -FolderPath $MyFolderPath
    }

    [String]GetLabel() {
        return "Zahlung"
    }
}

Function New-JtIndex_Zahlung {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [JtIndex]$MyJtIndex = New-Object JtIndex_Zahlung
    $MyJtIndex.DoIt($MyFolderPath)
}

Function Convert-JtFolderPath_To_Betrag_For_Year {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $False)][ValidateNotNullOrEmpty()][Int16]$Year
    )

    [String]$MyFunctionName = "Convert-JtFolderPath_To_Betrag_For_Year"
    
    [String]$MyFolderPath = $FolderPath
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath

    if (!($MyJtIoFolder.IsExisting())) {
        Write-JtError -Where $MyFunctionName -Text "Folder is not existing! MyJtIoFolder: $MyJtIoFolder"
        return 0
    }
    
    [Decimal]$MyDecResult = 0
    [String]$MyFilterPrefix = "20" 
    if ($Year) {
        [String]$MyFilterPrefix = $Year 
    } 

    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
    Foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File
        [String]$MyFilePath = $MyJtIoFile.GetPath()
        [Decimal]$MyDecBetrag = 0

        [String]$MyFilename = $MyJtIoFile.GetName()
        if ($MyFilename.StartsWith($MyFilterPrefix)) {
            if (Test-JtFilename_Betrag_IsValid -Filename $MyFilename) {
                [String]$MyFilename = $MyJtIoFile.GetName()
                [Decimal]$MyDecBetrag = Convert-JtFilename_To_DecBetrag -Filename $MyFilename
            }
            else {
                [JtIoFolder]$MyJtIoFolder = $MyJtIoFile.GetJtIoFolder_Parent()
                [String]$MyFolderPath = $MyJtIoFolder.GetPath()
                [String]$MyFilePath = $MyJtIoFile.GetPath()
                Write-JtFolder -Text "Problem with file; EURO (in GetInfo) MyFolderPath: $MyFolderPath" -FilePath $MyFilePath

                Return 9991
            }
            $MyDecResult = $MyDecResult + $MyDecBetrag
        }
        else {
            # Write-JtLog -Where $MyFunctionName -Text "Ignoring file. FilePath: $MyFilePath"
        }
    }
    [String]$MyResult = Convert-JtDecimal_To_String2 -Decimal $MyDecResult
    return $MyResult
}

Function Get-JtFolderYears {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath
    )

    [String]$MyFolderPath = $FolderPath
    [String]$MyFunctionName = "Get-JtFolderYears"

    Write-JtLog -Where $MyFunctionName -Text "Starting..."
    [JtList]$MyJtList = New-JtList
    
    
    [JtIoFolder]$MyJtIoFolder = New-JtIoFolder -FolderPath $MyFolderPath
    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder -Normal
    ForEach ($File in  $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File
        [String]$MyFilename = $MyJtIoFile.GetName()
        $Year = Convert-JtFilename_To_Jahr -Filename $MyFilename
        $MyJtList.Add($Year)
    }
    [System.Collections.ArrayList]$MyAlYears = $MyJtList.GetValues()
    return $MyAlYears
}



class JtFacFolderRen : JtClass {

    [JtIndex]$JtIndex
    [String]$Kind = "default"
    
    JtFacFolderRen([JtIoFile]$TheJtIoFile) {
        
        [JtIoFile]$MyJtIoFile = $TheJtIoFile
        
        [String]$MyFilePath = $MyJtIoFile.GetPath()

        $This.JtIndex = $This.GetJtIndex_Default()
        $This.Kind = $This.JtIndex.GetLabel()

        if ($MyFilePath.EndsWith(".ANZAHL.folder")) {
            $This.JtIndex = $This.GetJtIndex_Anzahl()
            $This.Kind = $This.JtIndex.GetLabel()
        }

        if ($MyFilePath.EndsWith(".BxH.folder")) {
            $This.JtIndex = $This.GetJtIndex_BxH()
            $This.Kind = $This.JtIndex.GetLabel()
        }

        if ($MyFilePath.EndsWith(".BETRAG.folder")) {
            $This.JtIndex = $This.GetJtIndex_Betrag()
            $This.Kind = $This.JtIndex.GetLabel()
        }

        if ($MyFilePath.EndsWith(".PREIS.folder")) {
            $This.JtIndex = $This.GetJtIndex_Betrag()
            $This.Kind = $This.JtIndex.GetLabel()
        }

        if ($MyFilePath.EndsWith(".ZAHLUNG.folder")) {
            $This.JtIndex = $This.GetJtIndex_Zahlung()
            $This.Kind = $This.JtIndex.GetLabel()
        }
    }

    [JtIndex]GetJtIndex() {
        return $This.JtIndex
    }

    [JtIndex]GetJtIndex_Anzahl() {
        [JtIndex]$Ren = [JtIndex_Anzahl]::new()
        return $Ren
    }


    [JtIndex]GetJtIndex_Betrag() {
        [JtIndex]$Ren = [JtIndex_Betrag]::new()
        return $Ren
    }

    [JtIndex]GetJtIndex_Default() {
        [JtIndex]$Ren = [JtIndex_Default]::new()
        return $Ren
    }

    [JtIndex]GetJtIndex_BxH() {
        [JtIndex]$Ren = [JtIndex_BxH]::new()
        return $Ren
    }

    [JtIndex]GetJtIndex_Zahlung() {
        [JtIndex]$Ren = [JtIndex_Zahlung]::new()
        return $Ren
    }

    [String]GetKind() {
        return $This.Kind
    }
}

Function Update-JtMetaFilesInTree {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathInput,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPathOutput
    )

    [String]$MyFunctionName = "Update-JtMetaFilesInTree"
    
    [String]$MyFolderPath_Input = $FolderPathInput
    [String]$MyFolderPath_Output = $FolderPathOutput
    [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyFolderPath_INput 
    [JtIoFolder]$MyJtIoFolder_Output = New-JtIoFolder -FolderPath $MyFolderPath_Output 

    [String]$MyFilter = -join ("*", [JtIo]::FileExtension_Folder)
    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder_Input -Filter $MyFilter -Recurse
    
    # $MyAlJtIoFiles.Count
    
    foreach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File
        [JtIoFolder]$MyJtIoFolder_Parent = $MyJtIoFile.GetJtIoFolder_Parent()

        Write-JtLog -Where $MyFunctionName -Text "Folder... MyJtIoFolder_Parent: $MyJtIoFolder_Parent"

        [JtFacFolderRen]$MyJtFacFolderRen = [JtFacFolderRen]::new($MyJtIoFile)
        [JtIndex]$MyJtIndex = $MyJtFacFolderRen.GetJtIndex()

        $MyJtIndex.DoIt($MyJtIoFolder_Parent)
    }
}

Function Get-JtSum_From_FolderPath {

    Param (
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$FolderPath,
        [Parameter(Mandatory = $True)][ValidateNotNullOrEmpty()][String]$Partname
    )

    [String]$MyFolderPath_Input = $FolderPath
    [JtIoFolder]$MyJtIoFolder_Input = New-JtIoFolder -FolderPath $MyFolderPath_Input

    [String]$MyColumn = $Partname
    [Decimal]$MySum = 0
    if (!($MyJtIoFolder_Input.IsExisting())) {
        Write-JtError -Where $This.ClassName -Text "Error!!! Please edit XML for MyJtIoFolder: $MyJtIoFolder_Input"
        return "0"
    }
    [JtTemplateFile]$MyJtTemplateFile = Get-JtTemplateFile -FolderPath $MyJtIoFolder_Input
    [String]$MyFilenameTemplate = $MyJtTemplateFile.GetName()
    [System.Collections.ArrayList]$MyAlJtIoFiles = Get-JtChildItem -FolderPath $MyJtIoFolder_Input -Normal
    ForEach ($File in $MyAlJtIoFiles) {
        [JtIoFile]$MyJtIoFile = $File

        [String]$MyFilename = $MyJtIoFile.GetName()
        [String]$MyValue = Convert-JtFilename_To_Info_With_Template -Filename $MyFilename -FilenameTemplate $MyFilenameTemplate -Field $MyColumn
        [Decimal]$MyDecValue = Convert-JtString_To_Decimal -Text $MyValue -Part
        $MySum = $MySum + $MyDecValue
    }


    [String]$MyResult = Convert-JtDecimal_To_String2 -Decimal $MySum
    return $MyResult
}


Export-ModuleMember -Function New-JtFacFolderRen

Export-ModuleMember -Function New-JtFolder_Csv_Files
Export-ModuleMember -Function New-JtFolder_Csv_Files_Alter

Export-ModuleMember -Function New-JtFolder_Md
Export-ModuleMember -Function New-JtFolder_Md_Zahlung
Export-ModuleMember -Function New-JtFolder_Md_BxH

Export-ModuleMember -Function New-JtFolder_Meta_Anzahl 
Export-ModuleMember -Function New-JtFolder_Meta_Betrag 
Export-ModuleMember -Function New-JtFolder_Meta_BxH
Export-ModuleMember -Function New-JtFolder_Meta_Zahlung

Export-ModuleMember -Function New-JtIndex_Anzahl
Export-ModuleMember -Function New-JtIndex_Betrag
Export-ModuleMember -Function New-JtIndex_BxH
Export-ModuleMember -Function New-JtIndex_Default
Export-ModuleMember -Function New-JtIndex_Zahlung

Export-ModuleMember -Function Update-JtMetaFilesInTree

Export-ModuleMember -Function Convert-JtFolderPath_To_Betrag_For_Year
Export-ModuleMember -Function Get-JtFolderYears

