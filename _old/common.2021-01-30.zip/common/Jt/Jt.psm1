﻿# using module JtIo

    
<# 
    FARBEN
    
    Black 
    DarkBlue 
    DarkGreen 
    DarkCyan 
    DarkRed 
    DarkMagenta 
    DarkYellow 
    Gray 
    DarkGray 
    Blue 
    Green 
    Cyan 
    Red 
    Magenta 
    Yellow
    White
    #> 

    
Function Get-JtVersion {
    return "2021-01-25"
}






    
class JtClass {

    hidden [String]$ClassName = "CLASSNAME not set!!!"

    hidden [Boolean]$BlnWriteLogToFile = $False
    hidden [Boolean]$BlnDevMode = $False

    static [String]$Version = "2021-01-24"
    static [System.Char]$Delimiter = ";"

    [String]GetVersion() {
        [String]$Result = [JtClass]::Version
        return $Result
    } 




    # not used? 
    static [System.Collections.Specialized.OrderedDictionary]GetDic($Hash) {
        $dictionary = [ordered]@{ }
        if ($Hash -is [System.Collections.Hashtable]) {
            $keys = $Hash.keys | Sort-Object
            foreach ($key in $keys) {
                $dictionary.add($key, $Hash[$key])
            }
            return $dictionary
        }
        elseif ($Hash -is [System.Array]) {
            for ($i = 0; $i -lt $hash.count; $i++) {
                $dictionary.add($i, $hash[$i])
            }
            return $dictionary
        }
        elseif ($Hash -is [System.Collections.Specialized.OrderedDictionary]) {
            return $dictionary
        }

        elseif ($Null -eq $Hash ) {
            Write-JtError -Text "STATIC GetDic. Hash is null!"
            return $dictionary
        }
        else {
            Write-JtError -Text "STATIC GetDic. Enter a hash table or an array. GetType: $Hash.getType()"
            return $dictionary
        }

        <# 
 .SYNOPSIS
 Converts a hash table or an array to an ordered dictionary. 
 
 .DESCRIPTION
 ConvertTo-OrderedDictionary takes a hash table or an array and 
 returns an ordered dictionary. 
 
 If you enter a hash table, the keys in the hash table are ordered 
 alphanumerically in the dictionary. If you enter an array, the keys 
 are integers 0 - n.
 
 .PARAMETER $hash
 Specifies a hash table or an array. Enter the hash table or array, 
 or enter a variable that contains a hash table or array.

 .INPUTS
 System.Collections.Hashtable
 System.Array

 .OUTPUTS
 System.Collections.Specialized.OrderedDictionary

 .EXAMPLE
 PS c:\> $myHash = @{a=1; b=2; c=3}
 PS c:\> .\ConvertTo-OrderedDictionary.ps1 -Hash $myHash

 Name Value     
 ---- -----     
 a 1     
 b 2     
 c 3 

 .EXAMPLE
 PS c:\> $myHash = @{a=1; b=2; c=3}
 PS c:\> $myHash = .\ConvertTo-OrderedDictionary.ps1 -Hash $myHash
 PS c:\> $myHash

 Name Value     
 ---- -----     
 a 1     
 b 2     
 c 3
 

 PS c:\> $myHash | Get-Member
 
 TypeName: System.Collections.Specialized.OrderedDictionary
 . . .

 .EXAMPLE
 PS c:\> $colors = "red", "green", "blue"
 PS c:\> $colors = .\ConvertTo-OrderedDictionary.ps1 -Hash $colors
 PS c:\> $colors

 Name Value     
 ---- -----     
 0 red     
 1 green     
 2 blue 

 
 .LINK
 about_hash_tables
#>

    }


    JtClass() {
    }
} 

class JtLog {
    
    static [String]$C_inventory = "c:\_inventory"
    static [String]$C_inventory_Report = "c:\_inventory\report"

    static [String]$FilePathError = $Null
    static [String]$FilePathFolder = $Null
    static [String]$FilePathLog = $Null
    static [String]$FilePathIo = $Null
    
    static [int32]$CounterError = 0
    static [int32]$CounterFolder = 0
    static [int32]$CounterIo = 0
    static [int32]$CounterLog = 0

    [String]$Text = ""
    [Boolean]$BlnWriteLogToFile = $True
    JtLog([String]$MyText) {
        $This.Text = $MyText
    }

    static [String]GetFileNameError([String]$Value) {
        [String]$MyName = -join ("log", ".", $Value, ".", "error", ".md")
        return $MyName
    }
    
    static [String]GetFileNameFolder([String]$Value) {
        # [String]$MyName = -join ("log", ".", $Value, ".", "folder", ".bat")
        # Do not use timestamp in name. Always use the same name...
        [String]$MyName = -join ("check", ".", "folder", ".bat")
        return $MyName
    }
    
    static [String]GetFileNameIo([String]$Value) {
        [String]$MyName = -join ("log", ".", $Value, ".", "io", ".md")
        return $MyName
    }
    
    static [String]GetFileNameLog([String]$Value) {
        [String]$MyName = -join ("log", ".", $Value, ".", "log", ".md")
        return $MyName
    }

    static [String]GetFilePathError() {
        if (([JtLog]::FilePathError).Length -lt 1) {
            [String]$Timestamp = Get-JtTimestamp 
            [String]$MyName = [JtLog]::GetFileNameError($Timestamp)
            [String]$MyPath = -join ([JtLog]::C_inventory_Report, "\", $MyName)
            [JtLog]::FilePathError = $MyPath
        }
        return [JtLog]::FilePathError
    }

    static [String]GetFilePathIo() {
        if (([JtLog]::FilePathIo).Length -lt 1) {
            [String]$Timestamp = Get-JtTimestamp
            [String]$MyName = [JtLog]::GetFileNameIo($Timestamp)
            [String]$MyPath = -join ([JtLog]::C_inventory_Report, "\", $MyName)
            [JtLog]::FilePathIo = $MyPath
        }
        return [JtLog]::FilePathIo
    }

    static [String]GetFilePathFolder() {
        if (([JtLog]::FilePathFolder).Length -lt 1) {
            [String]$Timestamp = Get-JtTimestamp
            [String]$MyName = [JtLog]::GetFileNameFolder($Timestamp)
            [String]$MyPath = -join ([JtLog]::C_inventory_Report, "\", $MyName)
            [JtLog]::FilePathFolder = $MyPath
        }
        return [JtLog]::FilePathFolder
    }
    
    static [String]GetFilePathLog() {
        if (([JtLog]::FilePathLog).Length -lt 1) {
            [String]$LogFolderPath = [JtLog]::C_inventory_Report
            New-Item -ItemType Directory -Force -Path $LogFolderPath 
        }
        if (([JtLog]::FilePathLog).Length -lt 1) {
            [String]$Timestamp = Get-JtTimestamp
            [String]$MyName = [JtLog]::GetFileNameLog($Timestamp)
            [String]$MyPath = -join ([JtLog]::C_inventory_Report, "\", $MyName)
            [JtLog]::FilePathLog = $MyPath
        }
        return [JtLog]::FilePathLog
    }
 

    DoPrintError() {
        [String]$Output = $This.Text
        $This.DoPrintLog()

        [String]$MyFilePathError = [JtLog]::GetFilePathError()
        
        if ([JtLog]::CounterError -lt 1) {
            [String]$Filter = -join ("*", [JtLog]::FileNameError)
            [String]$PathReport = [JtLog]::C_inventory_Report
            [String]$MyMsg = "DoPrintError. Filter: $Filter - Deleting in path: $PathReport"
            Write-Host -ForegroundColor Black -BackgroundColor DarkYellow  $MyMsg
            try {
                Get-Childitem -Path $PathReport -Filter $Filter -File | Remove-Item -Filter $Filter -Force
            }
            catch {
                Write-Host "DoPrintError. Error while deleting file...."
            }
        }
        
        [JtLog]::CounterError = [JtLog]::CounterError + 1
        [String]$Type = "ERROR"
        [String]$Counter = [JtLog]::CounterError

        [String]$Message = "$Type NR: $Counter - $Output"
        [String]$MyLine = "* $Message"
        
        Add-content -path $MyFilePathError -value $MyLine
        Write-Host -ForegroundColor Black -BackgroundColor Red $Message
        
        [String]$Timestamp = Get-JtTimestamp
        [String]$MyTime = "  * Time $Timestamp"
        Add-content -path $MyFilePathError -value $MyTime
    } 
    
    DoPrintFolder([String]$Path) {
        [String]$Output = $This.Text
        [String]$MyFilePathFolder = [JtLog]::GetFilePathFolder()
        
        if ([JtLog]::CounterFolder -lt 1) {
            [String]$Filter = [JtLog]::GetFileNameFolder("*")
            [String]$PathReport = [JtLog]::C_inventory_Report
            [String]$Message = "DoPrintFolder. Filter: $Filter - Deleting in path: $PathReport"
            Write-Host -ForegroundColor Black -BackgroundColor DarkYellow $Message
            try {
                Get-Childitem -Path $PathReport -Filter $Filter | Remove-Item -Filter $Filter -Force
            }
            catch {
                Write-Host "DoPrintFolder. Error while deleting file...."
            }
        }

        [JtLog]::CounterFolder = [JtLog]::CounterFolder + 1
        [String]$Type = "FOLDER"
        [String]$Counter = [JtLog]::CounterFolder
        [String]$Message = "$Type NR: $Counter -  $Output"
        [String]$MyLine = "@echo $Output"
        
        Add-content -path $MyFilePathFolder -value $MyLine
        Write-Host -ForegroundColor White -BackgroundColor Magenta $Message
        Write-Host -ForegroundColor White -BackgroundColor Magenta "PATH: $Path"
        
        [String]$MyLine = -join ('explorer.exe', ' ', '"', $Path, '"')
        Add-content -path $MyFilePathFolder  -value $MyLine

        [String]$MyLine = "@echo -----------------------------------------"
        Add-content -path $MyFilePathFolder -value $MyLine

        [String]$MyLine = "pause"
        Add-content -path $MyFilePathFolder -value $MyLine
        
        [String]$MyLine = "cls"
        Add-content -path $MyFilePathFolder -value $MyLine
    } 

    DoPrintIo() {
        [String]$Output = $This.Text
        [String]$MyFilePathIo = [JtLog]::GetFilePathIo()

        if ([JtLog]::CounterIo -lt 1) {
            [String]$Filter = [JtLog]::GetFileNameIo("*")
            [String]$PathReport = [JtLog]::C_inventory_Report
            [String]$Msg = "DoPrintIo. $Filter - Deleting in path: $PathReport"
            Write-Host -ForegroundColor Black -BackgroundColor DarkYellow $Msg
            try {
                Get-Childitem -Path $PathReport -Filter $Filter | Remove-Item -Filter $Filter -Force
            }
            catch {
                Write-Host "DoPrintIo. Error while deleting file...."
            }
        }
        
        [JtLog]::CounterIo = [JtLog]::CounterIo + 1
        [String]$Type = "IO_"
        [String]$Counter = [JtLog]::CounterIo
        [String]$Message = "$Type NR: $Counter - $Output"
        [String]$MyLine = "* $Message"
        
        Add-content -path $MyFilePathIo -value $MyLine
        Write-Host -ForegroundColor Black -BackgroundColor DarkYellow $Message
        
        [String]$Timestamp = Get-JtTimestamp
        [String]$MyTime = "  * Time $Timestamp"
        Add-content -path $MyFilePathIo -value $MyTime
    } 

    DoPrintIoIntern() {
        [String]$Output = $This.Text
        [String]$MyFilePathIo = [JtLog]::GetFilePathIo()

        if ([JtLog]::CounterIo -lt 1) {
            [String]$Filter = [JtLog]::GetFileNameIo("*")
            [String]$PathReport = [JtLog]::C_inventory_Report
            [String]$Msg = "DoPrintIo. $Filter - Deleting in path: $PathReport"
            Write-Host -ForegroundColor Blue -BackgroundColor DarkYellow $Msg
            try {
                Get-Childitem -Path $PathReport -Filter $Filter | Remove-Item -Filter $Filter -Force
            }
            catch {
                Write-Host "DoPrintIo. Error while deleting file...."
            }
        }
        
        [JtLog]::CounterIo = [JtLog]::CounterIo + 1
        [String]$Type = "IO"
        [String]$Counter = [JtLog]::CounterIo
        [String]$Message = "$Type NR: $Counter - $Output"
        [String]$MyLine = "* $Message"
        
        Add-content -path $MyFilePathIo -value $MyLine
        Write-Host -ForegroundColor Black -BackgroundColor DarkYellow $Message
        
        [String]$Timestamp = Get-JtTimestamp
        [String]$MyTime = "  * Time $Timestamp"
        Add-content -path $MyFilePathIo -value $MyTime
    } 
    
    DoPrintLog() {
        [String]$Output = $This.Text
        [String]$MyFilePathLog = [JtLog]::GetFilePathLog()

        if ([JtLog]::CounterLog -lt 1) {
            [String]$Filter = [JtLog]::GetFileNameLog("*")
            [String]$PathReport = [JtLog]::C_inventory_Report
            [String]$Msg = "DoPrintLog. Filter: $Filter - Deleting in path: $PathReport"
            Write-Host -ForegroundColor Black -BackgroundColor DarkYellow $Msg
            try {
                Get-Childitem -Path $PathReport -Filter $Filter | Remove-Item -Filter $Filter -Force
            }
            catch {
                Write-Host "DoPrintLog. Error while deleting file...."
            }
        }
        
        [JtLog]::CounterLog = [JtLog]::CounterLog + 1
        [String]$Type = "LOG"
        [String]$Counter = [JtLog]::CounterLog
        [String]$Message = "$Type NR: $Counter - $Output"
        [String]$MyLine = "* $Message"

        if ($This.BlnWriteLogToFile) {
            Add-content -path $MyFilePathLog -value $MyLine
        }

        Write-Host -ForegroundColor Black -BackgroundColor Blue $Message
        [String]$Timestamp = Get-JtTimestamp
        [String]$MyTime = "  * Time $Timestamp"
        Add-content -path $MyFilePathLog -value $MyTime
    } 
}


Function Write-JtLog {
    Param (
        [Parameter(Mandatory = $true)]
        [String]$Text,
        [Parameter(Mandatory = $false)]
        [String]$Class
    )

    [String]$MyText = $Text
    if (!($Class)) {
        $MyText = $MyText
    }
    else {
        $MyText = "Class: $Class, $MyText"
    }

    [JtLog]$JtLog = [JtLog]::new($MyText)
    $JtLog.DoPrintLog()
}

Function Write-JtError {

    Param (
        [Parameter(Mandatory = $false)]
        [String]$Class,
        [Parameter(Mandatory = $true)]
        [String]$Text
    )

    [String]$MyText = $Text
    if (!($Class)) {
        $MyText = $MyText
    }
    else {
        $MyText = "Class: $Class, $MyText"
    }

    [JtLog]$JtLog = [JtLog]::new($MyText)
    $JtLog.DoPrintError()

}


Function Write-JtFolder {

    Param (
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String]$Text,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String]$Path,
        [Parameter(Mandatory = $false)][ValidateNotNullOrEmpty()][String]$Class
    )

    [String]$MyText = $Text
    if (!($Class)) {
        $MyText = $MyText
    }
    else {
        $MyText = "Class: $Class, $MyText"
    }
    
    [JtLog]$JtLog = [JtLog]::new($MyText)
    $JtLog.DoPrintFolder($Path)
}

Function Write-JtIo {

    Param (
        [Parameter(Mandatory = $false)][ValidateNotNullOrEmpty()][String]$Class,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String]$Text,
        [Parameter(Mandatory = $true)][ValidateNotNullOrEmpty()][String]$Path
    )
    
    [String]$MyText = -join($Text, " --- PATH: ", $Path)
    if (!($Class)) {
        $MyText = $MyText
    }
    else {
        $MyText = "Class: $Class, $MyText"
    }
    
    [JtLog]$JtLog = [JtLog]::new($MyText)
    $JtLog.DoPrintIo()
}

Function Write-JtIoIntern {

    Param (
        [Parameter(Mandatory = $true)]
        [String]$Text,
        [Parameter(Mandatory = $false)]
        [String]$Class
    )
    
    [String]$MyText = $Text
    if (!($Class)) {
        $MyText = $MyText
    }
    else {
        $MyText = "Class: $Class, $MyText"
    }
    
    [JtLog]$JtLog = [JtLog]::new($MyText)
    $JtLog.DoPrintIoIntern()

}


class JtToolWol : JtClass {

    [String]$WolExe = -join ("c:\apps\tools\wol\wol.exe")
    [String]$Label = ""
    [String]$Mac = ""

    JtToolWol([String]$MyLabel, [String]$MyMac) {
        $This.ClassName = "JtToolWol"
        $This.Label = $MyLabel
        $This.Mac = $MyMac
    }

    JtToolWol([String]$Computername) {
        $This.ClassName = "JtToolWol"
        $This.Label = $Computername

        [String]$MyMac = [JtToolWol]::GetMac($Computername)

        if ($MyMac.Length -lt 1) {
            Write-JtError -Class $This.ClassName -Text "No MAC address found for computer: $Computername"
        }

        $This.Mac = $MyMac
    }    

    
    static [String]GetMac([String]$ComputerName) {
        [Hashtable]$Macs = [ordered]@{
            "al-its-pc-g01" = "18:66:DA:31:6C:DB"
            "al-its-pc-g02" = "18:66:DA:31:76:D0"
            "al-its-pc-g03" = "18:66:DA:31:7B:77"
            "al-its-pc-g04" = "18:66:DA:31:7E:FC"
            "al-its-pc-g05" = "18:66:DA:31:7B:46"
            "al-its-pc-g06" = "18:66:DA:31:70:5D"
            "al-its-pc-g07" = "18:66:DA:31:79:0C"
            "al-its-pc-g08" = "18:66:DA:31:7D:E1"
            "al-its-pc-g09" = "18:66:DA:31:7E:EB"
            "al-its-pc-g10" = "18:66:DA:31:84:1E"
            "al-its-pc-g11" = "18:66:DA:31:7D:C9"
            "al-its-pc-g12" = "18:66:DA:31:7B:A4"
            "al-its-pc-g13" = "18:66:DA:31:7B:6B"
            "al-its-pc-g14" = "18:66:DA:31:79:63"
            "al-its-pc-g15" = "18:66:DA:31:72:F7"
            "al-its-pc-g16" = "18:66:DA:31:7C:7F"
            "al-its-pc-g17" = "18:66:DA:31:7D:7D"
            "al-its-pc-g18" = "18:66:DA:31:83:06"
            "al-its-pc-g19" = "18:66:DA:31:7B:8B"
            "al-its-pc-h01" = "00:4E:01:A0:DD:4A"
            "al-its-pc-h02" = "00:4E:01:A0:C1:D8"
            "al-its-pc-h03" = "00:4E:01:A0:72:21"
            "al-its-pc-h04" = "00:4E:01:A1:0D:F8"
            "al-its-pc-h05" = "00:4E:01:A0:6A:CD"
            "al-its-pc-h06" = "00:4E:01:A0:DC:69"
            "al-its-pc-h07" = "00:4E:01:9F:07:96"
            "al-its-pc-h08" = "00:4E:01:A0:93:28"
            "al-its-pc-h09" = "00:4E:01:9F:03:8A"
            "al-its-pc-h10" = "00:4E:01:A0:95:7B"
            "al-its-pc-h11" = "00:4E:01:9F:03:FB"
            "al-its-pc-h12" = "00:4E:01:A0:DB:9E"
            "al-its-pc-h13" = "00:4E:01:9F:03:7F"
            "al-its-pc-h14" = "00:4E:01:A0:DC:E3"
            "al-its-pc-h15" = "00:4E:01:9F:03:9E"
            "al-its-pc-h16" = "00:4E:01:A0:93:BB"
            "al-its-pc-h17" = "00:4E:01:A0:FF:7E"
            "al-its-pc-h18" = "00:4E:01:9F:35:9E"
            "al-its-pc-h19" = "00:4E:01:A1:08:E3"
            "al-its-pc-h20" = "00:4E:01:A1:08:D6"
            "al-its-pc-h21" = "00:4E:01:9F:04:92"
            "al-its-pc-h22" = "00:4E:01:A0:FF:A2"
            "al-its-pc-h23" = "00:4E:01:A0:93:39"
            "al-its-pc-h24" = "00:4E:01:9F:04:1A"
            "al-its-pc-h25" = "00:4E:01:A1:08:DF"
            "al-its-pc-h26" = "00:4E:01:A0:DD:21"
            "al-its-pc-h27" = "00:4E:01:9F:32:5C"
            "al-its-pc-h28" = "00:4E:01:A0:67:91"
            "al-its-pc-h29" = "00:4E:01:A0:DB:83"
            "al-its-pc-h30" = "00:4E:01:9F:03:90"
            "al-its-pc-h31" = "00:4e:01:a0:c1:2b"
            "al-its-pc-h32" = "00:4E:01:A1:0C:B6"
            "al-its-pc-h33" = "00:4E:01:9F:04:7D"
            "al-its-pc-h34" = "00:4E:01:A0:FF:C3"
            "al-its-pc-h35" = "00:4E:01:A0:C9:45"
            "al-its-pc-h36" = "00:4E:01:A0:BA:E3"
            "al-its-pc-h37" = "00:4E:01:A0:93:7E"
            "al-its-pc-h38" = "00:4E:01:A0:B6:BE"
        }
        [String]$MyMac = $Macs.$Computername 

        return $MyMac
    }

    
    [Boolean]DoIt() {
        [String]$TheLabel = $This.Label
        [String]$TheMac = $This.Mac
        Write-JtLog -Class $This.ClassName -Text "JtToolWol; Label: $TheLabel; MAC: $TheMac"

        [String]$TheArgs = -join (" ", $This.Mac)


        if (Test-Path $This.WolExe) {
            Write-JtLog -Class $This.ClassName -Text "WOL args: $TheArgs"
            Start-Process -NoNewWindow -FilePath $This.WolExe -ArgumentList $TheArgs -Wait 
            return $true
        }
        else {
            [String]$MyWolExe = $This.WolExe
            Write-JtError -Class $This.ClassName -Text "ERROR! JtToolWol. wol.exe is missing: $MyWolExe"

            if ($This.ExitOnError -eq $True) {
                Exit
            }
            return $false
        }
    }
}



Function Get-JtTimestamp {
    
    $D = Get-Date
    [String]$Timestamp = $D.toString("yyyy-MM-dd_HH-mm-ss")
    Return $Timestamp
 
}

Function Get-JtDate {
    
    $D = Get-Date
    [String]$Timestamp = $D.toString("yyyy-MM-dd")
    Return $Timestamp
 
}

Function Convert-JtDecimalToString2([Decimal]$InputDec) {
    [Decimal]$MyDec = $InputDec
    
    [String]$Result = $MyDec.ToString("0.00")
    $Result = $Result.Replace(".", ",")
    
    return $Result
}

Function Convert-JtDecimalToString3([Decimal]$InputDec) {
    [Decimal]$MyDec = $InputDec

    [String]$Result = $MyDec.ToString("0.000")
    $Result = $Result.Replace(".", ",")

    return $Result
}

Function Convert-JtFileNameToArea([String]$Filename) {
    [String]$TheFilename = $FileName
    $Parts = $TheFilename.Split(".")
    [String]$MyFlaeche = ""
    try {
        [String]$MySize = $Parts[$Parts.count - 2]
        $SizeParts = $MySize.Split("x")
        if ($SizeParts.Count -lt 2) {
            Write-JtError -Class $This.ClassName -Text "Problem with FLAECHE in file: $TheFilename"
        }
        else {
            [String]$Breite = $SizeParts[0]
            [String]$Hoehe = $SizeParts[1]
            [Int32]$IntBreite = [Int32]$Breite
            [Int32]$IntHoehe = [Int32]$Hoehe
            [Int32]$IntFlaeche = $IntBreite * $IntHoehe
            [Decimal]$DecFlaeche = [Decimal]$IntFlaeche / 1000 / 1000
            # [Decimal]$DecFlaeche = [Decimal]$IntFlaeche
            [String]$MyFlaeche = $DecFlaeche.ToString("0.000")
            # [String]$MyFlaeche = $DecFlaeche.ToString("0")
            # $MyFlaeche = $MyFlaeche.Replace(",", ".")
        }
    }
    catch {
        Write-JtError -Class $This.ClassName -Text "Problem with FLAECHE in file: $TheFilename"
    }
    return $MyFlaeche
}

Function Convert-JtStringToDecimal([String]$MyInput) {
    [String]$Result = $MyInput
    $Result = $Result.Replace(",", ".")
    return [Decimal]$Result
}

Function Convert-JtStringToGb([String]$Memory) {
    [String]$In = $Memory
    [String]$Result = ""
    [int64]$IntNum = 0
    if ($Null -eq $In) {
        Write-JtError -Text "ConvertTo_StringToGb problem; input was NULL"
        return "NULL"
    }
    try {
        [int64]$IntNum = $In.ToInt64($Null)

    }
    catch {
        Write-JtError -Class $This.ClassName -Text "ConvertTo_StringToGb problem; INPUT: $In"
        return "ERROR"
    }
    [single]$Mini = $IntNum / 1024 / 1024 / 1024
    [int]$MiniInt = $Mini
    [String]$Giga = -join ($MiniInt , "")

    $Result = $Giga
    return $Result
} 

# quelle https://www.datenteiler.de/powershell-umlaute-ersetzen/
Function Convert-JtReplaceUmlaute([String]$Text) {
    $UmlautObject = New-Object PSObject | Add-Member -MemberType NoteProperty -Name Name -Value $Text -PassThru
    
    # hash tables are by default case insensitive
    # we have to create a new hash table object for case sensitivity 
    
    $characterMap = New-Object system.collections.hashtable
    $characterMap.ä = "ae"
    $characterMap.ö = "oe"
    $characterMap.ü = "ue"
    $characterMap.Ä = "Ae"
    $characterMap.Ö = "Oe"
    $characterMap.Ü = "Ue"         
    $characterMap.ß = "ss"
    
    foreach ($property  in 'Name') { 
        foreach ($key in $characterMap.Keys) {
            $UmlautObject.$property = $UmlautObject.$property -creplace $key, $characterMap[$key] 
        }
    }
    
    $UmlautObject
    return $UmlautObject.Name
} # Replace-Umlaute 

Function Convert-JtLabelToFilename([String]$MyInput) {
    [String]$Result = $MyInput
    $Result = $Result.Replace(",", "_")
    $Result = $Result.Replace(" ", "_")
    $Result = $Result.Replace("+", "_plus_")
    $Result = $Result.Replace("&", "_und_")
    $Result = $Result.Replace("__", "_")
    $Result = Convert-JtReplaceUmlaute $Result
    $Result = $Result.Trim()
    return $Result
}




Function Convert-JtExpandedPath {

    Param (
        [Parameter(Mandatory = $true)]
        [String]$Path
    )

    [String]$Result = $Path
    if ($Null -eq $Result) {
        $Result = ""
    }
    $Result = $Result.Replace("%OneDrive%", $env:OneDrive)
    $Result = $Result.Replace("%COMPUTERNAME%", $env:COMPUTERNAME)
    $Result = $Result.Replace("%temp%", $env:TEMP)

    return $Result
} 


# is in development mode?
Function Get-JtDevMode() {

    Write-JtLog -Class $This.ClassName -Text "DEV__________________________________"
    if ($env:COMPUTERNAME -eq "AL-DEK-NB-DEK05") {
        return $True
    }
    elseif ($env:COMPUTERNAME -eq "G13-AL-PC-DELL") {
        return $True
    }
    else {
        return $False
    }
}


Function Get-JtZufallszahl6 {
    [int16]$Stellen = 6
    [Int32]$Zufallszahl = Get-Random
    [String]$Zufallswort = "" + $Zufallszahl
    [String]$zufall = $Zufallswort.Substring(0, $Stellen)
    return $Zufall
}


Function Convert-JtIpToIp3 ([String]$IP) {
    [String]$MyFullIp = $IP
    $Parts = $MyFullIP.Split(".")        

    [String]$MyIp3 = ""
    if ($Parts.Count -eq 4) {
        $MyIP3 = $Parts[3]
    }
    else {
        $MyIp3 = "ERROR: $MyFullIP"
    }
    return $MyIp3
}




class JtTimeStop : JtClass {

    hidden [String]$Label
    hidden [DateTime]$TimeBegin
    hidden [DateTime]$TimeEnd
    hidden [timespan]$Duration 

    JtTimeStop() {
        $This.ClassName = "JtTimeStop"

    } 

    [String]GetMessageBegin([DateTime]$Time) {
        [String]$Message = ""
        $Message = -join ("___ Timer ", $Time, " --- ", "(Begin)", " ", " --- ", $This.Label)
        return $Message
    } 

    [String]GetMessageDuration([Timespan]$Timespan) {
        [String]$Message = ""
        $Message = -join ("=== Timer ", " ", $Timespan, " --- ", "(Duration)", " --- ", $This.Label)
        return $Message
    } 

    [String]GetMessageEnd([DateTime]$Time) {
        [String]$Message = ""
        $Message = -join ("___ Timer ", $Time, " --- ", "(End) ", " ", " --- ", $This.Label)
        return $Message
    } 


    Start([String]$Label) {
        $This.Label = $Label
        [DateTime]$D = Get-Date
        [String]$TheTimeBegin = $D
        $This.TimeBegin = $D
        Write-JtLog -Class $This.ClassName -Text $This.GetMessageBegin($TheTimeBegin)
    } 
    
    Stop() {
        [DateTime]$D = Get-Date
        [String]$TheTimeEnd = $D
        $This.TimeEnd = $TheTimeEnd
        
        Write-JtLog -Class $This.ClassName -Text $This.GetMessageEnd($TheTimeEnd)
        $This.Duration = $This.TimeEnd - $This.TimeBegin

        [String]$TheDuration = $This.Duration

        Write-JtLog -Class $This.ClassName -Text $This.GetMessageDuration($TheDuration)
    } 
} 

Function New-JtTimeStop {
    [JtTimeStop]::new()
}


Class JtTimer : JtClass {

    [String]$Name = ""

    $TimeStart
    $TimeEnd
    $TimeDuration

    $BlnStop


    JtTimer([String]$MyName) {
        $This.ClassName = "JtTimer"
        $This.Name = $MyName
        $This.BlnStop = $False
        $This.TimeStart = Get-Date
    }

    Sleep([int32]$Seconds) {
        Start-Sleep -Seconds $Seconds
    }

    Measure() {
        $This.TimeEnd = Get-Date
        $This.BlnStop = $True
        $This.TimeDuration = $This.TimeEnd - $This.TimeStart
    }

    Report() {
        if ($This.BlnStop -eq $False) {
            $Null = $This.Measure()
        }
        Write-Host "=================================="
        Write-Host "Timer   :" $This.Name
        Write-Host "=================================="
        Write-Host "Start   :" $This.TimeStart
        Write-Host "End     :" $This.TimeEnd
        Write-Host "=================================="
        Write-Host "Duration:" $This.TimeDuration
        Write-Host "=================================="
    }
}
