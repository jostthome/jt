using module JtInfi
using module JtInf_Soft
using module JtRep
using module JtTbl

class JtRep_Software : JtRep {
 
    JtRep_Software () : Base("software") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        [JtInf_Soft]$JtInf_Soft = $JtInfi.GetJtInf_Soft()
        [Object[]]$Fields = $JtInf_Soft.GetFields()

        foreach ($Field in $Fields) {
            [JtFldSoft]$JtFldSoft = $Field

            [JtField]$Fld = New-JtField -Label $JtFldSoft.GetLabel() -Value $JtFldSoft.GetValue()
            $JtTblRow.AddValue($JtInf_Soft.($Fld))
        }
 
        return $JtTblRow
    }
}

function New-JtRep_Software {

    [JtRep_Software]::new() 

}



