using module JtIo
using module JtUtil

class JtIoFile : JtIo {

    hidden [Boolean]$BlnExists = $true

    static [String]$FilePrefixAnzahl = "zzz"
    static [String]$FilePrefixArea = "zzz"
    static [String]$FilePrefixCount = "zzz"
    static [String]$FilePrefixFolder = "zzz"
    static [String]$FilePrefixSum = "zzz"

    static [String]$FileExtensionCsv = ".csv"
    static [String]$FileExtensionMd = ".md"
    static [String]$FileExtensionMeta = ".meta"
    static [String]$FileExtensionXml = ".xml"
    
    static [String]$FileExtensionArea = ".area"
    static [String]$FileExtensionCount = ".count"
    static [String]$FileExtensionFolder = ".folder"
    static [String]$FileExtensionWhg = ".whg"
    static [String]$FileExtensionPoster = ".poster"
    static [String]$FileExtensionSum = ".sum"
    
    JtIoFile([String]$MyPath) {
        $This.ClassName = "JtIoFile"
        $This.Path = $MyPath
        $This.BlnExists = Test-Path -Path $MyPath
    }
    
    [Boolean]DoRenameFile([String]$NewName) {
        Write-JtIo -Text ( -join ("Renaming file to ", $NewName, " at path ", $This.GetPath()))
        Rename-Item -Path $This.GetPath() -NewName $NewName
        # [JtIoFile]$NewFile = [JtIoFile]::new($This.)
        return $True
    }

    [Boolean]IsExisting() {
        $This.BlnExists = [System.IO.File]::Exists($This.GetPath())
        return $This.BlnExists
    }

    [Boolean]IsSpecialFile() {
        [Boolean]$IsSpecial = $False
        if ($This.GetName().Equals("desktop.ini")) {
            $IsSpecial = $True
            return $IsSpecial
        }  
        
        [String]$MyExtension = $This.GetExtension()
        
        $MyList = New-Object System.Collections.Generic.List[System.Object]
        $MyList.Add([JtIoFile]::FileExtensionArea)
        $MyList.Add([JtIoFile]::FileExtensionCount)
        $MyList.Add([JtIoFile]::FileExtensionCsv)
        $MyList.Add([JtIoFile]::FileExtensionFolder)
        $MyList.Add([JtIoFile]::FileExtensionMd)
        $MyList.Add([JtIoFile]::FileExtensionWhg)
        $MyList.Add([JtIoFile]::FileExtensionPoster)
        $MyList.Add([JtIoFile]::FileExtensionSum)
        
        foreach ($Extension in $MyList) {
            if ($Extension.Equals($MyExtension)) {
                $IsSpecial = $True
                return $IsSpecial
            }
        }
        
        return $IsSpecial
    }
    
   
    [String]GetExtension() {
        [String]$Result = [System.IO.Path]::GetExtension($This.Path)
        Return $Result
    }

    [String]GetFileTimestamp() {
        [String]$Timestamp = ""
        [Boolean]$FileOk = $This.IsExisting
 
        if ($FileOk) {
            [System.Object[]]$JtObjects = Get-ChildItem -Path $This.Path
            [System.IO.FileSystemInfo]$File = $JtObjects[0]
            $Timestamp = $File.LastWriteTime.ToString([JtIo]::TimestampFormat)
        }
        return $Timestamp
    }

    # First column has number 0
    [String]GetFieldAtPos([String]$MyInput, [Int16]$MyPos) {
        $MyInputParts = $MyInput.Split(".")

        if ($MyInputParts.Count -lt $MyPos) {
            return ""
        }

        return $MyInputParts[$MyPos]
    }
    
    [String]GetInfoFromFileName_Age() {
        [String]$TheFilename = $This.GetName()

        [String]$MyAlter = "0"
        
        [String]$Year = $This.GetInfoFromFilename_Year()
        if ($Year.Length -gt 0 ) {
            $ThisDate = Get-Date
            $ThisYear = $ThisDate.Year
    
            # Aus "20-04" soll "2020" werden.
            $MySep = $Year.substring(2, 1)
            if ($MySep -eq "-") {
                $Year = -join ("20", $Year.substring(0, 2))
            } 
            try {
                $MyAlter = $ThisYear - $Year
            }
            catch {
                $MyAlter = "0"
                Write-JtError -Text ( -join ("Problem with ThisYear:", $ThisYear, " in Filename:", $TheFilename))
            }
        }
        else {
            return "0"
        }
        return $MyAlter
    }

    [String]GetInfoFromFileName_Area() {
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyFlaeche = ""
        try {
            [String]$MySize = $Parts[$Parts.count - 2]
            $SizeParts = $MySize.Split("x")
            if ($SizeParts.Count -lt 2) {
                Write-JtError -Text ( -join ("Problem with FLAECHE in file:", $TheFilename))
                Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
            }
            else {
                [String]$Breite = $SizeParts[0]
                [String]$Hoehe = $SizeParts[1]
                [Int32]$IntBreite = [Int32]$Breite
                [Int32]$IntHoehe = [Int32]$Hoehe
                [Int32]$IntFlaeche = $IntBreite * $IntHoehe
                [Decimal]$DecFlaeche = [Decimal]$IntFlaeche / 1000 / 1000
                # [Decimal]$DecFlaeche = [Decimal]$IntFlaeche
                [String]$MyFlaeche = $DecFlaeche.ToString("0.000")
                # [String]$MyFlaeche = $DecFlaeche.ToString("0")
                # $MyFlaeche = $MyFlaeche.Replace(",", ".")
            }
        }
        catch {
            Write-JtError -Text ( -join ("Problem with FLAECHE in file:", $TheFilename))
            Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
        }
        return $MyFlaeche
    }
    
    
    
    
    [String]GetInfoFromFileName_Count() {
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyCount = "0"
        try {
            [String]$MyInt = $Parts[$Parts.count - 2]
            [Decimal]$DecInt = [Decimal]$MyInt / 1
            $MyCount = $DecInt
        }
        catch {
            Write-JtError -Text ( -join ("Problem with COUNT in file:", $TheFilename))
            Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
        }
        return $MyCount
    }

    [Boolean]GetInfoFromFileName_Count_IsValid() {
        [Boolean]$Result = $True
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyCount = "0"
        try {
            [String]$MyInt = $Parts[$Parts.count - 2]
            [Decimal]$DecInt = [Decimal]$MyInt / 1
            $MyCount = $DecInt
        }
        catch {
            Write-JtError -Text ( -join ("Problem with COUNT - not valid - in file:", $TheFilename))
            $Result = $False
        }
        return $Result
    }
    
    [String]GetInfoFromFileName_Dim() {
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyDim = ""
        try {
            [String]$MyDim = $Parts[$Parts.count - 2]
            $MyDim = $MyDim.Replace("x", " x ")
        }
        catch {
            Write-JtError -Text ( -join ("Problem with Dim in file:", $TheFilename))
            Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
        }
        return $MyDim
    }

    [String]GetInfoFromFileName([String]$JtTemplateFileName, [String]$TheFilename, [String]$Field) {
        [String]$Result = ""
        $TemplateParts = $JtTemplateFileName.Split(".")

        for ([Int16]$i = 0; $i -lt $TemplateParts.Count; $i = $i + 1 ) {
            [String]$TemplatePart = $TemplateParts[$i]
            if ($TemplatePart -eq $Field) {
                $Result = $This.GetFieldAtPos($TheFilename, $i)
            }

        }
        return $Result
    }
    
    [String]GetInfoFromFileName_Euro() {
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyEuro = ""
        try {
            [String]$MyCents = $Parts[$Parts.count - 2]
            $MyCents = $MyCents.Replace("_", "")
            [Decimal]$MyEuroDec = [Decimal]$MyCents / 100
            [String]$MyEuro = $MyEuroDec.ToString("0.00")
            $MyEuro = $MyEuro.Replace(".", ",")
        }
        catch {
            Write-JtError -Text ( -join ("Problem with EURO in file:", $TheFilename))
            Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
        }
        return $MyEuro
    }
    
    [Boolean]GetInfoFromFileName_Euro_IsValid() {
        [Boolean]$Result = $True
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyEuro = ""
        try {
            [String]$MyCents = $Parts[$Parts.count - 2]
            $MyCents = $MyCents.Replace("_", "")
            [Decimal]$MyEuroDec = [Decimal]$MyCents / 100
            [String]$MyEuro = $MyEuroDec.ToString("0.00")
            $MyEuro = $MyEuro.Replace(".", ",")
        }
        catch {
            Write-JtError -Text ( -join ("Problem with EURO - not valid - in file:", $TheFilename))
            $Result = $False
        }
        return $Result
    }
    
    [String]GetInfoFromFileName_Paper() {
        [String]$TheFilename = $This.GetName()
        $Parts = $TheFilename.Split(".")
        [String]$MyPaper = "xxxx"
        try {
            [String]$MyPaper = $Parts[$Parts.count - 3]
        }
        catch {
            Write-JtError -Text ( -join ("Problem with PAPIER in file:", $TheFilename))
            Write-JtError -Text ( -join ("FilePath:", $This.GetPath()))
        }
        return $MyPaper
    }
    
    [String]GetInfoFromFilename_Year() {
        [String]$TheFilename = $This.GetName()
        
        [String]$MyJahr = $TheFilename.substring(0, 4)
        
        try {
            # Aus "20-04" soll "2020" werden.
            $MySep = $MyJahr.substring(2, 1)
            if ($MySep -eq "-") {
                $MyJahr = -join ("20", $MyJahr.substring(0, 2))
            } 
        }
        catch {
            $MyJahr = ""
            Write-JtError -Text ( -join ("Problem with file:", $TheFilename))
        }
        return $MyJahr
    }

    [String]GetLabelForFilename() {
        [String]$Result = ""
        $Elements = $This.GetName().Split(".")
        [String]$Result = $Elements[0]
                
        return $Result
    }

    [String]GetName() {
        [String]$Result = [System.IO.Path]::GetFileName($This.Path)
        Return $Result
    }

    [String]GetNameWithoutExtension() {
        [String]$Result = $This.GetName()

        $Result = $Result.Replace($This.GetExtension(), "")

        Return $Result
    }  
    
    
    [String]GetPathOfFolder() {
        [String]$Result = $This.GetPath()
        $Result = $Result.Replace( -join ("\", $This.GetName()), "")
        return $Result
    }
}

Function New-JtIoFile {
    
    Param (
        [Parameter(Mandatory=$true)]
        [String]$Path
    )

    [JtIoFile]::new($Path)
}

class JtIoFileCsv : JtIoFile {
    
    JtIoFileCsv([String]$MyPath) : Base($MyPath) {
        $This.ClassName = "JtIoFileCsv"
    }

    [System.Collections.ArrayList]GetSelection([String]$Column) {
        $MyArrayList = [System.Collections.ArrayList]@()

        $Csv = Import-Csv -Path $This.Path -Delimiter ([JtUtil]::Delimiter)
        $Elements = $Csv | Select-Object -Property $Column | Sort-Object -Property $Column

        foreach ($Element in $Elements) {

            [String]$TheElement = $Element.$Column
            # [JtIoFile]$MyFile = [JtIoFile]::new($Element)
            $MyArrayList.Add($TheElement)
        }

        return $MyArrayList
    }
}

Function New-JtIoFileCsv {
    
    Param (
        [Parameter(Mandatory=$true)]
        [String]$Path
    )

    [JtIoFileCsv]::new($Path)
}

