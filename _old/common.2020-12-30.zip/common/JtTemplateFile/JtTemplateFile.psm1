using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtColRen

class JtTemplateFile : JtClass {

    [JtIoFile]$JtIoFile = $Null
    [JtIoFolder]$JtIoFolder = $Null
    [String]$JtTemplateFileExtension = $Null
    [String]$JtTemplateFileName = ""
    [Boolean]$Valid = $False
    
    static [JtColRen]GetJtColRen([String]$Part) {
        [JtColRen]$JtColRen = New-JtColRenInputText -Label $Part
        if ($Part.ToLower() -eq "preis") {
            $JtColRen = New-JtColRenInputCurrencyPreis
        }
        elseif ($Part.ToLower() -eq "_____datum") {
            $JtColRen = New-JtColRenInputDatum 
        }
        elseif ($Part.ToLower() -eq "breitexhoehe") {
            $JtColRen = New-JtColRenInputText -Label "B x H"
        } 
        elseif ($Part.ToLower() -eq "_nachname") {
            $JtColRen = New-JtColRenInputText -Label "NACHNAME"
        } 
        elseif ($Part.ToLower() -eq "bxh") {
            $JtColRen = New-JtColRenInputText -Label "bxh" -Header "B x H"
        }         
        elseif ($Part.ToLower() -eq "anzahl") {
            $JtColRen = New-JtColRenInputAnzahl 
        }
        elseif ($Part.ToLower() -eq "betrag") {
            $JtColRen = New-JtColRenInputCurrencyBetrag
        }
        elseif ($Part.ToLower() -eq "gesamt") {
            $JtColRen = New-JtColRenInputCurrency -Label "GESAMT"
        }
        elseif ($Part.ToLower() -eq "miete") {
            $JtColRen = New-JtColRenInputCurrency -Label "MIETE"
        }
        elseif ($Part.ToLower() -eq "nebenkosten") {
            $JtColRen = New-JtColRenInputCurrency -Label "NEBENKOSTEN"
        }
        elseif ($Part.ToLower() -eq "stand") {
            $JtColRen = New-JtColRenInputStand
        }
        elseif ($Part.ToLower() -eq "euro") {
            $JtColRen = New-JtColRenInputCurrencyEuro
        }
        elseif ($Part.ToLower() -eq "0000-00") {
            $JtColRen = New-JtColRenInputMonthId
        }
        return $JtColRen
    }



    JtTemplateFile([JtIoFolder]$MyFolder) {
        $This.ClassName = "JtTemplateFile"
        $This.JtIoFolder = $MyFolder
        $This.JtTemplateFileExtension = [JtIoFile]::FileExtensionFolder
        $This.DoInit()
        
    }
    
    JtTemplateFile([JtIoFolder]$MyFolder, [String]$MyExtension) {
        $This.ClassName = "JtTemplateFile"
        $This.JtIoFolder = $MyFolder
        $This.JtTemplateFileExtension = $MyExtension
        $This.DoInit()
        
    }

    # [JtIoFile]GetJtTemplateFile() {
    #     [String]$MyExtension = $This.GetJtTemplateFileExtension()
    #     [JtIoFile]$JtIoFile = $Null
    #     [String]$MyFilter = -join ("*", $MyExtension)
    #     [System.Collections.ArrayList]$FolderFiles = $This.JtIoFolder.GetJtIoFilesWithFilter($MyFilter) 
    #     if ($Null -eq $FolderFiles) {
    #         Write-JtError -Text ( -join ("This should not happen. FolderFiles is null for JtIoFolder ", $This.JtIoFolder.GetPath()))
    #     }
    #     elseif ($FolderFiles.Count -lt 1) {
    #         Write-JtError -Text ( -join ("This should not happen. No FolderFile in JtIoFolder ", $This.JtIoFolder.GetPath()))
    #     }
    #     elseif ($FolderFiles.Count -gt 1) {
    #         Write-JtError -Text ( -join ("This should not happen. More than one FolderFiles in JtIoFolder ", $This.JtIoFolder.GetPath()))
    #     }
    #     else {
    #         [JtIoFile]$JtIoFile = $FolderFiles[0]
    #     }
    #     return $JtIoFile
    # }

    [Boolean]DoInit() {
        [String]$Filter = -join ("*", $This.JtTemplateFileExtension)
        [System.Collections.ArrayList]$TheFiles = $This.JtIoFolder.GetJtIoFilesWithFilter($Filter, $False)
        $This.JtIoFile = $null
        if ($TheFiles.Count -gt 0) {
            $This.JtIoFile = $TheFiles[0]
            $This.Valid = $True
            $This.JtTemplateFileName = $This.JtIoFile.GetName()
        }
        else {
            $This.Valid = $False

            Write-JtError -Text ( -join ("Template file is missing. Folder:", $This.JtIoFolder.GetPath()))
        }
        return $True
    }



    [Boolean]IsValid() {
        return $This.Valid
    }
    [JtColRen]GetJtColRenForColumnNumber([Int16]$IntCol) {
        [System.Collections.ArrayList]$JtColRens = $This.GetJtColRens()
        if($IntCol -lt $JtColRens.Count) {
            return $JtColRens[$IntCol]
        } else {
            [String]$MyLabel = -join("Column_Number_", $IntCol)
            [JtColRen]$JtColRen = New-JtColRenInputText -Label $MyLabel
            Write-JtError -Text (-join("Problem with column number ", $IntCol) )
        }
        return $JtColRen
    }

    [System.Collections.ArrayList]GetJtColRens() {
        $TemplateParts = $This.JtTemplateFileName.Split(".")
 
        [System.Collections.ArrayList]$JtColRens = [System.Collections.ArrayList]::new()
        foreach ($Part in $TemplateParts) {
            [JtColRen]$MyJtColRen = [JtTemplateFile]::GetJtColRen($Part) 
            $JtColRens.Add($MyJtColRen)
        }
        return $JtColRens
    }

    [Int16]GetJtColRensCount() {
        [System.Collections.ArrayList]$JtColRens = $This.GetJtColRens()
        [Int32]$NumTemplateParts = $JtColRens.Count
        return $NumTemplateParts
    }

    [Boolean]GetHasColumnForAnzahl() {
        [JtColRen]$ColCompare = New-JtColRenInputAnzahl
        return $This.GetHasColumnOfType($ColCompare)
    }
    
    [Boolean]GetHasColumnForArea() {
        [JtColRen]$ColCompare = New-JtColRenInputArea
        return $This.GetHasColumnOfType($ColCompare)
    }
    
    [Boolean]GetHasColumnForEuro() {
        [JtColRen]$ColCompare = New-JtColRenInputCurrencyEuro
        return $This.GetHasColumnOfType($ColCompare)
    }

    [Boolean]GetHasColumnOfType([JtColRen]$JtColRen) {
        [Boolean]$Result = $false
        [System.Collections.ArrayList]$JtColRens = $This.GetJtColRens()
        
        [JtColRen]$ColCompare = $JtColRen
        foreach ($MyJtColRen in $JtColRens) {
            [JtColRen]$JtColRen = $MyJtColRen
            if ($ColCompare -eq $JtColRen) {
                $Result = $true
                return $Result
            }
        }
        return $Result
    }

    [String]GetJtTemplateFileName() {
        return $This.JtTemplateFileName
    }

}


Function New-JtTemplateFile {
    Param (
        [Parameter(Mandatory=$true)]
        [JtIoFolder]$JtIoFolder,
        [Parameter(Mandatory=$false)]
        [String]$Extension
    )

    [JtTemplateFile]::new($JtIoFolder, $Extension)
}

