using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSecurity : JtRep {

    JtRep_SoftwareSecurity() : Base("software.security") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().WinVersion)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Flash)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Java)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Opsi)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AntiVirus)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().CiscoAnyConnect)

        return $JtTblRow
    }
}


function New-JtRep_SoftwareSecurity {

    [JtRep_SoftwareSecurity]::new() 

}


