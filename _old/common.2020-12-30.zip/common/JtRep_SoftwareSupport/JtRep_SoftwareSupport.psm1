using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSupport : JtRep {

    JtRep_SoftwareSupport() : Base("software.support") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32ComputerSystem().Herst)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32ComputerSystem().Modell)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().LenovoSysUp)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellCommand)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellSuppAs)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Opsi)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seadrive)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seafile)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DokanLibrary)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().CiscoAnyConnect)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().WinVersion)

        return $JtTblRow
    }

}


function New-JtRep_SoftwareSupport {

    [JtRep_SoftwareSupport]::new() 

}

