using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Server : JtRep {

    JtRep_Z_Server() : Base("z.server") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().WinVersion)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seadrive)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seafile)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().ServerViewAgents)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Bacula)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Java)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AntiVirus)

        return $JtTblRow
    }
}

function new-JtRep_Z_Server {

    [JtRep_Z_Server]::new() 

}



