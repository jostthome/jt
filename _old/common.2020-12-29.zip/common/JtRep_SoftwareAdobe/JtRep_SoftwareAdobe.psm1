using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareAdobe : JtRep {

    JtRep_SoftwareAdobe () : Base("software.adobe") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_CreativeSuite_CS6())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Acrobat_DC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Photoshop_CC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Indesign_CC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Illustrator_CC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AfterEffects_CC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Flash())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Air())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AcrobatReader())
        
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())

        return $JtTblRow
    }
}



function New-JtRep_SoftwareAdobe {

    [JtRep_SoftwareAdobe]::new() 

}


