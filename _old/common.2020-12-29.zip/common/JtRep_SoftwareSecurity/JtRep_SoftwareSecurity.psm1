using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSecurity : JtRep {

    JtRep_SoftwareSecurity() : Base("software.security") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Flash())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Java())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Opsi())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AntiVirus())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_CiscoAnyConnect())


        return $JtTblRow
    }
}


function New-JtRep_SoftwareSecurity {

    [JtRep_SoftwareSecurity]::new() 

}


