using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareMicrosoftNormal : JtRep {
    
    JtRep_SoftwareMicrosoftNormal() : Base("software.microsoft.normal") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)
    
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsVersion())
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinGen())
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinBuild())
    
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office365())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_OfficeLabel())

        return $JtTblRow
    }
    
}




function New-JtRep_SoftwareMicrosoftNormal {

    [JtRep_SoftwareMicrosoftNormal]::new() 

}
