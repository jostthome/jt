using module JtTbl
using module JtInf_Soft
using module JtInfi
using module JtRep

class JtRep_Z_Pools : JtRep {

    JtRep_Z_Pools() : Base("z.pools") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_OfficeStandard()) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_CreativeSuite_CS6())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AutoCAD_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Max_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Revit_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Allplan_2019())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_ArchiCAD())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Vectorworks())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Cinema4D())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_SketchUp())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Rhino_6()) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRay3ds())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRevit())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRhino())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRaySketchup())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_BkiKosten())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_BkiPos())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_IbpHighend())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Orca())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_GoogleEarth())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Arduino())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_RawTherapee())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LibreOffice())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AcrobatReader())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AntiVirus())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Chrome())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Chromium())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Firefox64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Java())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Krita())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_PDF24())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellCommand())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellSuppAs())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Sumatra())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_VLC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_WibuKey())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Zip())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsVersion())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().Get_Grafikkarte())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().Get_TreiberVersion()) 
    
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())

        return $JtTblRow
    }

}


function New-JtRep_Z_Pools {

    [JtRep_Z_Pools]::new() 

}

