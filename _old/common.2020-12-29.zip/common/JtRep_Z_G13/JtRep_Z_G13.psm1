using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_G13 : JtRep {

    JtRep_Z_G13() : Base("z.g13") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)
        
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AffinityDesigner())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AffinityPhoto())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AffinityPublisher())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Revit_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office365())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seadrive())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seafile())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LibreOffice())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Firefox64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Thunderbird64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AcrobatReader())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Inkscape())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellCommand())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellSuppAs())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DokanLibrary())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Flash())
        
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())
        
        return $JtTblRow
    }

}



function New-JtRep_Z_G13 {

    [JtRep_Z_G13]::new() 

}


