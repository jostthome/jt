using module JtTbl
using module JtInf_Soft
using module JtInfi
using module JtRep


class JtRep_Obj_Uninstall32 : JtRep {
 
    JtRep_Obj_Uninstall32() : Base("obj.uninstall32") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        foreach ($Field in $JtInfi.GetJtInf_Soft_Uninstall32().GetFieldsUninstall32()) {
            [JtFieldSoftware]$JtFieldSoftware = $Field
            [JtField]$JtField = $JtFieldSoftware
            $JtTblRow.AddValue($JtField)
        }

        return $JtTblRow
    }
}


function New-JtRep_Obj_Uninstall32 {

    [JtRep_Obj_Uninstall32]::new() 

}


