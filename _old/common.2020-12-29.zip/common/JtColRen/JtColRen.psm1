using module JtClass
using module JtUtil

class JtColRen : JtClass {

    [String]$Label = ""
    [String]$Header = ""

    JtColRen([String]$MyLabel) {
        $This.ClassName = "JtColRen"
        $This.Label = $MyLabel
        $This.Header = $MyLabel
    }

    JtColRen([String]$MyLabel, [String]$MyHeader) {
        $This.ClassName = "JtColRen"
        $This.Label = $MyLabel
        if($Null -eq $MyHeader) {
            $This.Header = $MyLabel
        } else {
            $This.Header = $MyHeader
        }
    }

    [Boolean]CheckValid([String]$Value) {
        return $True
    }


    [String]GetHeader() {
        return $This.Header
    }

    [String]GetLabel() {
        return $This.Label
    }

    [String]GetName() {
        return $This.ClassName
    }

    [String]GetOutput([String]$Value) {
        return $Value
    }

    [String]GetOutput_Betrag([String]$Value) {
        [String]$Result = $Value

        $Result = $Result.Replace("_", "")
        $Result = $Result.Replace(".", "")
        $Result = $Result.Replace(",", "")

        try {
            [Int32]$Inti = [Decimal]$Result
            [Decimal]$Decimal = $Inti / 100
            [String]$Result = $Decimal.ToString("N2")
        }
        catch {
            Write-JtError -Text ( -join ("Convert problem. Value:", $Value))
            return [String]"0,00".ToString()
        }
        return $Result
    }
    
    [Boolean]IsEqual([JtColRen]$JtColRen) {
        [Boolean]$Result = $false
        $TheLabel = $JtColRen.GetLabel()
        if ($TheLabel.Equals($This.GetLabel())) {
            return $True
        }
        else {
            return $Result
        }
    }

    [Boolean]IsSummable() {
        return $False
    }
}



class JtColRenInputAnzahl : JtColRen {
    
    
    JtColRenInputAnzahl() : Base() {
        $This.Label = "Anzahl"
        $This.Header = "Anzahl"
    }
    
    [Boolean]IsSummable() {
        return $True
    }


    [String]GetOutput([String]$Value) {
        [String]$Result = $Value
        return $Result
    }
}


Function New-JtColRenInputAnzahl {

    [JtColRenInputText]::new("Anzahl", "Anzahl")
}


class JtColRenInputArea : JtColRen {


    JtColRenInputArea() : Base("BREITExHOEHE") {
        $This.ClassName = "JtColRenInputArea"
    }

    [Boolean]CheckValid([String]$Value) {
        return $True
    }

    [String]GetOutput([String]$Value) {
        return $Value
    }
    

    
    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColRenInputArea {

    [JtColRenInputArea]::new()
}




class JtColRenInputCurrency : JtColRen {



    JtColRenInputCurrency([String]$MyLabel) : Base($MyLabel) {
        $This.ClassName = "JtColRenInputCurrency"
    }


    [Boolean]CheckValid([String]$Value) {
        [String]$WithoutUnderscore = $Value.Replace("_", "")
        try {
            [Int32]$IntValue = [Int32]$WithoutUnderscore
        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (int check). Value:", $Value))
            return $False
        }
        try {
            [String]$MyValue = $Value
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$DecValue = [Decimal]$MyValue
        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (decimal check). Value:", $Value))
            return $False
        }
        try {
            [String]$MyValue = $Value
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$DecValue = [Decimal]$MyValue
            [Int32]$IntValue = [Int32]$WithoutUnderscore
            [Decimal]$MyValueThroughInt = $IntValue / 100
            if (0 -ne ($MyValueThroughInt - $DecValue)) {
                Write-JtError -Text ( -join ("Value is not valid (comma check). Value:", $Value))
                return $False
            }
        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (decimal check). Value:", $Value))
            return $False
        }
        return $True
    }


    [Boolean]DoTest() {
        [Boolean]$TestOk = $True

        [String[]]$TestValues = @('Apples', 'Apples10', '00000', '2356323', '2323_23', '2323.23')
        [String[]]$TestOutputs = @('0,00', '0,00', '0,00', '23.563,23', '2.323,23', '2.323,23')

        for ([Int32]$i = 0; $i -lt $TestValues.Length; $i = $i + 1) {
            [String]$Test = $TestValues[$i]
            [String]$Should = $TestOutputs[$i]
            [String]$Is = $This.GetOutput($Test)

            $Test
            $Should
            $Is
            
            if ($Should -ne $Is) {
                Write-JtError -Text ( -join ("Result is not ok for value. Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
                $TestOk = $False
            }
            else {
                Write-JtLog -Text ( -join ("Result is OK for value. _____ Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
            }
        }
        return $TestOk
    }



    [String]GetOutput([String]$Value) {
        return $This.GetOutput_Betrag($Value)
    }


    [Boolean]IsSummable() {
        return $True
    }
}



Function New-JtColRenInputCurrency {

    Param (
        [Parameter(Mandatory=$true)]
        [String]$Label
    )

    [JtColRenInputCurrency]::new($Label)
}

Function New-JtColRenInputCurrencyBetrag {
    New-JtColRenInputCurrency -Label "BETRAG"
}



Function New-JtColRenInputCurrencyEuro {

    [JtColRenInputCurrency]::new("EURO")
}

Function New-JtColRenInputCurrencyPreis {

    [JtColRenInputCurrency]::new("PREIS")
}

Function New-JtColRenInputCurrencyGesamt {

    [JtColRenInputCurrency]::new("GESAMT")
}



class JtColRenInputDatum : JtColRen {

    JtColRenInputDatum() : Base("Datum") {
        $This.ClassName = "JtColRenInputDatum"
    }

    [Boolean]CheckValid([String]$Value) {
        return $True
    }

    [String]GetOutput([String]$Value) {
        return $Value
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColRenInputDatum {

    [JtColRenInputDatum]::new()
}


class JtColRenInputPrice: JtColRen {

    JtColRenInputPrice([String]$MyLabel) : Base($MyLabel) {
        $This.ClassName = "JtColRenInputPrice"
            $This.Header = "Preis"
    }

    [Boolean]DoTest() {
        [Boolean]$TestOk = $True

        [String[]]$TestValues = @('Apples', 'Apples10', '00000', '2356323', '2323_23', '2323.23')
        [String[]]$TestOutputs = @('0,00', '0,00', '0,00', '23.563,23', '2.323,23', '2.323,23')

        for ([Int32]$i = 0; $i -lt $TestValues.Length; $i = $i + 1) {
            [String]$Test = $TestValues[$i]
            [String]$Should = $TestOutputs[$i]
            [String]$Is = $This.GetOutput($Test)

            $Test
            $Should
            $Is
            
            if ($Should -ne $Is) {
                Write-JtError -Text ( -join ("Result is not ok for value. Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
                $TestOk = $False
            }
            else {
                Write-JtLog -Text ( -join ("Result is OK for value. _____ Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
            }
        }
        return $TestOk
    }

    [String]GetOutput([String]$Value) {
        [String]$Result = $Value

        $Result = $Result.Replace("_", "")
        $Result = $Result.Replace(".", "")
        $Result = $Result.Replace(",", "")

        try {
            [Int32]$Inti = [Decimal]$Result
            # [Decimal]$Decimal = $Inti / 100
            [Decimal]$Decimal = $Inti
            [String]$Result = $Decimal.ToString("N2")
        }
        catch {
            Write-JtError -Text ( -join ("Convert problem. Value:", $Value))
            return [String]"0,00".ToString()
        }
        return $Result
    }

    [Boolean]IsSummable() {
        return $True
    }


}







class JtColRenInputStand : JtColRen {

    JtColRenInputStand() : Base("Stand") {
    }

    [Boolean]CheckValid([String]$Value) {
        [String]$WithoutUnderscore = $Value.Replace("_", "")
        try {
            [Int32]$IntValue = [Int32]$WithoutUnderscore
        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (int check). Value:", $Value))
            return $False
        }
        try {
            [String]$MyValue = $Value
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$DecValue = [Decimal]$MyValue
        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (decimal check). Value:", $Value))
            return $False
        }
        try {
            [String]$MyValue = $Value
            $MyValue = $MyValue.Replace("_", ".")
            [Decimal]$DecValue = [Decimal]$MyValue
            [Int32]$IntValue = [Int32]$WithoutUnderscore
            [Decimal]$MyValueThroughInt = $IntValue / 1000
            if (0 -ne ($MyValueThroughInt - $DecValue)) {
                Write-JtError -Text ( -join ("Value is not valid (comma check). Value:", $Value))
                return $False
            }

        }
        catch {
            Write-JtError -Text ( -join ("Value is not valid (decimal check). Value:", $Value))
            return $False
        }
        return $True
    }



    [String]GetOutput([String]$Value) {
        [String]$Result = $Value

        $Result = $Result.Replace("_", "")
        $Result = $Result.Replace(".", "")
        $Result = $Result.Replace(",", "")

        try {
            [Int32]$Inti = [Decimal]$Result
            [Decimal]$Decimal = $Inti / 1000
            [String]$Result = $Decimal.ToString("N3")
        }
        catch {
            Write-JtError -Text ( -join ("Convert problem. Value:", $Value))
            return [String]"0,00".ToString()
        }
        return $Result
    }

    
    [Boolean]DoTest() {
        [Boolean]$TestOk = $True

        [String[]]$TestValues = @('Apples', 'Apples10', '00000', '2356323', '2323_23', '2323.23')
        [String[]]$TestOutputs = @('0,000', '0,000', '0,000', '23.563,230', '2.323,230', '2.323,230')

        for ([Int32]$i = 0; $i -lt $TestValues.Length; $i = $i + 1) {
            [String]$Test = $TestValues[$i]
            [String]$Should = $TestOutputs[$i]
            [String]$Is = $This.GetOutput($Test)

            $Test
            $Should
            $Is
            
            if ($Should -ne $Is) {
                Write-JtError -Text ( -join ("Result is not ok for value. Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
                $TestOk = $False
            }
            else {
                Write-JtLog -Text ( -join ("Result is OK for value. _____ Value:", $Test, " - Should be:", $Should, " - Is:", $Is))
            }
        }
        return $TestOk
    }


    [Boolean]IsSummable() {
        return $True
    }
}


class JtColRenInputSum : JtColRen {
    
    
    JtColRenInputSum() : Base("Summe") {
    }


    [String]GetOutput([String]$Value) {
        [String]$MyDec = [JtUtil]::GetConvert_DecimalToString2($Value)
        [String]$Result = $MyDec.Replace(",", "_")
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }

}


Function New-JtColRenInputSum {
    
    [JtColRenInputSum]::new()
}


class JtColRenInputText : JtColRen {

    [String] hidden $Label

    JtColRenInputText([String]$MyLabel) : Base($MyLabel) {
        $This.ClassName = "JtColRenInputText"
    }

    JtColRenInputText([String]$MyLabel, [String]$MyHeader) : Base($MyLabel, $MyHeader) {
        $This.ClassName = "JtColRenInputText"
    }



    [String]GetOutput([String]$Value) {
        return $Value
    }

    [Boolean]IsSummable() {
        return $False
    }

}


Function New-JtColRen {
    Param (
        [Parameter(Mandatory=$true)]
        [String]$Label,
        [Parameter(Mandatory=$false)]
        [String]$Header
    )

    [JtColRen]::new($Label, $Header)
}



Function New-JtColRenInputText {
    Param (
        [Parameter(Mandatory=$true)]
        [String]$Label,
        [Parameter(Mandatory=$false)]
        [String]$Header
    )

    [JtColRenInputText]::new($Label, $Header)
}

Function New-JtColRenInputTextNr {

    [JtColRenInputText]::new("NR", "NR")
}





Function New-JtColRenInputMonthId {

    [JtColRenInputText]::new("Monat", "Monat")
}

Function New-JtColRenInputStand {

    [JtColRenInputStand]::new()
}
