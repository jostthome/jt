# Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Jt\JtClient.psm1 
# Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Jt\JtMaster.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtClass\JtClass.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtConfig\JtConfig.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtIo\JtIo.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtTbl\JtTbl.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtUtil\JtUtil.psm1 

Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\ColRen\JtTemplateFile.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Csv\JtCsvWriter.psm1 

Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtImageTool.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtNsLookup.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtStoppUhr.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtTimer.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtFacFolderRen.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\FileElementXml.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\FileWriterMeta.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\Gen_Csvs_To_CsvsAll.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\Get-InstalledSoftware.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtImageMagick.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtMarkdown.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\JtPreisliste.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\X\Tool.psm1 

Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtFolderSummary\JtFolderSummary.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer_Count.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer_Default.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer_Miete.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer_Poster.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\FolRen\JtFolderRenderer_Sum.psm1 

Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_AFolder.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Bitlocker.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Soft.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Soft_InstalledSoftware.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Soft_Uninstall32.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Soft_Uninstall64.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32Bios.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32ComputerSystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32LogicalDisk.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32NetworkAdapter.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32OperatingSystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32Processor.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Inf\Inf_Win32VideoController.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtSearchSet\JtSearchSet_Software.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtSearchSet\JtSearchSet_Software_InstalledSoftware.psm1
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtSearchSet\JtSearchSet_Software_Uninstall32.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtSearchSet\JtSearchSet_Software_Uninstall64.psm1 



Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtSnapshot\JtSnapshot.psm1 

Write-Host "Rep"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep.psm1 


Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Bitlocker.psm1 
exit
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Folder.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Hardware.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_HardwareSn.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Net.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Uninstall32.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Uninstall64.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32Bios.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32Computersystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32LogicalDisk.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32NetworkAdapter.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32OperatingSystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32Processor.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Obj_Win32VideoController.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Software.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareAdobe.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareMicrosoft.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareMicrosoftNormal.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareOpsi.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareSecurity.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareSupport.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_SoftwareVray.psm1 
exit
Write-Host "Rep_Z_G13"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_G13.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_Iat.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_Lab.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_Pools.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_Server.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Z_Vorwag.psm1 

Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Obj.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Bitlocker.psm1 
exit
Write-Host "ObjXml_Soft"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_InstalledSoftware.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Soft_Uninstall32.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Soft_Uninstall64.psm1 
Write-Host "Init_Inf_Win32Bios"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32Bios.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32ComputerSystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32LogicalDisk.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32NetworkAdapter.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32OperatingSystem.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32Processor.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Init_Inf_Win32VideoController.psm1 


Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\JtColFile\JtColFile.psm1 
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\ColRen\ColRen.psm1 

Write-Host "Rep_Timestamps"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Rep\Rep_Timestamps.psm1 


Write-Host "Repo"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Repo\Repo.psm1 


Write-Host "JtCsvTool"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Csv\JtCsvTool.psm1 

Write-Host "JtCsvGenerator"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Csv\JtCsvGenerator.psm1 



Write-Host "Obj_Soft"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Obj_Soft.psm1 
exit

Write-Host "Infi"
Import-Module C:\Users\thome.ARCHLAND\OneDrive\0.INVENTORY\common\Obj\Infi.psm1 
exit