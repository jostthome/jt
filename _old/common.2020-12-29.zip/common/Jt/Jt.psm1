using module JtClass
using module JtConfig
using module JtIo
using module JtIoFolder
using module JtRepo

# $Host.UI.RawUI.BackgroundColor = ($bckgrnd = 'DarkGray')

class JtClient : JtClass {
    
    [JtConfig]$JtConfig
    [JtIoFolder]$FolderReport
    
    JtClient([JtConfig]$MyConfig) {
        $This.ClassName = "JtClient"
        $This.JtConfig = $MyConfig
        $This.FolderReport = $MyConfig.Get_JtIoFolder_Report()
    }

    [Boolean]DoClean() {
        [JtRepo]$Report = [JtRepo_Client_Clean]::New($This.JtConfig)
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "clean"
        $Report.DoIt()

        return $True
    }

    [Boolean]DoClient() {
        $This.DoClean()
        $This.DoUpdate()
        # $This.DoInstall()

        $This.DoReport()
        $This.DoObjects()
        $This.DoSoftware()
        $This.DoCsvs()
        
        # $This.DoFiles()
        # $This.DoFolders()
        # $This.DoLines()
        # $This.DoLengths()
        # $This.DoJtMarkdown()
        $This.DoExport()
        
        # $This.DoData()
        
        $This.DoErrors()
        $This.DoExport()
        return $True
    }

    
    [Boolean]DoConfig() {
        [JtRepo]$Report = New-JtRepo_Client_Config -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "config"
        $Report.DoIt()

        return $True
    }

    [Boolean]DoCsvs() {
        [JtRepo]$Report = New-JtRepo_Client_Csvs -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "csv"
        $Report.DoIt()

        return $True
    }

    [Boolean]DoData() {
        [JtRepo]$Report = New-JtRepo_Client_Data -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "data"
        $Report.DoIt()

        return $True
    }

    [Boolean]DoDownload() {
        [JtRepo]$Report = New-JtRepo_Client_Download -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "download"
        $Report.DoIt()

        return $True
    }

    [Boolean]DoErrors() {
        [JtRepo]$Report = New-JtRepo_Client_Errors -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "errors"
        $Report.DoIt()
        
        return $True
    }

    [Boolean]DoExport() {
        [JtRepo]$Report = New-JtRepo_Client_Export -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "export"
        $Report.DoIt()
        
        return $True
    }

    [Boolean]DoFiles() {
        [JtRepo]$Report = New-JtRepo_Client_Files -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "files"
        $Report.DoIt()
        
        return $True
    }

    [Boolean]DoFolders() {
        [JtRepo]$Report = New-JtRepo_Client_Folders -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "folders"
        $Report.DoIt()
        
        return $True
    }

    [Boolean]DoInstall() {
        [JtRepo]$Report = New-JtRepo_Client_Install -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "install"
        $Report.DoIt()
        
        return $True
    }

    
    [Boolean]DoLengths() {
        [JtRepo]$Report = New-JtRepo_Client_Lengths -JtConfig $This.JtConfig
        $Report.DoIt()

        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "lengths"
        $Report.DoIt()
        
        return $True
    }


    [Boolean]DoLines() {
        [JtRepo]$Report = New-JtRepo_Client_Lines -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "lines"
        $Report.DoIt()
        
        return $True
    }


    [Boolean]DoJtMarkdown() {
        [JtRepo]$Report = New-JtRepo_Client_JtMarkdown -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "JtMarkdown"
        $Report.DoIt()
        
        return $True
    }

        
    [Boolean]DoMiete() {
        [JtRepo]$Report = New-JtRepo_Client_Miete -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "miete"
        $Report.DoIt()
        
        return $True
    }

    
    [Boolean]DoMirror() {
        [JtRepo]$Report = New-JtRepo_Client_Mirror -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "mirror"
        $Report.DoIt()
        
        return $True
    }

        
    [Boolean]DoObjects() {
        [JtRepo]$Report = New-JtRepo_Client_Objects -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "objects"
        $Report.DoIt()
        
        return $True
    }
    
    [Boolean]DoPoster() {
        [JtRepo]$Report = New-JtRepo_Client_Poster -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "poster"
        $Report.DoIt()
        
        return $True
    }
    
    [Boolean]DoRecover() {
        [JtRepo]$Report = New-JtRepo_Client_Recover -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "recover"
        $Report.DoIt()
        
        return $True
    }
    
    [Boolean]DoRename() {
        [JtRepo]$Report = New-JtRepo_Client_Rename -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "rename"
        $Report.DoIt()
        
        return $True
    }
    
    
    [Boolean]DoReport() {
        [JtRepo]$Report = New-JtRepo_Client_Report -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "report"
        $Report.DoIt()
        
        return $True
    }
    
    
    [Boolean]DoSoftware() {
        [JtRepo]$Report = New-JtRepo_Client_Software -JtConfig $This.JtConfig
        $Report.DoIt()
            
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "software"
        $Report.DoIt()
            
        return $True
    }
        
    
    [Boolean]DoJtSnapshot() {
        [JtRepo]$Report = New-JtRepo_Client_JtSnapshot -JtConfig $This.JtConfig
        $Report.DoIt()
        
        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "JtSnapshot"
        $Report.DoIt()
        
        return $True
    }
    
    [Boolean]DoUpdate() {
        [JtRepo]$Report = New-JtRepo_Client_Update -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "update"
        $Report.DoIt()
        
        return $True
    }

    [Boolean]DoWol() {
        [JtRepo]$Report = New-JtRepo_Client_Wol -JtConfig $This.JtConfig
        $Report.DoIt()

        [JtRepo]$Report = New-JtRepo_Client_Timestamp -JtConfig $This.JtConfig -Label "wol"
        $Report.DoIt()

        return $True
    }
}


Function New-JtClient {
    Param (
        [Parameter(Mandatory=$true)]
        [JtConfig]$JtConfig
    )

    [JtClient]::new($JtConfig)
}

Function New-JtClient_Clean {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoClean()  
}

Function New-JtClient_Client {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoClient()  
}

Function New-JtClient_Config {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoConfig()  
}

Function New-JtClient_Csvs {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoCsvs()  
}

Function New-JtClient_Data {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoData()  
}


Function New-JtClient_Download {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoDownload()  
}


Function New-JtClient_Errors {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoErrors()  
}

Function New-JtClient_Export {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoExport()  
}

Function New-JtClient_Files {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoFiles()  
}

Function New-JtClient_Folders {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoFolders()  
}

Function New-JtClient_Install {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoInstall()  
}


Function New-JtClient_Lengths {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoLengths()  
}

Function New-JtClient_Lines {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoLines()  
}

Function New-JtClient_JtMarkdown {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoJtMarkdown()  
}

Function New-JtClient_Miete {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoMiete()  
}

Function New-JtClient_Mirror {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoMirror()  
}

Function New-JtClient_Objects {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoObjects()  
}

Function New-JtClient_Poster {
    [JtConfig]$JtConfig = New-JtConfig

    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig
    $JtClient.DoPoster()  
}
Function New-JtClient_Recover {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoRecover()  
}
Function New-JtClient_Rename {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig
    
    $JtClient.DoRename()  
}


Function New-JtClient_Report {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig
    
    $JtClient.DoReport()  
}

Function New-JtClient_JtSnapshot {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig
    
    $JtClient.DoJtSnapshot()  
}


Function New-JtClient_Software {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoSoftware()  
}


Function New-JtClient_Update {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig
    
    $JtClient.DoUpdate()  
}

Function New-JtClient_Wol {
    [JtConfig]$JtConfig = New-JtConfig
    [JtClient]$JtClient = New-JtClient -JtConfig $JtConfig

    $JtClient.DoWol()  
}



class JtMaster : JtClass {

    [JtConfig]$JtConfig
    
    JtMaster([JtConfig]$JtConfig) {
        $This.ClassName = "JtMaster"
        $This.JtConfig = $JtConfig
        
    }
    
    [String]GetToolFamily() {
        return "master"
    }

    
    [Boolean]DoCombine() {
        [JtRepo_Master_Combine]$Gen = [JtRepo_Master_Combine]::new($This.JtConfig)
        return $Gen.DoIt()
    }

    [Boolean]DoReports() {
        [JtRepo_Master_Reports]$Gen = [JtRepo_Master_Reports]::new($This.JtConfig)
        return $Gen.DoIt()
    }   

}




Function New-JtMaster {

    Param (
        [Parameter(Mandatory=$true)]
        [JtConfig]$JtConfig
    )

    [JtMaster]::new($JtConfig)
}

Function New-JtMaster_Master {
    [JtConfig]$JtConfig = New-JtConfig
    [JtMaster]$JtMaster = New-JtMaster -JtConfig $JtConfig
    
    $JtMaster.DoReports()
    $JtMaster.DoCombine()
}


Function New-JtMaster_Combine {
    [JtConfig]$JtConfig = New-JtConfig
    [JtMaster]$JtMaster = New-JtMaster -JtConfig $JtConfig
    
    $JtMaster.DoCombine()
}

Function New-JtMaster_Reports {
    [JtConfig]$JtConfig = New-JtConfig
    [JtMaster]$JtMaster = New-JtMaster -JtConfig $JtConfig
    
    $JtMaster.DoReports()
}






