using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Obj_Win32OperatingSystem : JtRep {

    JtRep_Obj_Win32OperatingSystem() : Base("obj.win32_operatingsystem") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsCaption) | Out-Null 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsManu) | Out-Null 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsSerial) | Out-Null 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsVersion) | Out-Null 
        return $JtTblRow
    }

}

function New-JtRep_Obj_Win32OperatingSystem {

    [JtRep_Obj_Win32OperatingSystem]::new() 

}

