using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Server : JtRep {

    JtRep_Z_Server() : Base("z.server") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seadrive())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seafile())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_ServerViewAgents())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Bacula())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Java())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AntiVirus())

        return $JtTblRow
    }

}

function New-JtRep_Z_Server {

    [JtRep_Z_Server]::new() 

}



