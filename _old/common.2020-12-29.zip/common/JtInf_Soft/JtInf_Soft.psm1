using module JtClass
using module JtInf
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtTbl
using module JtUtil

class JtInf_Soft : JtInf {

    [String]$ClassName = "JtInf_Soft"


    [JtField]$Herst = [JtField]::new("Herst")
    [JtField]$Modell = [JtField]::new("Modell")
    [JtField]$OfficeLabel = [JtField]::new("OfficeLabel")

    [JtFieldSoftware]$Acrobat_DC
    [JtFieldSoftware]$AcrobatReader
    [JtFieldSoftware]$AdobeCreativeCloud
    [JtFieldSoftware]$AfterEffects_CC
    [JtFieldSoftware]$AffinityDesigner
    [JtFieldSoftware]$AffinityPhoto
    [JtFieldSoftware]$AffinityPublisher
    [JtFieldSoftware]$Air
    [JtFieldSoftware]$Allplan_2012
    [JtFieldSoftware]$Allplan_2019
    [JtFieldSoftware]$AntiVirus
    [JtFieldSoftware]$ArchiCAD
    [JtFieldSoftware]$Arduino
    [JtFieldSoftware]$ASBwin
    [JtFieldSoftware]$AutoCAD_2020
    [JtFieldSoftware]$AutoCAD_2021
    [JtFieldSoftware]$Bacula
    [JtFieldSoftware]$BkiKosten
    [JtFieldSoftware]$BkiPos
    [JtFieldSoftware]$Chrome
    [JtFieldSoftware]$Chromium
    [JtFieldSoftware]$Cinema4D
    [JtFieldSoftware]$CiscoAnyConnect
    [JtFieldSoftware]$CorelDRAW
    [JtFieldSoftware]$CreativeSuite_CS6
    [JtFieldSoftware]$DellCommand
    [JtFieldSoftware]$DellSuppAs
    [JtFieldSoftware]$DokanLibrary
    [JtFieldSoftware]$DriveFs
    [JtFieldSoftware]$Firefox32
    [JtFieldSoftware]$Firefox64
    [JtFieldSoftware]$Flash
    [JtFieldSoftware]$Foxit
    [JtFieldSoftware]$Gimp
    [JtFieldSoftware]$GoogleEarth
    [JtFieldSoftware]$Grafiktreiber
    [JtFieldSoftware]$IbpHighend
    [JtFieldSoftware]$Illustrator_CC
    [JtFieldSoftware]$Indesign_CC
    [JtFieldSoftware]$Inkscape
    [JtFieldSoftware]$IntelME
    [JtFieldSoftware]$IntelNET
    [JtFieldSoftware]$Java
    [JtFieldSoftware]$Krita
    [JtFieldSoftware]$Laubwerk
    [JtFieldSoftware]$LenovoSysUp
    [JtFieldSoftware]$LibreOffice
    [JtFieldSoftware]$Lightroom_CC
    [JtFieldSoftware]$LUH_Rotis
    [JtFieldSoftware]$Max_2019
    [JtFieldSoftware]$Max_2020
    [JtFieldSoftware]$Max_2021
    [JtFieldSoftware]$Maya_2019
    [JtFieldSoftware]$Maya_2020
    [JtFieldSoftware]$Nanocad
    [JtFieldSoftware]$Notepad
    [JtFieldSoftware]$OBS
    [JtFieldSoftware]$Office
    [JtFieldSoftware]$Office365
    [JtFieldSoftware]$OfficeStandard
    [JtFieldSoftware]$OPSI
    [JtFieldSoftware]$Orca
    [JtFieldSoftware]$PDF24
    [JtFieldSoftware]$Photoshop_CC
    [JtFieldSoftware]$Premiere_CC
    [JtFieldSoftware]$Project
    [JtFieldSoftware]$RawTherapee
    [JtFieldSoftware]$Revit_2020
    [JtFieldSoftware]$Revit_2021
    [JtFieldSoftware]$Rhino_6
    [JtFieldSoftware]$Seadrive
    [JtFieldSoftware]$Seafile
    [JtFieldSoftware]$ServerViewAgents
    [JtFieldSoftware]$Silverlight
    [JtFieldSoftware]$Sketchup
    [JtFieldSoftware]$Sumatra
    [JtFieldSoftware]$Thunderbird32
    [JtFieldSoftware]$Thunderbird64
    [JtFieldSoftware]$Unity
    [JtFieldSoftware]$UnityHub
    [JtFieldSoftware]$Vectorworks
    [JtFieldSoftware]$VLC
    [JtFieldSoftware]$vRay3ds
    [JtFieldSoftware]$vRayRevit
    [JtFieldSoftware]$vRayRhino
    [JtFieldSoftware]$vRaySketchup
    [JtFieldSoftware]$WibuKey
    [JtFieldSoftware]$Zip

    JtInf_Soft() {
        $This.Acrobat_DC = [JtFieldSoftware]::new("Acrobat_DC", [JtSoftwareSource]::Uninstall32, "Adobe Acrobat DC*")
        $This.AcrobatReader = [JtFieldSoftware]::new("AcrobatReader", [JtSoftwareSource]::Uninstall32, "Adobe Acrobat Reader DC*")
        $This.AdobeCreativeCloud = [JtFieldSoftware]::new("AdobeCreativeCloud", [JtSoftwareSource]::Uninstall32, "Adobe Creative Cloud*")
        $This.AfterEffects_CC = [JtFieldSoftware]::new("AfterEffects_CC", [JtSoftwareSource]::Uninstall32, "Adobe After Effects 2020*")
        $This.AffinityDesigner = [JtFieldSoftware]::new("AffinityDesigner", [JtSoftwareSource]::Uninstall64, "Affinity Designer*")
        $This.AffinityPhoto = [JtFieldSoftware]::new("AffinityPhoto", [JtSoftwareSource]::Uninstall64, "Affinity Photo*")
        $This.AffinityPublisher = [JtFieldSoftware]::new("AffinityPublisher", [JtSoftwareSource]::Uninstall64, "Affinity Publisher*")
        $This.Air = [JtFieldSoftware]::new("Air", [JtSoftwareSource]::Uninstall32, "Adobe AIR*")
        $This.Allplan_2012 = [JtFieldSoftware]::new("Allplan_2012", [JtSoftwareSource]::Uninstall32, "Allplan 2012*")
        $This.Allplan_2019 = [JtFieldSoftware]::new("Allplan_2019", [JtSoftwareSource]::Uninstall32, "Allplan 2019*")
        $This.AntiVirus = [JtFieldSoftware]::new("AntiVirus", [JtSoftwareSource]::Uninstall32, "Sophos Anti-Virus*")
        $This.ArchiCAD = [JtFieldSoftware]::new("ArchiCAD", [JtSoftwareSource]::Uninstall64, "ARCHICAD *")
        $This.Arduino = [JtFieldSoftware]::new("Arduino", [JtSoftwareSource]::Uninstall32, "Arduino*")
        $This.ASBwin = [JtFieldSoftware]::new("ASBwin", [JtSoftwareSource]::Uninstall32, "ASBwin*")
        $This.AutoCAD_2020 = [JtFieldSoftware]::new("AutoCAD_2020", [JtSoftwareSource]::Uninstall64, "Autodesk AutoCAD Jtecture 2020*")
        $This.AutoCAD_2021 = [JtFieldSoftware]::new("AutoCAD_2021", [JtSoftwareSource]::Uninstall64, "Autodesk AutoCAD Jtecture 2021*")
        $This.Bacula = [JtFieldSoftware]::new("Bacula", [JtSoftwareSource]::Uninstall32, "Bacula Systems*")
        $This.BkiKosten = [JtFieldSoftware]::new("BkiKosten", [JtSoftwareSource]::Uninstall32, "BKI Kostenplaner*")
        $This.BkiPos = [JtFieldSoftware]::new("BkiPos", [JtSoftwareSource]::Uninstall32, "BKI Positionen*")
        $This.Chrome = [JtFieldSoftware]::new("Chrome", [JtSoftwareSource]::Uninstall64, "Google Chrome*")
        $This.Chromium = [JtFieldSoftware]::new("Chromium", [JtSoftwareSource]::Uninstall32, "Chromium*")
        $This.Cinema4D = [JtFieldSoftware]::new("Cinema4D", [JtSoftwareSource]::Uninstall64, "Cinema 4D *")
        $This.CiscoAnyConnect = [JtFieldSoftware]::new("CiscoAnyConnect", [JtSoftwareSource]::Uninstall64, "Cisco AnyConnect*")
        $This.CorelDRAW = [JtFieldSoftware]::new("CorelDRAW", [JtSoftwareSource]::Uninstall64, "CorelDRAW Graphics Suite*")
        $This.CreativeSuite_CS6 = [JtFieldSoftware]::new("CreativeSuite_CS6", [JtSoftwareSource]::Uninstall32, "Adobe Creative Suite 6 Design Standard*")
        $This.DellCommand = [JtFieldSoftware]::new("DellCommand", [JtSoftwareSource]::Uninstall32, "Dell Command*")
        $This.DellSuppAs = [JtFieldSoftware]::new("DellSuppAs", [JtSoftwareSource]::Uninstall64, "Dell SupportAssist*")
        $This.DokanLibrary = [JtFieldSoftware]::new("DokanLibrary", [JtSoftwareSource]::Uninstall64, "Dokan Library*")
        $This.DriveFs = [JtFieldSoftware]::new("DriveFs", [JtSoftwareSource]::Uninstall64, "Google Drive File Stream*")
        $This.Firefox32 = [JtFieldSoftware]::new("Firefox32", [JtSoftwareSource]::Uninstall32, "Mozilla Firefox*")
        $This.Firefox64 = [JtFieldSoftware]::new("Firefox64", [JtSoftwareSource]::Uninstall64, "Mozilla Firefox*")
        $This.Flash = [JtFieldSoftware]::new("Flash", [JtSoftwareSource]::Uninstall32, "Adobe Flash Player*")
        $This.Foxit = [JtFieldSoftware]::new("Foxit", [JtSoftwareSource]::Uninstall32, "Foxit Reader*")
        $This.Gimp = [JtFieldSoftware]::new("Gimp", [JtSoftwareSource]::Uninstall64, "GIMP*")
        $This.GoogleEarth = [JtFieldSoftware]::new("GoogleEarth", [JtSoftwareSource]::Uninstall32, "Google Earth *")
        $This.Grafiktreiber = [JtFieldSoftware]::new("Grafiktreiber", [JtSoftwareSource]::Uninstall64, "NVIDIA Grafiktreiber*")
        $This.IbpHighend = [JtFieldSoftware]::new("IbpHighend", [JtSoftwareSource]::Uninstall32, "IBP18599 HighEnd*")
        $This.Illustrator_CC = [JtFieldSoftware]::new("Illustrator_CC", [JtSoftwareSource]::Uninstall32, "Adobe Illustrator 2020*")
        $This.Indesign_CC = [JtFieldSoftware]::new("Indesign_CC", [JtSoftwareSource]::Uninstall32, "Adobe InDesign 2020*")
        $This.Inkscape = [JtFieldSoftware]::new("Inkscape", [JtSoftwareSource]::Uninstall64, "Inkscape*")
        $This.IntelME = [JtFieldSoftware]::new("IntelME", [JtSoftwareSource]::Uninstall64, "Intel (R) Management Engine Components*")
        $This.IntelNET = [JtFieldSoftware]::new("IntelNET", [JtSoftwareSource]::Uninstall64, "Intel (R) Network *")
        $This.Java = [JtFieldSoftware]::new("Java", [JtSoftwareSource]::Uninstall64, "Java 8*")
        $This.Krita = [JtFieldSoftware]::new("Krita", [JtSoftwareSource]::Uninstall64, "Krita (x64)*")
        $This.Laubwerk = [JtFieldSoftware]::new("Laubwerk", [JtSoftwareSource]::Uninstall64, "Laubwerk Plants*")
        $This.LenovoSysUp = [JtFieldSoftware]::new("LenovoSysUp", [JtSoftwareSource]::Uninstall32, "Lenovo System Update*")
        $This.LibreOffice = [JtFieldSoftware]::new("LibreOffice", [JtSoftwareSource]::Uninstall64, "LibreOffice*")
        $This.Lightroom_CC = [JtFieldSoftware]::new("Lightroom_CC", [JtSoftwareSource]::Uninstall32, "Adobe Lightroom Classic 2020*")
        $This.LUH_Rotis = [JtFieldSoftware]::new("LUH_Rotis", [JtSoftwareSource]::Uninstall32, "LUH-Rotis-Font*")
        $This.Max_2019 = [JtFieldSoftware]::new("Max_2019", [JtSoftwareSource]::Uninstall64, "Autodesk 3ds Max 2019*")
        $This.Max_2020 = [JtFieldSoftware]::new("Max_2020", [JtSoftwareSource]::Uninstall64, "Autodesk 3ds Max 2020*")
        $This.Max_2021 = [JtFieldSoftware]::new("Max_2021", [JtSoftwareSource]::Uninstall64, "Autodesk 3ds Max 2021*")
        $This.Maya_2019 = [JtFieldSoftware]::new("Maya_2019", [JtSoftwareSource]::Uninstall64, "Autodesk Maya 2019*")
        $This.Maya_2020 = [JtFieldSoftware]::new("Maya_2020", [JtSoftwareSource]::Uninstall64, "Autodesk Maya 2020*")
        $This.Nanocad = [JtFieldSoftware]::new("Nanocad", [JtSoftwareSource]::Uninstall32, "Nanocad*")
        $This.Notepad = [JtFieldSoftware]::new("Notepad", [JtSoftwareSource]::Uninstall64, "Notepad++*")
        $This.OBS = [JtFieldSoftware]::new("OBS", [JtSoftwareSource]::Uninstall32, "OBS Studio*")
        $This.Office = [JtFieldSoftware]::new("Office", [JtSoftwareSource]::Uninstall64, "Microsoft Office Standard*")
        $This.Office365 = [JtFieldSoftware]::new("Office365", [JtSoftwareSource]::Uninstall64, "Microsoft 365*")
        $This.OfficeStandard = [JtFieldSoftware]::new("OfficeStandard", [JtSoftwareSource]::Uninstall64, "Microsoft Office Standard*")
        $This.OPSI = [JtFieldSoftware]::new("OPSI", [JtSoftwareSource]::Uninstall32, "opsi-client-agent*")
        $This.Orca = [JtFieldSoftware]::new("Orca", [JtSoftwareSource]::Uninstall32, "ORCA AVA*")
        $This.PDF24 = [JtFieldSoftware]::new("PDF24", [JtSoftwareSource]::Uninstall32, "PDF24 Creator*")
        $This.Photoshop_CC = [JtFieldSoftware]::new("Photoshop_CC", [JtSoftwareSource]::Uninstall32, "Adobe Photoshop 2020*")
        $This.Premiere_CC = [JtFieldSoftware]::new("Premiere_CC", [JtSoftwareSource]::Uninstall32, "Adobe Premiere Pro 2020*")
        $This.Project = [JtFieldSoftware]::new("Project", [JtSoftwareSource]::Uninstall64, "Microsoft Project MUI*")
        $This.RawTherapee = [JtFieldSoftware]::new("RawTherapee", [JtSoftwareSource]::Uninstall64, "RawTherapee Version*")
        $This.Revit_2020 = [JtFieldSoftware]::new("Revit_2020", [JtSoftwareSource]::Uninstall64, "Autodesk Revit 2020*")
        $This.Revit_2021 = [JtFieldSoftware]::new("Revit_2021", [JtSoftwareSource]::Uninstall64, "Autodesk Revit 2021*")
        $This.Rhino_6 = [JtFieldSoftware]::new("Rhino_6", [JtSoftwareSource]::Uninstall64, "Rhinoceros 6*")
        $This.Seadrive = [JtFieldSoftware]::new("Seadrive", [JtSoftwareSource]::Uninstall64, "SeaDrive*")
        $This.Seafile = [JtFieldSoftware]::new("Seafile", [JtSoftwareSource]::Uninstall32, "Seafile*")
        $This.ServerViewAgents = [JtFieldSoftware]::new("ServerViewAgents", [JtSoftwareSource]::Uninstall64, "FUJITSU Software ServerView Agents x64*")
        $This.Silverlight = [JtFieldSoftware]::new("Silverlight", [JtSoftwareSource]::Uninstall64, "Microsoft Silverlight*")
        $This.Sketchup = [JtFieldSoftware]::new("Sketchup", [JtSoftwareSource]::Uninstall64, "SketchUp*")
        $This.Sumatra = [JtFieldSoftware]::new("Sumatra", [JtSoftwareSource]::Uninstall64, "SumatraPDF*")
        $This.Thunderbird32 = [JtFieldSoftware]::new("Thunderbird32", [JtSoftwareSource]::Uninstall32, "Mozilla Thunderbird*")
        $This.Thunderbird64 = [JtFieldSoftware]::new("Thunderbird64", [JtSoftwareSource]::Uninstall64, "Mozilla Thunderbird*")
        $This.Unity = [JtFieldSoftware]::new("Unity", [JtSoftwareSource]::Uninstall32, "Unity")
        $This.UnityHub = [JtFieldSoftware]::new("UnityHub", [JtSoftwareSource]::Uninstall64, "Unity Hub*")
        $This.Vectorworks = [JtFieldSoftware]::new("Vectorworks", [JtSoftwareSource]::Uninstall64, "Vectorworks*")
        $This.VLC = [JtFieldSoftware]::new("VLC", [JtSoftwareSource]::Uninstall64, "VLC media player*")
        $This.vRay3ds = [JtFieldSoftware]::new("vRay3ds", [JtSoftwareSource]::Uninstall64, "V-Ray for 3dsmax 2020*")
        $This.vRayRevit = [JtFieldSoftware]::new("vRayRevit", [JtSoftwareSource]::Uninstall64, "V-Ray for Revit*")
        $This.vRayRhino = [JtFieldSoftware]::new("vRayRhino", [JtSoftwareSource]::Uninstall64, "V-Ray for Rhinoceros*")
        $This.vRaySketchup = [JtFieldSoftware]::new("vRaySketchup", [JtSoftwareSource]::Uninstall64, "V-Ray for SketchUp*")
        $This.WibuKey = [JtFieldSoftware]::new("WibuKey", [JtSoftwareSource]::Uninstall64, "WibuKey Setup*")
        $This.Zip = [JtFieldSoftware]::new("Zip", [JtSoftwareSource]::Uninstall64, "7-Zip*")
    }
        
        
    [Object[]]GetFields() {
        $JtInf = [JtObj]::new()

        [Object[]]$Result = @()

        [System.Array]$Properties = $This.GetProperties()

        foreach ($Property in $Properties) {

            [String]$PropertyName = $Property.Name
            Write-Host "PropertyName:" $PropertyName
            
            $Field = $JtInf.($PropertyName)
            [String]$FieldType = $Field.GetType()
            # Write-Host "Field-Type:" $FieldType
            if ($FieldType.StartsWith("JtFieldSoftware")) {
                $Result += $Field
            }

        }

        $Result

        return $Result
    }



    [System.Array]GetProperties() {
        [JtInf_Soft]$JtInf_Soft = [JtObj]::new()
        $Properties = $JtInf_Soft | Get-Member -MemberType Property
        return $Properties
    }

    # [JtTblTable]GetPropertyTable() {
    #     [JtTblTable]$JtTblTable = New-JtTblTable -Label $This.ClassName

    #     foreach($Property in $This.GetProperties()) {
    #         [JtTblRow]$JtTblRow = New-JtTblRow
    #         $JtTblRow.AddValue($Property.Name, $Property.Name)
    #         $JtTblTable.AddRow($JtTblRow)
    #     }

    #     return $JtTblTable
    # }

}

Function New-JtInf_Soft {

    [JtObj]::new()
}


class JtSearchSet_Software : JtClass {

    hidden [String]$Description

    hidden [System.Collections.Specialized.OrderedDictionary]$TheSet

    JtSearchSet_Software([JtSoftwareSource]$JtSoftwareSource) {
        $This.ClassName = "JtSearchSet_Software"
        [String]$Des = ""
        switch ($JtSoftwareSource) {
            ([JtSoftwareSource]::InstalledSoftware) { 
                $Des = "installedSoftware"
            } 
            ([JtSoftwareSource]::Uninstall32) { 
                $Des = "uninstall32"
            } 
            ([JtSoftwareSource]::Uninstall64) { 
                $Des = "uninstall64"
            } 
            default {
                Write-Host "This should not happen! Error with JtSoftwareSource"
                Throw "JtSearchSet_Software ERROR!!!"
                Exit
            }
        }

        $This.Description = $Des
        $This.TheSet = $This.DoInit()
    }


    [System.Collections.Specialized.OrderedDictionary]GetSet() {
        return $This.TheSet
    } 

    [Object[]]GetFields() {
        return $Null
    }

    [System.Collections.Specialized.OrderedDictionary]DoInit() {

        $JtSearchSet = [Ordered]@{ }

        [Object[]]$Fields = $This.GetFields()

        foreach ($JtObject in $Fields) {
            [JtFieldSoftware]$Field = $JtObject
            $header = $Field.GetLabel()
            $search = $Field.GetSearch()
            try {
                $JtSearchSet.add($header, $search) | Out-Null 
            }
            catch {
                Write-Host "Error in DoInit() ... line 4351"
            }
 
        } 
        if ($JtSearchSet.Keys.Count -lt 1) {
            Write-Host "JtSearchSet empty" $This.Description
        } 
        else {
            #    Write-Host "JtSearchSet:" $JtSearchSet.Keys.Count " in " $This.Description
        } 
        return $JtSearchSet
    } 
 
 
}





Function New-Init_JtInf_Soft {
    
    Param (
        [Parameter(Mandatory = $true)]
        [JtIoFolder]$JtIoFolder)


    [String]$Name = "soft"


    [JtInf_Soft_InstalledSoftware]$JtInf_Soft_InstalledSoftware = New-Init_JtInf_Soft_InstalledSoftware -JtIoFolder $JtIoFolder
    [JtInf_Soft_Uninstall32]$JtInf_Soft_Uninstall32 = New-Init_JtInf_Soft_Uninstall32 -JtIoFolder $JtIoFolder
    [JtInf_Soft_Uninstall64]$JtInf_Soft_Uninstall64 = New-Init_JtInf_Soft_Uninstall64 -JtIoFolder $JtIoFolder
    
    [JtInf_Soft]$JtInf = [JtObj]::new()
    $This.SetSoftwareValue($JtInf.Acrobat_DC)
    $This.SetSoftwareValue($JtInf.AcrobatReader)
    $This.SetSoftwareValue($JtInf.AdobeCreativeCloud)
    $This.SetSoftwareValue($JtInf.AfterEffects_CC)
    $This.SetSoftwareValue($JtInf.AffinityDesigner)
    $This.SetSoftwareValue($JtInf.AffinityPhoto)
    $This.SetSoftwareValue($JtInf.AffinityPublisher)
    $This.SetSoftwareValue($JtInf.Air)
    $This.SetSoftwareValue($JtInf.Allplan_2012)
    $This.SetSoftwareValue($JtInf.Allplan_2019)
    $This.SetSoftwareValue($JtInf.AntiVirus)
    $This.SetSoftwareValue($JtInf.ArchiCAD)
    $This.SetSoftwareValue($JtInf.Arduino)
    $This.SetSoftwareValue($JtInf.ASBwin)
    $This.SetSoftwareValue($JtInf.AutoCAD_2020)
    $This.SetSoftwareValue($JtInf.AutoCAD_2021)
    $This.SetSoftwareValue($JtInf.Bacula)
    $This.SetSoftwareValue($JtInf.BkiKosten)
    $This.SetSoftwareValue($JtInf.BkiPos)
    $This.SetSoftwareValue($JtInf.Chrome)
    $This.SetSoftwareValue($JtInf.Chromium)
    $This.SetSoftwareValue($JtInf.Cinema4D)
    $This.SetSoftwareValue($JtInf.CiscoAnyConnect)
    $This.SetSoftwareValue($JtInf.CorelDRAW)
    $This.SetSoftwareValue($JtInf.CreativeSuite_CS6)
    $This.SetSoftwareValue($JtInf.DellCommand)
    $This.SetSoftwareValue($JtInf.DellSuppAs)
    $This.SetSoftwareValue($JtInf.DokanLibrary)
    $This.SetSoftwareValue($JtInf.DriveFs)
    $This.SetSoftwareValue($JtInf.Firefox32)
    $This.SetSoftwareValue($JtInf.Firefox64)
    $This.SetSoftwareValue($JtInf.Flash)
    $This.SetSoftwareValue($JtInf.Foxit)
    $This.SetSoftwareValue($JtInf.Gimp)
    $This.SetSoftwareValue($JtInf.GoogleEarth)
    $This.SetSoftwareValue($JtInf.Grafiktreiber)
    $This.SetSoftwareValue($JtInf.IbpHighend)
    $This.SetSoftwareValue($JtInf.Illustrator_CC)
    $This.SetSoftwareValue($JtInf.Indesign_CC)
    $This.SetSoftwareValue($JtInf.IntelME)
    $This.SetSoftwareValue($JtInf.IntelNET)
    $This.SetSoftwareValue($JtInf.Java)
    $This.SetSoftwareValue($JtInf.Krita)
    $This.SetSoftwareValue($JtInf.Laubwerk)
    $This.SetSoftwareValue($JtInf.LenovoSysUp)
    $This.SetSoftwareValue($JtInf.LibreOffice)
    $This.SetSoftwareValue($JtInf.Lightroom_CC)
    $This.SetSoftwareValue($JtInf.LUH_Rotis)
    $This.SetSoftwareValue($JtInf.Max_2019)
    $This.SetSoftwareValue($JtInf.Max_2020) 
    $This.SetSoftwareValue($JtInf.Max_2021) 
    $This.SetSoftwareValue($JtInf.Maya_2019) 
    $This.SetSoftwareValue($JtInf.Maya_2020) 
    $This.SetSoftwareValue($JtInf.Nanocad) 
    $This.SetSoftwareValue($JtInf.Notepad)
    $This.SetSoftwareValue($JtInf.OBS)
    $This.SetSoftwareValue($JtInf.Office)
    $This.SetSoftwareValue($JtInf.Office365)
    $This.SetSoftwareValue($JtInf.OfficeStandard)
    $This.SetSoftwareValue($JtInf.OPSI)
    $This.SetSoftwareValue($JtInf.Orca)
    $This.SetSoftwareValue($JtInf.PDF24)
    $This.SetSoftwareValue($JtInf.Photoshop_CC)
    $This.SetSoftwareValue($JtInf.Premiere_CC)
    $This.SetSoftwareValue($JtInf.Project)
    $This.SetSoftwareValue($JtInf.RawTherapee)
    $This.SetSoftwareValue($JtInf.Revit_2020)
    $This.SetSoftwareValue($JtInf.Revit_2021)
    $This.SetSoftwareValue($JtInf.Rhino_6)
    $This.SetSoftwareValue($JtInf.Seadrive)
    $This.SetSoftwareValue($JtInf.Seafile)
    $This.SetSoftwareValue($JtInf.ServerViewAgents)
    $This.SetSoftwareValue($JtInf.Silverlight)
    $This.SetSoftwareValue($JtInf.Sketchup)
    $This.SetSoftwareValue($JtInf.Sumatra)
    $This.SetSoftwareValue($JtInf.Thunderbird32)
    $This.SetSoftwareValue($JtInf.Thunderbird64)
    $This.SetSoftwareValue($JtInf.Unity)
    $This.SetSoftwareValue($JtInf.UnityHub)
    $This.SetSoftwareValue($JtInf.Vectorworks)
    $This.SetSoftwareValue($JtInf.VLC)
    $This.SetSoftwareValue($JtInf.vRay3ds)
    $This.SetSoftwareValue($JtInf.vRayRevit)
    $This.SetSoftwareValue($JtInf.vRayRhino)
    $This.SetSoftwareValue($JtInf.vRaySketchup)
    $This.SetSoftwareValue($JtInf.WibuKey)
    $This.SetSoftwareValue($JtInf.Zip)
        
    <#         $Value = [JtObj]::GetLabelForOffice($Value)
        $JtInf.Get_OfficeLabel().SetValue($Value) #>

}



class JtObj : JtClass {



    hidden [String]$Name


    
    static hidden [Object[]]$Cache_Fields_InstalledSoftware
    static hidden [Object[]]$Cache_Fields_Uninstall32
    static hidden [Object[]]$Cache_Fields_Uninstall64

    

    static [System.Collections.ArrayList]GetFilteredArrayList([System.Collections.ArrayList]$MyArray, [String]$FilterProperty) {
        [System.Collections.ArrayList]$Re = [System.Collections.ArrayList]::new()
 
        if ($Null -eq $MyArray) {
            Write-Host("GetFilteredArrayList;  ArrayList is null ------------------------------------")
            return $Re
        }
        # [Int32]$h = $MyArray.Count
        [Int32]$i = 0
        [Int32]$j = 0
 
        foreach ($MySys in $MyArray) {
            $El = $MySys | Get-Member | Where-Object { $_.name -like $FilterProperty }
            if ($Null -ne $El) {
                $Re.add($MySys)
                $j = $j + 1
            }
            $i = $i + 1
        }
 
        return $re
    }


        
    static [System.Object]GetXmlReportSoftware([JtIoFolder]$JtIoFolder, [String]$Name) {
        [System.Object]$JtObject = $Null

        Write-JtLog ( -Join ("GetXmlReportSoftware - ", $JtIoFolder.GetPath()))
        
        [String]$FilenameXml = -Join ($Name, [JtIoFile]::FileExtensionXml)
        [JtIoFolder]$FolderXml = $JtIoFolder.GetChild("software")
        [String]$FilePathXml = $FolderXml.GetFilePath($FilenameXml)
        Write-JtLog -Text ( -join ("FilePathXml:", $FilePathXml))
        if (Test-Path ($FilePathXml)) {
            try {
                $JtObject = Import-Clixml $FilePathXml
            }
            catch {
                Write-JtError -Text ( -join ("GetXmlReportSoftware; problem while reading Xml:", $FilePathXml))
            }
        }
        return $JtObject
    }

    static [JtInf]GetInit([JtInf]$JtInf, [String]$Name, [JtIoFolder]$JtIoFolder, [JtSearchSet_Software]$JtSearchSet, [String]$FilterProperty, [String]$VersionProperty) {
        [JtSearchSet_Software]$MyJtSearchSet = $JtSearchSet
        [System.Object]$JtObj = [JtObj]::GetXmlReportSoftware($JtIoFolder, $Name)

        if ($Null -eq $JtObj) {
            Write-JtError -Text ( -Join ("Array is null for name:", $Name))
        }


        [System.Collections.ArrayList]$MyArray = [JtObj]::GetFilteredArrayList($JtObj, $FilterProperty)

        foreach ($Key in $MyJtSearchSet.GetSet().keys) {
            [String]$Keyword = $MyJtSearchSet.GetSet()[$Key]
            [String]$Version = ""
            try {
                $MyJtSearchSet.GetSet().keys | Out-Null 
            } 
            catch {
                Write-JtError -Text ( -join ("Error:JtSearchSet.keys", $Name))
            }
            try {
                $MyResult = $MyArray | Where-Object { $_.($FilterProperty) -like $Keyword }
                if ($Null -ne $MyResult) {
                    $Version = "v" + $MyResult[0].($VersionProperty)
                }
            }
            catch {
                $MyArray
                Write-JtError -Text ( -join ("In: ", $Name, ". ", $FilterProperty, " does not exist. key:", $key, "---Keyword:", $Keyword))
            }
            Write-JtLog ( -join ("Key:", $Key, "; Version:", $Version))
            try {
                
                $JtInf.($Key).SetValue($Version) | Out-Null 
            }
            catch {
                Write-JtError ( -join ("Problem!!! Key:", $Key, "; Version:", $Version))

            }
        }
        return $JtInf
    }




    static [String]GetLabelForOffice([String]$Version) {
        [String]$Result = ""
        if ($Null -eq $Version) {
 
        }
        else {
            [String[]]$Parts = $Version.Split(".")
            if ($Parts.Count -gt 2) {
                [String]$Part = $Parts[0]
                # [String]$Part2 = $Parts[1]
                [String]$Part3 = $Parts[2]
                switch ($Part) {
                    "v12" { 
                        $Result = "Office2007"
                    } 
                    "v13" { 
                        $Result = "Office2010"
                    } 
                    "v15" { 
                        $Result = "Office2013"
                    } 
                    "v16" { 
                        if ($Part3 -eq "4266") {
                            $Result = "Office2016"
                        }
                        elseif ($Part3 -eq "10827") {
                            $Result = "Office2019"
                        }
                        else {
                            $Result = "OfficeXXX"
                        }
                    } 
                    default {
                        $Result = $Version
                    }
                }
            }
        }
        return $Result
    }


    static [Boolean]SetObjValue([JtInf]$JtInf, [System.Object]$JtObj, [JtField]$JtField, [String]$Value) {
        if ($Null -ne $JtObj) {
            try {
                $JtField.SetValue($Value)
            } 
            catch {
                Write-JtError -Text ( -join ("Field:", "xxxx", ", Error in ", $JtField.GetName()))
            } 
        }
        else {
            Write-JtError -Text ( -join ("Obj is NULL, field:", $JtField.GetName()))
        }
        return $True
    }


    JtObj([String]$Name) {
        $This.ClassName = "obj"
        $This.Name = $Name
    }


    [String]GetName() {
        return $This.Name
    }

}


class ObjXml_Soft : JtObj {

    hidden [String]$FilterProperty
    hidden [String]$VersionProperty
    hidden [JtIoFolder]$JtIoFolder
    hidden [JtTblRow]$Line 
    hidden [JtSearchSet_Software]$JtSearchSet 
    hidden [JtSoftwareSource]$JtSoftwareSource
    hidden [JtInf_Soft]$Cache_JtInf_Soft = $Null

 
    ObjXml_Soft([String]$Name, [JtIoFolder]$MyJtIoFolder, [JtSoftwareSource]$MyJtSoftwareSource, [String]$MyFilterProperty, [String]$MyVersionProperty) : base($Name) {
        $This.ClassName = "ObjXml_Soft"   
        $This.JtIoFolder = $MyJtIoFolder
        $This.JtSoftwareSource = $MyJtSoftwareSource
        $This.FilterProperty = $MyFilterProperty
        $This.VersionProperty = $MyVersionProperty

        [JtInf_Soft]$JtInf = [JtObj]::new()
        $This.Cache_JtInf_Soft = $JtInf
    }
    
    [JtInf_Soft]GetInf() {
        return $This.Cache_JtInf_Soft
    }

    [JtTblRow]GetLine() {
        [JtTblRow]$JtTblRow = $This.Line
        return $JtTblRow
    }


    [Boolean]SetValue([JtFieldSoftware]$Field) {
        [String]$Value = $This.GetValue($Field) 
        return $Field.SetValue($Value)
    }

    [JtTblRow]GetJtTblRow() {
        return $This.JtTblRow
    }
}



function Set-SoftwareValue {

    Param (
        [Parameter(Mandatory = $True)]
        [JtFieldSoftware]$Field,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_InstalledSoftware]$JtInf_Soft_InstalledSoftware,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_Uninstall32]$JtInf_Soft_Uninstall32,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_Uninstall64]$JtInf_Soft_Uninstall64
    )
    if ($Null -eq $Field) {
        Write-Host "Field is null"
        Throw "SetSoftwareValue Field is null"
    }
    else {
        [String]$Value = "default"
        
        try {
            $Value = Get-SoftwareValue -Field $Field -JtInf_Soft_InstalledSoftware $JtInf_Soft_InstalledSoftware -JtInf_Soft_Uninstall32 $JtInf_Soft_Uninstall32 -JtInf_Soft_Uninstall64 $JtInf_Soft_Uninstall64
        
        }
        catch {

            Write-Host "Error! Get-SoftwareValue 1"
            Throw "Error! Get-SoftwareValue 1"
            return $false
        }

        try {
            
            $Field.SetValue($Value)

        }
        catch {

            Write-Host "Error! SetSoftwareValue 3"
            return $false
        }
    }

    return $False
}

function Get-SoftwareValue {

    Param (
        [Parameter(Mandatory = $True)]
        [JtFieldSoftware]$Field,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_InstalledSoftware]$JtInf_Soft_InstalledSoftware,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_Uninstall32]$JtInf_Soft_Uninstall32,
        [Parameter(Mandatory = $True)]
        [JtInf_Soft_Uninstall64]$JtInf_Soft_Uninstall64
    )


    [String]$Result = ""

    if ($Null -ne $Field) {
        switch ($Field.GetSource()) {
            ([JtSoftwareSource]::InstalledSoftware) { 
                $Result = $JtInf_Soft_InstalledSoftware.GetValue($Field.GetLabel())
            } 
            ([JtSoftwareSource]::Uninstall32) { 
                $Result = $JtInf_Soft_Uninstall32.GetValue($Field.GetLabel())
            } 
            ([JtSoftwareSource]::Uninstall64) { 
                $Result = $JtInf_Soft_Uninstall65.GetValue($Field.GetLabel())
            } 
            default {
                Write-Host "This should not happen! Error with JtSoftwareSource"
                Exit
            }
        }
    }
    else {
        Throw "Field is null"
    }
    $Result
    return $Result
}

class JtInf_Soft_InstalledSoftware : JtInf_Soft {

    [Object[]]GetFieldsInstalledSoftware() {
        [Object[]]$Fields = [JtObj]::Cache_Fields_InstalledSoftware

        if ($Null -eq $Fields) {
            [Object[]]$JtObjects = $This.GetFields()
            [Object[]]$Result = @()
            foreach ($JtObject in $JtObjects) {
                [JtFieldSoftware]$Field = $JtObject
                [JtSoftwareSource]$Source = $Field.GetSource()
                if ($Source -eq ([JtSoftwareSource]::InstalledSoftware)) {
                    $Result += $Field
                }
            }

            $Fields = $Result
            [JtObj]::Cache_Fields_InstalledSoftware = $Result
        }

        return $Fields
    }

}


class JtSearchSet_Software_InstalledSoftware : JtSearchSet_Software {
 
    JtSearchSet_Software_InstalledSoftware() : base ([JtSoftwareSource]::InstalledSoftware) { 
        $This.ClassName = "JtSearchSet_Software_InstalledSoftware"
    } 
 
    [Object[]]GetFields() {
        [JtInf_Soft_InstalledSoftware]$JtInf_Soft = [JtInf_Soft_InstalledSoftware]::new()
        return $JtInf_Soft.GetFieldsInstalledSoftware()
    }
} 


Function New-JtInf_Soft_InstalledSoftware {

    [JtInf_Soft_InstalledSoftware]::new()
}


Function New-Init_JtInf_Soft_InstalledSoftware {

    Param (
        [Parameter(Mandatory = $true)]
        [JtIoFolder]$JtIoFolder)

    [String]$Name = "InstalledSoftware"


    #    [JtSoftwareSource]$SoftwareSource = [JtSoftwareSource]::InstalledSoftware

    
    [String]$FilterProperty = "Name"
    [String]$VersionProperty = "Version"
    
    [JtSearchSet_Software]$JtSearchSet = [JtSearchSet_Software_InstalledSoftware]::new()
            
    $JtInf = [JtObj]::GetInit($JtInf, $Name, $JtIoFolder, $JtSearchSet, $FilterProperty, $VersionProperty)
    return $JtInf
}

# static [JtInf]GetInit(
#     [JtInf]$JtInf, 
#     [String]$Name, 
#     [JtIoFolder]$JtIoFolder, 
#     [JtSearchSet_Software]$JtSearchSet, 
#     [String]$FilterProperty, 
#     [String]$VersionProperty) 


class JtInf_Soft_Uninstall32 : JtInf_Soft {

    # static [JtSearchSet_Software]$Set = $null
    #    [JtTblRow]$LineUninstall32 = New-JtTblRow

    [Object[]]GetFieldsUninstall32() {
        [Object[]]$Fields = [JtObj]::Cache_Fields_Uninstall32
        if ($Null -eq $Fields) {
            [Object[]]$JtObjects = $This.GetFields()
            [Object[]]$Result = @()
            foreach ($JtObject in $JtObjects) {
                [JtFieldSoftware]$Field = $JtObject
                [JtSoftwareSource]$Source = $Field.GetSource()
                if ($Source -eq ([JtSoftwareSource]::Uninstall32)) {
                    $Result += $Field
                }
            }
            $Fields = $Result
            [JtObj]::Cache_Fields_Uninstall32 = $Result
        }

        return $Fields
    }

}


class JtSearchSet_Software_Uninstall32 : JtSearchSet_Software {
 
    JtSearchSet_Software_Uninstall32() : base ([JtSoftwareSource]::Uninstall32) { 
        $This.ClassName = "JtSearchSet_Software_Uninstall32"
 
    } 

    [Object[]]GetFields() {
        [JtInf_Soft_Uninstall32]$JtInf_Soft = [JtInf_Soft_Uninstall32]::new()
        return $JtInf_Soft.GetFieldsUninstall32()
    }


} 


Function New-JtInf_Soft_Uninstall32 {

    [JtInf_Soft_Uninstall32]::new()
}

Function New-Init_JtInf_Soft_Uninstall32 {
    
    Param (
        [Parameter(Mandatory = $true)]
        [JtIoFolder]$JtIoFolder)
    
    [String]$Name = "Uninstall32"
        
    # [JtSoftwareSource]$SoftwareSource = [JtSoftwareSource]::Uninstall32
        
    [String]$FilterProperty = "DisplayName"
    [String]$VersionProperty = "DisplayVersion"
        
    [JtSearchSet_Software]$JtSearchSet = [JtSearchSet_Software_Uninstall32]::new()

    [JtInf_Soft_Uninstall32]$JtInf = [JtObj]::GetInit($JtInf, $Name, $JtIoFolder, $JtSearchSet, $FilterProperty, $VersionProperty)
    return $JtInf
}


class JtInf_Soft_Uninstall64 : JtInf_Soft {

    # static [JtSearchSet_Software]$Set = $null
    #    [JtTblRow]$LineUninstall64 = New-JtTblRow

    [Object[]]GetFieldsUninstall64() {
        [Object[]]$Fields = [JtObj]::Cache_Fields_Uninstall64
        if ($Null -eq $Fields) {
            [Object[]]$JtObjects = $This.GetFields()
            [Object[]]$Result = @()
            foreach ($JtObject in $JtObjects) {
                [JtFieldSoftware]$Field = $JtObject
                [JtSoftwareSource]$Source = $Field.GetSource()
                if ($Source -eq ([JtSoftwareSource]::Uninstall64)) {
                    $Result += $Field
                }
            }
            $Fields = $Result
            [JtObj]::Cache_Fields_Uninstall64 = $Fields
        }

        return $Fields
    }
}
Function New-JtInf_Soft_Uninstall64 {

    [JtInf_Soft_Uninstall64]::new()

}

class JtSearchSet_Software_Uninstall64 : JtSearchSet_Software {
 
    JtSearchSet_Software_Uninstall64() : base ([JtSoftwareSource]::Uninstall64) { 
        $This.ClassName = "JtSearchSet_Software_Uninstall64"
    } 
 
    [Object[]]GetFields() {
        [JtInf_Soft_Uninstall64]$JtInf_Soft = [JtInf_Soft_Uninstall64]::new()
        return $JtInf_Soft.GetFieldsUninstall64()
    }
} 






Function New-Init_JtInf_Soft_Uninstall64 {

    Param (
        [Parameter(Mandatory = $False)]
        [JtIoFolder]$JtIoFolder)
    
    
    
    # [JtSoftwareSource]$SoftwareSource = [JtSoftwareSource]::Uninstall64

    [String]$Name = "Uninstall64"
    [String]$FilterProperty = "DisplayName"
    [String]$VersionProperty = "DisplayVersion"

    [JtSearchSet_Software]$JtSearchSet = [JtSearchSet_Software_Uninstall64]::new()
            
    [JtIoFolder]$JtIoFolder = New-JtIoFolderReport

    [JtInf_Soft_Uninstall64]$JtInf = [JtObj]::GetInit($JtInf, $Name, $JtIoFolder, $JtSearchSet, $FilterProperty, $VersionProperty)
    return $JtInf
}






