using module JtClass
using module JtTbl
using module JtInfi
using module JtTime

class JtRep : JtClass {

    hidden [JtTimeStop]$Uhr
    hidden [String]$Label
    hidden [Boolean]$HideSpezial = $False

    JtRep([String]$Label) {
        $This.ClassName = $Label
        $This.Label = $Label
        
        $This.HideSpezial = $True
        $This.Uhr = [JtTimeStop]::new()
    }
    
    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        Throw "This should not happen! Should be 'GetJtTblRow' overwritten!!!!"
        return $Null
    }

    [JtTblRow]GetJtTblRowDefault([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = New-JtTblRow
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_SystemId()) | Out-Null
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_Org1()) | Out-Null
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_Org2()) | Out-Null
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_Type()) | Out-Null
    
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_Computername()) | Out-Null
        #        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Alias) | Out-Null
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_LabelC()) | Out-Null
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_DaysAgo()) | Out-Null
    
        return $JtTblRow
    }

    [String]GetCsvFileName() {
        [String]$Result = -join ($This.Label, ".csv")
        Return $Result
    }

    [String]GetLabel() {
        return $This.Label
    }

}
