using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtTbl
using module JtCsvWriter


Class JtFolderSummary : JtClass {
    
    [String]$Delimiter = ";"
    [String]$Label = $Null
    [String]$Sub = $Null
    [String]$Expected = $Null
    [JtIoFolder]$IoFolderBase = $Null

    JtFolderSummary ([String]$MyPath, [String]$MyLabel, [String]$MySub, [String]$MyExpected) : Base() {
        $This.ClassName = "JtFolderSummary"
        $This.Label = $MyLabel
        $This.Sub = $MySub
        $This.Expected = $MyExpected
        $This.IoFolderBase = [JtIoFolder]::new($MyPath)
    }
}

Function New-JtFolderSummary {

    Param (
        [Parameter()]
        [String]$Path,
        [Parameter()]
        [String]$Label,
        [Parameter()]
        [String]$Sub,
        [Parameter()]
        [String]$Expected
    )

    [JtFolderSummary]::new($Path, $Label, $Sub, $Expected)
}


Class JtFolderSummaryMeta : JtFolderSummary {
    
    JtFolderSummaryMeta([String]$MyPath, [String]$MyLabel, [String]$MySub, [String]$MyExpected) : base($MyPath, $MyLabel, $MySub, $MyExpected) {
        $This.ClassName = "JtFolderSummaryMeta"
    }

    [Boolean]DoIt() {
        Write-JtLog -Text ( -join ("Label:", $This.Label, " - Sub:", $This.Sub))
        
        [JtIoFolder]$TheFolder = $This.IoFolderBase.GetSubFolder($This.Sub)
    
        $JtTblTable = New-JtTblTable -Label $This.ClassName

        [JtTblRow]$JtTblRow = New-JtTblRow
        
        [System.Collections.ArrayList]$Subfolders = $TheFolder.GetSubFolders()
        foreach ($SubFolder in $Subfolders) {
            [JtIoFolder]$MyFolder = $SubFolder
            $FileCountExpected = 0 

            [String]$FolderName = $MyFolder.GetName()
            $JtTblRow.AddValue("NAME", $FolderName)
            # $JtTblRow.AddValue("Label", $This.Label)
            [Array]$ExpectedTypes = $This.Expected.Split(",")

            foreach ($MyType in $ExpectedTypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension

                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                
                $LabelForType = -join ("X", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "")
                
                $ColumnName = $LabelForType 
                $ColumnValue = $CountForType
                

                $FileCountExpected = $FileCountExpected + $CountForType
            }

            [int16]$intExpected = $ExpectedTypes.Count
            

            # Is the result ok? ("OK", "")
            [String]$NumberOk = "0"
            if ($FileCountExpected -ge $intExpected) {
                $NumberOk = "1"
            }
            
            $ColumnName = "OK"
            $ColumnValue = $NumberOk
            # $JtTblRow.AddValue( $ColumnName, $ColumnValue)

            # Is the result ok? ("OK", "")
            [String]$TextOk = "Nein"
            if ($FileCountExpected -ge $intExpected) {
                $TextOk = "Ja"
            }

            $ColumnName = "Best"
            $ColumnValue = $TextOk
            # $JtTblRow.AddValue( $ColumnName, $ColumnValue)



            $ColumnName = "Gef_SOLL"
            $ColumnValue = $ExpectedTypes.Count
            # $JtTblRow.AddValue( $ColumnName, $ColumnValue)
            


            # How many files were expected? (1)
            $ColumnName = "Gef_IST"
            $ColumnValue = $FileCountExpected
            # $JtTblRow.AddValue( $ColumnName, $ColumnValue)
            
            
            # Which filetypes had to be delivered? (".pdf,.txt")
            $ColumnName = "Typen_SOLL"
            $ColumnValue = $This.Expected
            # $JtTblRow.AddValue( $ColumnName, $ColumnValue)

            # Which filetypes were delivered? (.pdf,.txt)
            [System.Collections.ArrayList]$AllTypes = $MyFolder.GetFileTypesInFolder()
            $ColumnName = "Typen_IST"
            $ColumnValue = $AllTypes -join ","
            # $JtTblRow.AddValue($ColumnName, $ColumnValue)


            # Generate columes for each expected type (X_pdf,X_jpg)
            foreach ($MyType in $ExpectedTypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension
                [String]$TypeLabel = $MyExtension.Replace(".meta", "")
                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                
                $LabelForType = -join ("X", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "")
                $LabelForType = $LabelForType.Replace("_", "")
                
                $ColumnName = $LabelForType 
                $ColumnValue = $CountForType
                
                # $JtTblRow.AddValue( $ColumnName, $ColumnValue)


                $LabelForType = $TypeLabel.ToUpper()
                $LabelForType = $LabelForType.Replace(".", "")
                $LabelForType = $LabelForType.Replace("_", "")
                $ColumnName = $LabelForType 

                $ColumnValue = "-"
                [JtIoFile]$MyFile = $null
                if($FilesWithExtension.Count -gt 0) {
                    [JtIoFile]$MyFile = $FilesWithExtension[0]
                    $ColumnValue = $MyFile.GetName()
                    $ColumnValue = $ColumnValue.Replace($MyExtension, "")
                }
                $JtTblRow.AddValue( $ColumnName, $ColumnValue)


            }
                
            $JtTblTable.AddRow($JtTblRow)
        }

        [JtCsvWriter]$JtCsvWriter = New-JtCsvWriter -JtIofolder $This.IoFolderBase -Objects $JtTblTable.GetObjects() -Label $This.Label
        $JtCsvWriter.DoWrite()
        return $True
    }

}


Function New-JtFolderSummaryMeta {

    Param (
        [Parameter()]
        [String]$Path,
        [Parameter()]
        [String]$Label,
        [Parameter()]
        [String]$Sub
    )

    [JtFolderSummary]$JtFolderSummary = [JtFolderSummaryMeta]::new($Path, $Label, $Sub, ".user.meta,.room.meta")
    $JtFolderSummary.DoIt()
}







Class JtFolderSummaryExpected : JtFolderSummary {
    
    JtFolderSummaryExpected([String]$MyPath, [String]$MyLabel, [String]$MySub, [String]$MyExpected) : base($MyPath, $MyLabel, $MySub, $MyExpected) {
        $This.ClassName = "JtFolderSummaryExpected"
    }

    [Boolean]DoIt() {
        Write-JtLog -Text ( -join ("Label:", $This.Label, " - Sub:", $This.Sub))
        
        [JtIoFolder]$TheFolder = $This.IoFolderBase.GetSubFolder($This.Sub)
    
        $JtTblTable = New-JtTblTable -Label $This.ClassName

        [JtTblRow]$JtTblRow = New-JtTblRow
        
        [System.Collections.ArrayList]$Subfolders = $TheFolder.GetSubFolders()
        foreach ($SubFolder in $Subfolders) {
            [JtIoFolder]$MyFolder = $SubFolder
            $FileCountExpected = 0 

            [String]$FolderName = $MyFolder.GetName()
            $JtTblRow.AddValue("Name", $FolderName)
            $JtTblRow.AddValue("Label", $This.Label)
            [Array]$ExpectedTypes = $This.Expected.Split(",")

            
           
            foreach ($MyType in $ExpectedTypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension

                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                
                $LabelForType = -join ("X", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "_")
                
                $ColumnName = $LabelForType 
                $ColumnValue = $CountForType
                

                $FileCountExpected = $FileCountExpected + $CountForType
            }

            [int16]$intExpected = $ExpectedTypes.Count
            

            # Is the result ok? ("OK", "")
            [String]$NumberOk = "0"
            if ($FileCountExpected -ge $intExpected) {
                $NumberOk = "1"
            }
            
            $ColumnName = "OK"
            $ColumnValue = $NumberOk
            $JtTblRow.AddValue( $ColumnName, $ColumnValue)

            # Is the result ok? ("OK", "")
            [String]$TextOk = "Nein"
            if ($FileCountExpected -ge $intExpected) {
                $TextOk = "Ja"
            }

            $ColumnName = "Best"
            $ColumnValue = $TextOk
            $JtTblRow.AddValue( $ColumnName, $ColumnValue)



            $ColumnName = "Gef_SOLL"
            $ColumnValue = $ExpectedTypes.Count
            $JtTblRow.AddValue( $ColumnName, $ColumnValue)
            


            # How many files were expected? (1)
            $ColumnName = "Gef_IST"
            $ColumnValue = $FileCountExpected
            $JtTblRow.AddValue( $ColumnName, $ColumnValue)
            
            
            # Which filetypes had to be delivered? (".pdf,.txt")
            $ColumnName = "Typen_SOLL"
            $ColumnValue = $This.Expected
            $JtTblRow.AddValue( $ColumnName, $ColumnValue)

            # Which filetypes were delivered? (.pdf,.txt)
            [System.Collections.ArrayList]$AllTypes = $MyFolder.GetFileTypesInFolder()
            $ColumnName = "Typen_IST"
            $ColumnValue = $AllTypes -join ","
            $JtTblRow.AddValue($ColumnName, $ColumnValue)


            # Generate columes for each expected type (X_pdf,X_jpg)
            foreach ($MyType in $ExpectedTypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension

                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                
                $LabelForType = -join ("X", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "_")
                
                $ColumnName = $LabelForType 
                $ColumnValue = $CountForType
                
                $JtTblRow.AddValue( $ColumnName, $ColumnValue)

            }
                
            $JtTblTable.AddRow($JtTblRow)
        }

        [JtCsvWriter]$JtCsvWriter = New-JtCsvWriter -JtIofolder $This.IoFolderBase -Objects $JtTblTable.GetObjects() -Label $This.Label
        $JtCsvWriter.DoWrite()
        return $True
    }

}


Function New-JtFolderSummaryExpected {

    Param (
        [Parameter()]
        [String]$Path,
        [Parameter()]
        [String]$Label,
        [Parameter()]
        [String]$Sub,
        [Parameter()]
        [String]$Expected
    )

    [JtFolderSummary]$JtFolderSummary = [JtFolderSummaryExpected]::new($Path, $Label, $Sub, $Expected)
    $JtFolderSummary.DoIt()
}




Class JtFolderSummaryAll : JtFolderSummary {
    
    JtFolderSummaryAll([String]$MyPath, [String]$MyLabel, [String]$MySub, [String]$MyExpected) : base($MyPath, $MyLabel, $MySub, $MyExpected) {
        $This.ClassName = "JtFolderSummaryAll"
    }

    [Boolean]DoIt() {
        Write-JtLog -Text ( -join ("Label:", $This.Label, " - Sub:", $This.Sub))
        
        [JtIoFolder]$TheFolder = $This.IoFolderBase.GetSubFolder($This.Sub)
    
        [System.Collections.ArrayList]$AllFiletypes = $TheFolder.GetFiletypesInSubfolders()

        $JtTblTable = New-JtTblTable -Label $This.ClassName

        [JtTblRow]$JtTblRow = New-JtTblRow
        
        [System.Collections.ArrayList]$Subfolders = $TheFolder.GetSubFolders()
        foreach ($SubFolder in $Subfolders) {
            [JtIoFolder]$MyFolder = $SubFolder
            $FileCountExpected = 0 
            $FileCountAll = 0 

            $JtTblRow.AddValue("Name", $MyFolder.GetName())

            $JtTblRow.AddValue("Label", $This.Label)
            
            [Array]$ExpectedTypes = $This.Expected.Split(",")
            
            foreach ($MyType in $ExpectedTypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension

                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                
                $LabelForType = -join ("X", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "_")
                
                $ColumnName = $LabelForType 
                $ColumnValue = $CountForType
                $JtTblRow.AddValue( $ColumnName, $ColumnValue)

                $FileCountExpected = $FileCountExpected + $CountForType
            }

            $ColumnName = "CountExpected"
            $ColumnValue = $FileCountExpected
            $JtTblRow.AddValue( $ColumnName, $FileCountExpected)

            foreach ($MyType in $AllFiletypes) {
                [String]$MyExtension = [String]$MyType
                [String]$TypeLabel = $MyExtension
    
    
                [System.Collections.ArrayList]$FilesWithExtension = $MyFolder.GetJtIoFilesWithExtension($MyExtension)
                [Int16]$CountForType = $FilesWithExtension.Count
                $LabelForType = -join ("Z", $TypeLabel.ToLower())
                $LabelForType = $LabelForType.Replace(".", "_")

                $ColumnName = $LabelForType 
                $ColumnValue = $FilesWithExtension.Count
                $JtTblRow.AddValue($ColumnName, $ColumnValue)
                    
                $FileCountAll = $FileCountAll + $CountForType
            }
                
            $ColumnName = "CountAll"
            $ColumnValue = $FileCountAll   
            $JtTblRow.AddValue($ColumnName, $FileCountAll)
                
            [Boolean]$SameNumber = $false
            if (($FileCountExpected - $ExpectedTypes.Length) -eq 0) {
                $SameNumber = $True
            }
            [String]$IsExpected = "" 
            if ($SameNumber) {
                $IsExpected = "OK"
            }
            else {
                $IsExpected = ""
            }
                
            $ColumnName = "Expected"
            $ColumnValue = $IsExpected
            $JtTblRow.AddValue($ColumnName, $ColumnValue)

            $JtTblTable.AddRow($JtTblRow)
        }

        [JtCsvWriter]$JtCsvWriter = New-JtCsvWriter -JtIofolder $This.IoFolderBase -Objects $JtTblTable.GetObjects() -Label $This.Label
        $JtCsvWriter.DoWrite()
        return $True
    }

}


Function New-JtFolderSummaryAll {

    Param (
        [Parameter()]
        [String]$Path,
        [Parameter()]
        [String]$Label,
        [Parameter()]
        [String]$Sub,
        [Parameter()]
        [String]$Expected
    )

    [JtFolderSummary]$JtFolderSummary = [JtFolderSummaryAll]::new($Path, $Label, $Sub, $Expected)
    $JtFolderSummary.DoIt()
}


