using module JtClass
using module JtUtil
using module JtIo
using module JtIoFile
using module JtPreisliste

class JtColFile : JtClass {


    JtColFile() {
        $This.ClassName = "JtColFile"
    }

    [String]GetHeader() {
        Throw "GetHeader should be overwritten"
        return $Null
    }

    [String]GetLabel() {
        Throw "GetLabel should be overwritten"
        return $Null
    }

    [String]GetName() {
        return $This.ClassName
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        Throw "GetLabel should be overwritten"
        return $Null
    }

    [String]GetOutputFile([JtIoFile]$JtIoFile) {
        [String]$Result = $This.GetOutput($JtIoFile)
        # $Result = $Result.Replace(" ", "_")
        # $Result = $Result.Replace(",", "_")
        return $Result
    }

    [Boolean]CheckValid([String]$Value) {
        return $True
    }

    [Boolean]IsSummable() {
        return $False
    }
}


class JtColFileAge : JtColFile {

    JtColFileAge() : Base() {
        $This.ClassName = "JtColFileAge"
    }

    [String]GetHeader() {
        [String]$Result = "Alter"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFileName_Age()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColFileAge {
    

    [JtColFileAge]::new()
}


class JtColFileAnzahl : JtColFile {

    JtColFileAnzahl()  {
        $This.ClassName = "JtColFileAnzahl"
    }

    [String]GetHeader() {
        [String]$Result = "Anzahl"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFileName_Count()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }

}

Function New-JtColFileAnzahl {

    [JtColFileAnzahl]::new()
}


class JtColFileArea : JtColFile {

    
    JtColFileArea()  {
        $This.ClassName = "JtColFileArea"
    }

    [String]GetHeader() {
        [String]$Result = "DIM"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFileName_Area()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColFileArea {
    
}




class JtColFileDim : JtColFile {

    JtColFileDim()  {
        $This.ClassName = "JtColFileDim"
    }

    [String]GetHeader() {
        [String]$Result = "DIM"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFileName_Dim()
        return $Result
    }

    [Boolean]IsSummable() {
        return $True
    }
}


Function New-JtColFileDim {
    
    [JtColFileDim]::new()
}




class JtColFileEuro : JtColFile {


    JtColFileEuro()  {
        $This.ClassName = "JtColFileEuro"
    }

    [String]GetHeader() {
        [String]$Result = "EURO"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFileName_Euro()
        return $Result
    }

    [Boolean]IsSummable() {
        return $True
    }

}

Function New-JtColFileEuro {
    
    [JtColFileEuro]::new()
}

class JtColFileName : JtColFile {

    JtColFileName() {
        $This.ClassName = "JtColFileName"
    }

    [String]GetHeader() {
        [String]$Result = "FILE"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetName()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}

Function New-JtColFileName {
    
    [JtColFileName]::new()
}




class JtColFilePath : JtColFile {

    JtColFilePath()  {
        $This.ClassName = "JtColFilePath"
    }

    [String]GetHeader() {
        [String]$Result = "PATH"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetPath()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColFilePath {
    
    [JtColFilePath]::new()
}



class JtColFileJtPreisliste : JtColFile {

    [JtPreisliste]$JtPreisliste
    
    JtColFileJtPreisliste([JtPreisliste]$MyJtPreisliste) : Base()  {
        $This.ClassName = "JtColFileJtPreisliste"
        $This.JtPreisliste = $MyJtPreisliste
    }

    [String]GetHeader() {
        [String]$Result = "PREISE"
        return $Result
    }

    [String]GetPaper([JtIoFile]$JtIoFile) {

        [String]$Paper = $JtIoFile.GetInfoFromFileName_Paper()
        return $Paper
    }

    [String]GetArea([JtIoFile]$JtIoFile) {

        [String]$Area = $JtIoFile.GetInfoFromFileName_Area()
        return $Area
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Area = $This.GetArea($JtIoFile)
        [String]$Paper = $This.Paper($JtIoFile)

        [String]$GrundpreisPapier = $This.JtPreisliste.GetPapierGrundpreis($Paper)

        [String]$Result = -join($Area, " x ", $GrundpreisPapier)
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }

}



Function New-JtColFileJtPreisliste {
    
    Param (
        [Parameter(Mandatory=$true)]
        [JtPreisliste]$JtPreisliste
    )

    [JtColFileJtPreisliste]::new($JtPreisliste)
}

class JtColFileJtPreisliste_Ink : JtColFileJtPreisliste {

    JtColFileJtPreisliste_Ink([JtPreisliste]$MyJtPreisliste) : Base($MyJtPreisliste) {
        $This.ClassName = "JtColFileJtPreisliste_Ink"
    }

    [String]GetHeader() {
        [String]$Result = "TINT."
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Area = $This.GetArea($JtIoFile)
        [String]$Paper = $This.GetPaper($JtIoFile)

        [String]$PriceInk = $This.JtPreisliste.GetTinteGrundpreis($Paper)

        [Decimal]$DecArea = [JtUtil]::GetConvert_StringToDecimal($Area)
        [Decimal]$DecPriceInk = [JtUtil]::GetConvert_StringToDecimal($PriceInk)

        [Decimal]$DecResult = ($DecArea * $DecPriceInk)
        
        [String]$Result = [JtUtil]::GetConvert_DecimalToString2($DecResult)
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}



Function New-JtColFileJtPreisliste_Ink {
    
    Param (
        [Parameter(Mandatory=$true)]
        [JtPreisliste]$JtPreisliste
    )

    [JtColFileJtPreisliste_Ink]::new($JtPreisliste)
}


class JtColFileJtPreisliste_Paper : JtColFileJtPreisliste {
    
    JtColFileJtPreisliste_Paper([JtPreisliste]$MyJtPreisliste) : Base($MyJtPreisliste) {
        $This.ClassName = "JtColFileJtPreisliste_Paper"
    }

    [String]GetHeader() {
        [String]$Result = "PAP."
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Area = $This.GetArea($JtIoFile)
        [String]$Paper = $This.GetPaper($JtIoFile)

        [String]$PricePaper = $This.JtPreisliste.GetPapierGrundpreis($Paper)

        [Decimal]$DecArea = [JtUtil]::GetConvert_StringToDecimal($Area)
        [Decimal]$DecPricePaper = [JtUtil]::GetConvert_StringToDecimal($PricePaper)

        [Decimal]$DecResult = $DecPricePaper * $DecArea

        # [String]$Result = -join($Area, " x ", $Price, " = ", ($DecPrice * $DecArea))

        [String]$Result = [JtUtil]::GetConvert_DecimalToString2($DecResult)
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }

}


Function New-JtColFileJtPreisliste_Paper {
    
    Param (
        [Parameter(Mandatory=$true)]
        [JtPreisliste]$JtPreisliste
    )

    [JtColFileJtPreisliste_Paper]::new($JtPreisliste)
}





class JtColFileJtPreisliste_Price : JtColFileJtPreisliste {
    
    JtColFileJtPreisliste_Price([JtPreisliste]$MyJtPreisliste) : Base($MyJtPreisliste) {
        $This.ClassName = "JtColFileJtPreisliste_Price"
    }

    [String]GetHeader() {
        [String]$Result = "PREIS"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Area = $This.GetArea($JtIoFile)
        [String]$Paper = $This.GetPaper($JtIoFile)

        [String]$PricePaper = $This.JtPreisliste.GetPapierGrundpreis($Paper)
        [String]$PriceInk = $This.JtPreisliste.GetTinteGrundpreis($Paper)

        [Decimal]$DecArea = [Decimal]$Area

        [Decimal]$DecArea = [JtUtil]::GetConvert_StringToDecimal($Area)
        [Decimal]$DecPricePaper = [JtUtil]::GetConvert_StringToDecimal($PricePaper)
        [Decimal]$DecPriceInk = [JtUtil]::GetConvert_StringToDecimal($PriceINk)
      
        [Decimal]$DecResult = ($DecArea * $DecPriceInk) + ($DecArea * $DecPricePaper)
        
        [String]$Result = [JtUtil]::GetConvert_DecimalToString2($DecResult)
        return $Result
    }
    
    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColFileJtPreisliste_Price {
    
    Param (
        [Parameter(Mandatory=$true)]
        [JtPreisliste]$JtPreisliste
    )

    [JtColFileJtPreisliste_Price]::new($JtPreisliste)
}



class JtColFileYear : JtColFile {

    JtColFileYear() : Base()  {
        $This.ClassName = "JtColFileYear"
    }

    [String]GetHeader() {
        [String]$Result = "Jahr"
        return $Result
    }

    [String]GetOutput([JtIoFile]$JtIoFile) {
        [String]$Result = $JtIoFile.GetInfoFromFilename_Year()
        return $Result
    }

    [Boolean]IsSummable() {
        return $False
    }
}


Function New-JtColFileYear {
    
    [JtColFileYear]::new()
}
