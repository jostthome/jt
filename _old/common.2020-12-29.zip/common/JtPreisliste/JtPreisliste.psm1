using module JtClass
using module JtIo
using module JtIoFile
using module JtTbl

class JtPreisliste : JtClass {

    [JtTblTable]$JtTblTable = $Null
    
    [String]$Title = ""
    [String]$ColPreisId = "PREIS_ID"
    [String]$ColPapierLabel = "PAPIER"
    [String]$ColTinteLabel = "TINTE"
    [String]$ColTinteGrundpreis = "BASIS_TINTE"
    [String]$ColPapierGrundpreis = "BASIS_PAPIER"

    [String]$Tarif_Papier_Normal = "1.25"
    [String]$Tarif_Papier_Spezial = "2.50"

    [String]$Tarif_Tinte_Normal = "6.5"
    [String]$Tarif_Tinte_Minimal = "1.00"


    JtPreisliste([String]$MyTitle) {
        $This.ClassName = "JtPreisliste"
        $This.Title = $MyTitle

        $This.JtTblTable = New-JtTblTable -Label $This.Title
    }

    [Boolean]AddRow([String]$PreisId, [String]$PapierLabel, [String]$TinteLabel, [String]$PapierGrundpreis, [String]$TinteGrundpreis) {
        [JtTblRow]$JtTblRow = New-JtTblRow

        [String]$Label = ""
        [String]$Value = ""

        $Label = $This.ColPreisId
        $Value = $PreisId
        $JtTblRow.AddValue($Label, $Value)

        $Label = $This.ColPapierLabel
        $Value = $PapierLabel
        $JtTblRow.AddValue($Label, $Value)

        $Label = $This.ColTinteLabel
        $Value = $TinteLabel
        $JtTblRow.AddValue($Label, $Value)

        $Label = $This.ColPapierGrundpreis
        $Value = $PapierGrundpreis
        $JtTblRow.AddValue($Label, $Value)

        $Label = $This.ColTinteGrundpreis
        $Value = $TinteGrundpreis
        $JtTblRow.AddValue($Label, $Value)

        $This.JtTblTable.AddRow($JtTblRow)

        return $True
    }

    [String]GetTitle() {
        return $This.Title
    }

    [Decimal]GetPapierGrundpreis() {
        [Decimal]$Result = 7.77

        return $Result
    }

    [Decimal]GetTinteGrundpreis() {
        [Decimal]$Result = 8.88
        
        return $Result
    }

    [JtTblRow]GetRow([String]$Label) {
        [JtTblRow]$Row = $Null

        [System.Collections.ArrayList]$Rows = $This.JtTblTable.GetRows()
        foreach ($MyRow in $Rows) {

            [String]$PreisId = $MyRow.GetValue($This.ColPreisId)

            if ($Label -eq $PreisId) {
                return $MyRow
            }
        }
        return $Row
    }

    [String]GetPapierGrundpreis([String]$Label) {
        [JtTblRow]$Row = $This.GetRow($Label)

        if ($Null -eq $Row) {
            return "0"
        }
        else {
            return $Row.GetValue($This.ColPapierGrundpreis)
        }
    }

    [String]GetJtTemplateFileName() {
        [String]$Result = -join ("_NACHNAME.VORNAME.LABEL.PAPIER.BxH", [JtIoFile]::FileExtensionPoster)
        return $Result
    }

    [String]GetTinteGrundpreis([String]$Label) {
        [JtTblRow]$Row = $This.GetRow($Label)

        if ($Null -eq $Row) {
            return "0"
        }
        else {
            return $Row.GetValue($This.ColTinteGrundpreis)
        }
    }


}



Function New-JtPreisliste_Plotten_2020_07_01 {

    [JtPreisliste]$JtPreisliste = [JtPreisliste]::new("Plotten_2020_07_01")

    $JtPreisliste.AddRow("fabriano", "FABRIANO", "NORMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("fabriano_minimal", "FABRIANO", "MINIMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("semi", "Fotopapier, matt", "NORMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("semi_minimal", "Fotopapier, matt", "MINIMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("glossy", "Fotopapier, glanz", "NORMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("glossy_minimal", "Fotopapier, glanz", "MINIMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("trans", "Transparent-Papier", "NORMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("trans_minimal", "Transparent-Papier", "MINIMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("180g", "180g-Papier", "NORMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("180g_minimal", "180g-Papier", "MINIMAL", $This.Tarif_Papier_Spezial, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("90g", "90g-Papier", "NORMAL", $This.Tarif_Papier_Normal, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("90g_minimal", "90g-Papier", "MINIMAL", $This.Tarif_Papier_Normal, $This.Tarif_Tinte_Minimal)

    $JtPreisliste.AddRow("own", "Eigenes Papier", "NORMAL", $This.Tarif_Papier_Normal, $This.Tarif_Tinte_Normal)
    $JtPreisliste.AddRow("own_minimal", "Eigenes Papier", "MINIMAL", $This.Tarif_Papier_Normal, $This.Tarif_Tinte_Minimal)
    $JtPreisliste
}

