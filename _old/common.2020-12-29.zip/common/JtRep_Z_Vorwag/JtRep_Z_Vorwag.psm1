using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Vorwag : JtRep {

    JtRep_Z_Vorwag () : Base("z.vorwag") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellCommand())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_ArchiCAD())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LibreOffice())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Firefox64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Thunderbird32())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Thunderbird64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Flash())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_WibuKey())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AcrobatReader())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())

        return $JtTblRow
    }
}


function New-JtRep_Z_Vorwag {

    [JtRep_Z_Vorwag]::new() 

}

