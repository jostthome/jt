using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareSupport : JtRep {

    JtRep_SoftwareSupport() : Base("software.support") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32ComputerSystem().Get_Herst())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32ComputerSystem().Get_Modell())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LenovoSysUp())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellCommand())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellSuppAs())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Opsi())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seadrive())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seafile())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DokanLibrary())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_CiscoAnyConnect())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsVersion())
    
        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())

        return $JtTblRow
    }

}


function New-JtRep_SoftwareSupport {

    [JtRep_SoftwareSupport]::new() 

}

