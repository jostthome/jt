using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtTbl
using module JtUtil
using module JtColRen
using module JtTemplateFile
using module JtCsvWriter
using module JtColFile
using module JtMarkdown
using module JtPreisliste


class JtFolderRenderer : JtClass {

    [JtIoFolder]$JtIoFolder = $Null
    [JtTemplateFile]$JtTemplateFile = $Null

    JtFolderRenderer([JtIoFolder]$TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer"
        $This.JtIoFolder = $TheJtIoFolder
        Write-JtLog -Text (-join("JtFolderRenderer; path:", $This.JtIoFolder.GetPath()))
        $This.JtTemplateFile = New-JtTemplateFile -JtIoFolder $This.JtIoFolder -Extension $This.GetJtTemplateFileExtension()
    }

    [Boolean]DoCheckFolder() {
        [Boolean]$Result = $True
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()

        
        if ($This.JtTemplateFile.IsValid() -eq $False) {
            return $False
        }
        [System.Collections.ArrayList]$JtColRens = $This.JtTemplateFile.GetJtColRens()
        [Int32]$NumTemplateParts = $JtColRens.Count
        
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            $FileNameParts = $FileName.Split(".")
            $NumOfFilenameParts = $FileNameParts.Count
            
            if ($NumOfFilenameParts -ne $NumTemplateParts) {
                Write-JtError -Text ( -join ("Filename does not have the expected format: ", $FileName, ", fileName parts:", $NumOfFilenameParts, " , template parts:", $NumTemplateParts))
                Write-JtError -Text ( -join ("Problem with file: ", $JtIoFile.GetPath()))
                
                [JtIoFolder]$TheFolder = [JtIoFolder]::new($JtIoFile)
                [String]$Message = -join ("Problem with file: ", $JtIoFile.GetName())
                Write-JtFolder -Text $Message -Path $TheFolder.GetPath()
                $Result = $False
            }
            else {
                for ([Int32]$i = 0; $i -lt $NumTemplateParts; $i++) {
                    [String]$MyValue = $FileNameParts[$i]
                    [JtColRen]$JtColRen = $JtColRens[$i]
                    [Boolean]$IsValid = $JtColRen.CheckValid($MyValue)
                    if ($False -eq $IsValid) {
                        [String]$Message = -join ("Problem with file: ", $JtIoFile.GetName())
                        return $False
                    }
                }
            }
        }
        return $Result
    }
    
    [Boolean]DoCleanFilesInFolder() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefix()
        [String]$OutputFileExtension = $This.GetOutputFileExtension()
        $This.JtIoFolder.DoCleanFiles($OutputFilePrefix, $OutputFileExtension)
        
        [String]$OutputFilePrefix = $This.GetOutputFilePrefixCsv()
        [String]$OutputFileExtension = $This.GetOutputFileExtensionCsv()
        $This.JtIoFolder.DoCleanFiles($OutputFilePrefix, $OutputFileExtension)
        
        return $True
    }

    [Boolean]DoWriteCsvFileIn([JtIoFolder]$FolderTarget) {
        [String]$OutputFileLabel = $This.GetOutputFileLabelCsv()
        $OutputFileLabel = [JtUtil]::GetFilenameFromString($OutputFileLabel)
        
        if ($FolderTarget.IsExisting()) {
            # OK.
        }
        else {
            Write-JtError -Text ( -join ("TargetFolder does not exist!!! TargetFolder:", $FolderTarget.GetPath()))
            return $False
        }
        
        if ($This.JtIoFolder.IsExisting()) {
            [JtTblTable]$JtTblTable = $This.GetJtTblTable()
            [JtCsvWriter]$JtCsvWriter = [JtCsvWriter]::new($FolderTarget, $JtTblTable.GetObjects(), $OutputFileLabel)
            $JtCsvWriter.DoWrite()
            return $True
        }
        else {
            Write-JtError -Text ( -join ("JtIoFolder does not exist!!! TargetFolder:", $This.JtIoFolder.GetPath()))
            return $False
        }
    }
    
    [Boolean]DoWriteCsvFileInFolder() {
        [JtIoFolder]$FolderTarget = $This.JtIoFolder
        return $This.DoWriteCsvFileIn($FolderTarget)
    }
    
    [Boolean]DoWriteInCInventory() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        # $This.DoCleanFilesInFolder()
        $This.DoWriteSpecialFileInCInventory()
        return $True
    }
    
    [Boolean]DoWriteInFolder() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $This.DoCleanFilesInFolder()
        $This.DoWriteSpecialFileInFolder()
        return $True
    }
    
    [Boolean]DoWriteSpecialFileIn([JtIoFolder]$FolderTarget) {
        [String]$OutputFileName = $This.GetOutputFileName()
        $OutputFileName = [JtUtil]::GetFilenameFromString($OutputFileName)
        
        if ($FolderTarget.IsExisting()) {
            # OK.
        }
        else {
            Write-JtError -Text ( -join ("TargetFolder does not exist!!! TargetFolder:", $FolderTarget.GetPath()))
            return $False
        }
        
        [String]$OutputFilePath = $FolderTarget.GetFilePath($OutputFileName)
        if ($This.JtIoFolder.IsExisting()) {
            Write-JtIo -Text ( -join ("WARNING. Creating special file. PREFIX:", $This.GetOutputFilePrefix(), " EXTENSION:", $This.GetOutputFileExtension(), "; file:", $OutputFilePath))
            $This.JtIoFolder.GetPath() | Out-File -FilePath $OutputFilePath -Encoding UTF8
            return $True
        }
        else {
            Write-JtError -Text ( -join ("JtIoFolder does not exist!!! TargetFolder:", $This.JtIoFolder.GetPath()))
            return $False
        }
    }
    
    [Boolean]DoWriteSpecialFileInFolder() {
        [JtIoFolder]$FolderTarget = $This.JtIoFolder
        return $This.DoWriteSpecialFileIn($FolderTarget)
    }
    

    
    [JtTblTable]GetJtTblTable() {
        Throw "GetJtTblTable should be overwritten"
        return $Null
    }
    
    [String]GetInfo() {
        Throw "GetInfo should be overwritten"
        return $Null
    }
    
    [String]GetLabel() {
        Throw "GetLabel should be overwritten"
        return $Null
    }
    
    [String]GetMdDoc() {
        Throw "GetMdDoc should be overwritten"
        return $Null
    }
    
    [String]GetOutputFileExtension() {
        Throw "GetOutputFileExtension should be overwritten"
        return $Null
    }
    
    [String]GetOutputFilePrefix() {
        Throw "GetOutputFilePrefix should be overwritten"
        return $Null
    }
    
    [String]GetOutputFilePrefixCsv() {
        return [JtIoFile]::FilePrefixFolder
    }
    
    [String]GetOutputFileExtensionCsv() {
        return [JtUtil]::FileExtensionCsv
    }
    
    [String]GetOutputFileLabelCsv() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefixCsv()
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$FileLabel = $MyFolderName
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $FileLabel)
        return $OutputFileName
    }
    
    [String]GetOutputFileName() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefix()
        [String]$OutputFileExtension = $This.GetOutputFileExtension()
        [String]$MyValue = $This.GetInfo()
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$FileLabel = -join ($MyFolderName, ".", $MyValue)
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $FileLabel, $OutputFileExtension)
        return $OutputFileName
    }

    [String]GetSum([String]$MyColumn) {
        [Decimal]$MySum = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            [Decimal]$MyDec = 0

            $This.GetJtTemplateFile().GetJtTemplateFileName()

            [String]$MyValue = $JtIoFile.GetInfoFromFileName($This.GetJtTemplateFile().GetJtTemplateFileName(), $JtIoFile.GetName(), $MyColumn)
            $MyValue = $MyValue.Replace("_", ",")
            
            [Decimal]$MyDec = 0

            try {
                [Decimal]$MyDec = [Decimal]$MyValue
            }
            catch {
                Write-JtError -Text ( -join ("Problme in COL:", $MyColumn, " with value:", $MyValue))
            }
            $MySum = $MySum + $MyDec
        }
        [Decimal]$DecResult = $MySum / 100

        [String]$Result = $DecResult.ToString("0.00")
        $Result = $Result.Replace(",", "_")
        $Result = $Result.Replace(".", "_")
        return $Result
    }


    [JtTemplateFile]GetJtTemplateFile() {
        return $This.JtTemplateFile
    }
    
    [String]GetJtTemplateFileExtension() {
        # [String]$Extension = [JtIoFile]::FileExtensionFolder
        Throw "GetJtTemplateFileExtension should be overwritten"
        return $Null
    }
}

class JtFolderRenderer_Count : JtFolderRenderer {

    JtFolderRenderer_Count([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Count"
    }

    [JtTblTable]GetJtTblTable() {
        [JtTblTable]$JtTblTable = New-JtTblTable -Label "Files"
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
        [System.Collections.ArrayList]$JtColRens = $MyJtTemplateFile.GetJtColRens()

        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog -Text ( -join ("____FileName:", $FileName))
    
            $FilenameParts = $FileName.Split(".")
            [JtTblRow]$JtTblRow = New-JtTblRow
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$JtColRen = $JtColRens[$j]
                [String]$Header = $JtColRen.GetHeader()
                [String]$Value = $JtColRens[$j].GetOutput($FilenameParts[$j])
                $JtTblRow.AddValue($Header, $Value)
            }

            [JtColFile]$JtColRen = New-JtColFileYear
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            [JtColFile]$JtColRen = New-JtColFileAge
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            $JtTblTable.AddRow($JtTblRow)
        }
        return $JtTblTable
    }

    [Decimal]GetInfo() {
        [Decimal]$MyCount = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            if($JtIoFile.GetInfoFromFileName_Count_IsValid()) {
                [String]$MyAnz = $JtIoFile.GetInfoFromFileName_Count()
                [Decimal]$MyDecAnz = [Decimal]$MyAnz 
                $MyCount = $MyCount + $MyDecAnz
            } else {
                [JtIoFolder]$Folder = [JtIoFolder]::new($JtIoFile)
                Write-JtFolder -Text (-join("Problem with file: "), $JtIoFile.GetName()) -Path $Folder.GetPath()
            }
            
        }
        return $MyCount
    }

    [String]GetLabel() {
        return "COUNT"
    }
    
    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixAnzahl
        return $Result
    }

    [String]GetJtTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionFolder
        return $Extension
    }

}


class JtFolderRenderer_Default : JtFolderRenderer {

    JtFolderRenderer_Default([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Default"
    }

    [JtTblTable]GetJtTblTable() {
        [JtTblTable]$JtTblTable = New-JtTblTable -Label "Sum"
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
        [System.Collections.ArrayList]$JtColRens = $MyJtTemplateFile.GetJtColRens()
    
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog -Text ( -join ("____FileName:", $FileName))

            $FilenameParts = $FileName.Split(".")
            [JtTblRow]$JtTblRow = New-JtTblRow
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$JtColRen = $JtColRens[$j]
                if ($Null -ne $JtColRen) {
                    [String]$Header = $JtColRen.GetHeader()
                    [String]$Value = $JtColRens[$j].GetOutput($FilenameParts[$j])
                    $JtTblRow.AddValue($Header, $Value)
                }
                else {
                    Write-JtError -Text ( -join ("JtColRen is null. J:", $J, " File:", $MyFile.GetPath()))
                }
            }

            [JtColFile]$JtColRen = New-JtColFileName
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            [JtColFile]$JtColRen = New-JtColFilePath
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            $JtTblTable.AddRow($JtTblRow)
        }
        return $JtTblTable
    }

    [Decimal]GetInfo() {
        [Decimal]$MyCount = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            Write-JtLog -Text ( -join ("JtIoFile: ", $JtIoFile.GetName()))
        }
        return $MyCount
    }

    
    [String]GetLabel() {
        return "DEFAULT"
    }
    
    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixAnzahl
        return $Result
    }

    [String]GetJtTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionFolder
        return $Extension
    }

}


class JtFolderRenderer_Miete : JtFolderRenderer {

    JtFolderRenderer_Miete([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Miete"
    }
    
    [Boolean]DoWriteMd() {
        Write-JtLog -Text ("Writing MD-Doc - BEGIN")
        [String]$Md = $This.GetMdDoc() 
        Write-JtLog -Text ($Md)
        Write-JtLog -Text ("Writing MD-Doc - END")
        
        [String]$OutFileName = $This.GetMdFileName()
        [String]$OutFilePath = $This.JtIoFolder.GetFilePath($OutFileName)
        
        Write-JtIo -Text ( -join ("Writing MD-Doc:", $OutFilePath))
        $Md | Out-File -FilePath $OutFilePath -Encoding UTF8

        return $True
    }

    [String]GetSum_Miete() {
        [String]$MyCol = "MIETE"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }

    [String]GetSum_Nebenkosten() {
        [String]$MyCol = "NEBENKOSTEN"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }

    [String]GetSum_Betrag() {
        [String]$MyCol = "BETRAG"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }

    [JtTblTable]GetJtTblTable() {
        [JtTblTable]$JtTblTable = New-JtTblTable -Label "Miete"
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
        [System.Collections.ArrayList]$JtColRens = $MyJtTemplateFile.GetJtColRens()

        [Int32]$IntLine = 1
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-Host "____FileName:" $FileName
            
            [String]$Value = ""
            
            $FilenameParts = $FileName.Split(".")
            [JtTblRow]$JtTblRow = New-JtTblRow

            for ([Int32]$j = 0; $j -lt ($FilenameParts.Count - 1); $j++) {
                
                [JtColRen]$JtColRen = New-JtColRenInputTextNr
                [String]$Header = "NR"
                $JtTblRow.AddValue($Header, $IntLine)

                [JtColRen]$JtColRen = $JtColRens[$j]
                
                if ($Null -eq $JtColRen) {
                    Write-JtError -Text ( -join ("This should not happen. JtColRen is NULL. JtIoFile:", $JtIoFile.GetPath()))
                }
                else {
                    [String]$Header = $JtColRen.GetHeader()
                    $Value = $JtColRens[$j].GetOutput($FilenameParts[$j])
                    $JtTblRow.AddValue($Header, $Value)
                }
            }
            
            $JtTblTable.AddRow($JtTblRow)
            $IntLine = $IntLine + 1
        }
        
        [JtTblRow]$JtTblRow = New-JtTblRow


        [Int32]$j = 0

        $j = 0
        [JtColRen]$JtColRen = New-JtColRenInputTextNr
        $JtTblRow.AddValue($JtColRen.GetHeader(), "SUM:")

        $j = 0
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), "(Monat)")

        $j = 1
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), "(Art)")

        $j = 2
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), "(Objekt)")
        
        $j = 3
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), "(Mieter)")

        $j = 4
        [String]$MySum = $This.GetSum_Miete()
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), $JtColRen.GetOutput($MySum))
        
        $j = 5
        [String]$MySum = $This.GetSum_Nebenkosten()
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), $JtColRen.GetOutput($MySum))
        
        $j = 6
        [String]$MySum = $This.GetSum_Betrag
        [JtColRen]$JtColRen = $JtColRens[$j]
        $JtTblRow.AddValue($JtColRen.GetHeader(), $JtColRen.GetOutput($MySum))

        $JtTblTable.AddRow($JtTblRow)

        return $JtTblTable
    }



    [String]GetInfo() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }

        $Result = -join($This.GetSum_Miete(),".",$This.GetSum_Nebenkosten(),".", $This.GetSum_Betrag())
        return $Result
    }

    
    [String]GetLabel() {
        return "MIETE"
    }
    


    [String]GetMdDoc() {
        [MdDocument]$MdDocument = [MdDocument]::new("Miete und Nebenkosten - Zahlungen")
        $MdDocument.AddLine( -join ("*", " ", "Stand: ", [JtLog]::GetMyTimestamp()))
        $MdDocument.AddLine( -join ("*", " ", $This.JtIoFolder.GetPath()))

        # $MdDocument.AddLine("Hier werden die Pläne aufgelistet.")


        $MdDocument.AddH2("Beträge")

        [MdTable]$MyTable = [MdTable]::new($This.GetJtTblTable())

        $MdDocument.AddLine($MyTable.GetOutput())

        $MdDocument.AddLine("---")

        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName() {
        [String]$OutputFilePrefix = "zzz.ABRECHNUNG"
        [String]$OutputFileExtension = [JtIoFile]::FileExtensionMd
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $MyFolderName, $OutputFileExtension)
        return $OutputFileName
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

    [String]GetJtTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionWhg
        return $Extension
    }

}







class JtFolderRenderer_Poster : JtFolderRenderer {

    [JtPreisliste]$JtPreisliste = $Null
 
    JtFolderRenderer_Poster([JtIoFolder]$TheJtIoFolder, [JtPreisliste]$MyJtPreisliste) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Poster"
        $This.JtPreisliste = $MyJtPreisliste
    }
    
    [Boolean]DoWriteMd() {
        Write-JtLog -Text ("Writing MD-Doc - BEGIN")
        [String]$Md = $This.GetMdDoc() 
        Write-JtLog -Text ($Md)
        Write-JtLog -Text ("Writing MD-Doc - END")
        
        [String]$OutFileName = $This.GetMdFileName()
        [String]$OutFilePath = $This.JtIoFolder.GetFilePath($OutFileName)
        
        Write-JtIo -Text (-join("Writing MD-Doc:", $OutFilePath))
        $Md | Out-File -FilePath $OutFilePath -Encoding UTF8

        return $True
    }

    [JtTblTable]GetJtTblTable() {
        [JtTblTable]$JtTblTable = New-JtTblTable -Label "Poster"
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
        [System.Collections.ArrayList]$JtColRens = $MyJtTemplateFile.GetJtColRens()

        [Int32]$IntLine = 1
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-Host "____FileName:" $FileName
            
            [String]$Value = ""
            
            $FilenameParts = $FileName.Split(".")
            [JtTblRow]$JtTblRow = New-JtTblRow

            for ([Int32]$j = 0; $j -lt ($FilenameParts.Count - 1); $j++) {
                
                [JtColRen]$JtColRen = New-JtColRenInputTextNr
                [String]$Header = "NR"
                $JtTblRow.AddValue($Header, $IntLine)

                [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
                [String]$Header = $JtColRen.GetHeader()
                [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
                $JtTblRow.AddValue($Header, $Value)

                [JtColRen]$JtColRen = $JtColRens[$j]
                
                if ($Null -eq $JtColRen) {
                    Write-JtError -Text ( -join ("This should not happen. JtColRen is NULL. JtIoFile:", $JtIoFile.GetPath()))
                }
                else {
                    [String]$Header = $JtColRen.GetHeader()
                    $Value = $JtColRens[$j].GetOutput($FilenameParts[$j])
                    $JtTblRow.AddValue($Header, $Value)
                }
                
            }
            
            [JtColFile]$JtColRen = New-JtColFileArea
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)
            
            [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Paper -JtPreisliste $This.JtPreisliste
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)
            
            [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Ink -JtPreisliste $This.JtPreisliste
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)
            
            $JtTblTable.AddRow($JtTblRow)
            $IntLine = $IntLine + 1
        }
        
        [JtTblRow]$JtTblRow = New-JtTblRow

        [JtColRen]$JtColRen = New-JtColRenInputTextNr
        [String]$Header = $JtColRen.GetHeader()
        [String]$Value = "SUM:"
        $JtTblRow.AddValue($Header, $Value)

        [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColRen.GetHeader()
        [String]$Value = $This.GetInfo()
        $JtTblRow.AddValue($Header, $Value)

        [Int32]$i = 0
        foreach ($JtColRender in $JtColRens) {
            $JtTblRow.AddValue($JtColRender.GetHeader(), "")
            $i = $i + 1
        }

        [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Paper -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColRen.GetHeader()
        [String]$Value = ""
        $JtTblRow.AddValue($Header, $Value)

        [JtColFile]$JtColRen = New-JtColFileJtPreisliste_Ink -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColRen.GetHeader()
        [String]$Value = ""
        $JtTblRow.AddValue($Header, $Value)

        $JtTblTable.AddRow($JtTblRow)

        return $JtTblTable
    }


    [String]GetInfo() {
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
        [JtColFile]$JtColFileJtPreisliste_Price = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
        [Decimal]$MyPrice = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            
            [String]$MySheetPrice = $JtColFileJtPreisliste_Price.GetOutput($JtIoFile)

            # Write-Host "___MyArea:" $MyArea
            [Decimal]$MyDecSheetPrice = [JtUtil]::GetConvert_StringToDecimal($MySheetPrice)
            # Write-Host "___MyDecAread:" $MyDecArea
    
            $MyPrice = $MyPrice + $MyDecSheetPrice
        }
        [Decimal]$DecResult = $MyPrice

        [String]$Result = [JtUtil]::GetConvert_DecimalToString2($DecResult)
        # $Result = $Result.Replace(", ", "_")
        # $Result = $Result.Replace(".", "_")
        return $Result
    }

    
    [String]GetLabel() {
        return "POSTER"
    }
    


    [String]GetMdDoc() {
        [MdDocument]$MdDocument = [MdDocument]::new("Fakultät für Jtektur und Landschaft")
        $MdDocument.AddLine("https://www.archland.uni-hannover.de/de/fakultaet/ausstattung/plotservice/")
        $MdDocument.AddH2("Plot-Service - Abrechnung")
        $MdDocument.AddLine( -join ("*", " ", "Stand: ", [JtLog]::GetMyTimestamp()))
        $MdDocument.AddLine( -join ("*", " ", "JtPreisliste: ", $This.JtPreisliste.GetTitle()))
        $MdDocument.AddLine( -join ("*", " ", $This.JtIoFolder.GetPath()))

        # $MdDocument.AddLine("Hier werden die Pläne aufgelistet.")


        $MdDocument.AddH2("Pläne")

        [MdTable]$MyTable = [MdTable]::new($This.GetJtTblTable())

        $MdDocument.AddLine($MyTable.GetOutput())

        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Kunde")
        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Plot-Service")
        $MdDocument.AddLine("---")

        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName() {
        [String]$OutputFilePrefix = "zzz.ABRECHNUNG"
        [String]$OutputFileExtension = [JtIoFile]::FileExtensionMd
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $MyFolderName, $OutputFileExtension)
        return $OutputFileName
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

    [JtPreisliste]GetJtPreisliste() {
        return $This.JtPreisliste
    }

    [String]GetJtTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionPoster
        return $Extension
    }

}


class JtFolderRenderer_Sum : JtFolderRenderer {

    JtFolderRenderer_Sum([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Sum"
    }
    
    [JtTblTable]GetJtTblTable() {
        [JtTblTable]$JtTblTable = New-JtTblTable -Label "Sum"
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$MyJtTemplateFile = $This.GetJtTemplateFile()
    
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog -join("____FileName: ",$FileName)

            [String]$Value = ""
    
            $FilenameParts = $FileName.Split(".")
            [JtTblRow]$JtTblRow = New-JtTblRow
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$JtColRen = $This.JtTemplateFile.GetJtColRenForColumnNumber($j)

                [String]$Header = $JtColRen.GetHeader()
                [String]$Value = $JtColRen.GetOutput($FilenameParts[$j])
                $JtTblRow.AddValue($Header, $Value)
            }

            [JtColFile]$JtColRen = New-JtColFileYear
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            [JtColFile]$JtColRen = New-JtColFileAge
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            [JtColFile]$JtColRen = New-JtColFileName
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            [JtColFile]$JtColRen = New-JtColFilePath
            [String]$Header = $JtColRen.GetHeader()
            [String]$Value = $JtColRen.GetOutputFile($JtIoFile)
            $JtTblRow.AddValue($Header, $Value)

            $JtTblTable.AddRow($JtTblRow)
        }
        return $JtTblTable
    }

    [String]GetInfo() {
        [Decimal]$MySum = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            [Decimal]$MyDecEuro = 0

            if ($JtIoFile.GetInfoFromFileName_Euro_IsValid()) {
                [String]$MyEuro = $JtIoFile.GetInfoFromFileName_Euro()
                
                # Write-Host "___MyEuro:" $MyEuro
                [Decimal]$MyDecEuro = [Decimal]$MyEuro 
                # Write-Host "___MyDecEuro:" $MyDecEuro
            }
            else {
                [JtIoFolder]$JtIoFolder = [JtIoFolder]::new($JtIoFile)
                Write-JtFolder -Text ( -join ("Problem with file EURO:", $JtIoFile.GetName())) -Path $JtIoFolder.GetPath()
            }
    
            $MySum = $MySum + $MyDecEuro
        }
        [Decimal]$DecResult = $MySum / 100

        [String]$Result = $DecResult.ToString("0.00")
        $Result = $Result.Replace(",", "_")
        $Result = $Result.Replace(".", "_")
        return $Result
    }

    [String]GetLabel() {
        return "SUM"
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

    [String]GetJtTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionFolder
        return $Extension
    }

}
