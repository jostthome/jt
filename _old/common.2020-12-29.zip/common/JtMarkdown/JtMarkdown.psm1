using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtTbl
using module JtCsvWriter

class JtMarkdown : JtClass{

    JtMarkdown() {
        $This.ClassName = "JtMarkdown"
        $This.JtInf_Name = $This.GetType()
    }

    static [String]GetLinkForLine([String]$Line) {
        [String]$Result = $Line
        if ($Null -eq $Line) {

        }
        else {
            # [String]$MyPattern = "[\[][A-Za-z_]*[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))"
            [String]$MyPattern = "(https:\/\/)[A-Za-z0-9.\-\/]*"
            $Line -match $MyPattern
            if ($Null -eq $matches) {

            }
            else {
                [String]$Link = $matches[0]
                $Result = $Link
            }
        }
        return $Result
    }

    static [System.Collections.ArrayList]GetList([System.Collections.ArrayList]$JtIoFiles, [String]$ThePattern) {
        [System.Collections.ArrayList]$MyList = [System.Collections.ArrayList]::new()
        foreach ($AnyFile in $JtIoFiles) {
            [JtIoFile]$JtIoFile = $AnyFile
            [String]$FileName = $JtIoFile.GetName()
            [String]$FileLabel = $JtIoFile.GetLabelForFileName()
            [String]$FilePath = $JtIoFile.GetPath()
            [String]$Pattern = $ThePattern.Replace("{FILELABEL}", $FileLabel)
            [String]$FileExtension = [System.IO.Path]::GetExtension($FileName)
            
            [String]$Content = Get-Content -Path $JtIoFile.GetPath() -Encoding UTF8
            [System.Collections.ArrayList]$MyHitList = [JtMarkdown]::GetHits($Content, $Pattern)
            foreach ($El in $MyHitList) {
                [String]$Find = $Content | Select-String -Pattern $Pattern
                if ($Null -ne $Find) {
                    $Content -match $Pattern
                    # if ($matches.Length -gt 0) {
                    #     [String]$MyLine = $matches[0]
                    #     if ($MyLine.Length -gt 0) {
                    #         Write-Host "MyLine: " $MyLine
                    #     }
                    # }
                    [PSCustomObject]$MyObject = [PSCustomObject]@{ }
                    $MyObject | Add-Member -MemberType NoteProperty -Name Filename -Value $FileName
                    $MyObject | Add-Member -MemberType NoteProperty -Name Filepath -Value $FilePath
                    $MyObject | Add-Member -MemberType NoteProperty -Name Extension -Value $FileExtension
                    # $MyObject | Add-Member -MemberType NoteProperty -Name Find -Value $MyLine
                    $MyObject | Add-Member -MemberType NoteProperty -Name Label -Value $FileLabel
                    
                    $MyLab = [JtMarkdown]::GetLabelForLine($El)
                    $MyObject | Add-Member -MemberType NoteProperty -Name Lab -Value $MyLab
                    
                    $MyLink = [JtMarkdown]::GetLinkForLine($El)
                    $MyObject | Add-Member -MemberType NoteProperty -Name URL -Value $MyLink
                    $MyList.add($MyObject)
                }
            }
        }
        return $MyList
    }

    static [String]GetLabelForLine([String]$Line) {
        [String]$Result = $Line
        if ($Null -eq $Line) {

        }
        else {
            # [String]$MyPattern = "[\[][A-Za-z_]*[\]][\(](https:\/\/)[A-Za-z0-9.\-\/]*(\))"
            [String]$MyPattern = "[\[][A-Za-z0-9_]*[\]]"
            $Line -match $MyPattern
            if ($Null -eq $matches) {

            }
            else {
                [String]$Label = $matches[0]
                $Result = $Label
            }
        }
        $Result = $Result.Replace("[", "")
        $Result = $Result.Replace("]", "")
        return $Result
    }


    static [System.Collections.ArrayList]GetHits([String]$Content, [String]$Pattern) {
        $Mat3 = $Content.split() | Where-Object { $_ -match $Pattern } | ForEach-Object { $Matches[0] }
        $Mat3

        [System.Collections.ArrayList]$MyList = [System.Collections.ArrayList]::new()
        # if($matches.Length -gt 0) {
        $e = $mat3 | foreach-object { $_ -match $Pattern } | ForEach-Object { $Matches[0] }
        if ($null -eq $e) {

        }
        else {
            ForEach ($element in $e) {
                $MyList.Add($element)
            }
        }
        return $MyList
    }

    static [Boolean]DoWriteJtMarkdownCsv([JtIoFolder]$FolderWork, [JtIoFolder]$FolderTarget, [String]$MyLabel, [String]$MyFilter, [String]$ThePattern) {
        [System.Collections.ArrayList]$MyList = [System.Collections.ArrayList]::new()
        [System.Collections.ArrayList]$JtIoFiles = $FolderWork.GetJtIoFilesWithFilter($MyFilter)

        [System.Collections.ArrayList]$MyList = [JtMarkdown]::GetList($JtIoFiles, $ThePattern)

        [JtCsvWriter]$JtCsvWriter = [JtCsvWriter]::new($FolderTarget, $MyList, $MyLabel)

        return $JtCsvWriter.DoWrite()
    }

}



class MdDocument {

    [String]$End = "`n"


    hidden [System.Collections.ArrayList]$Lines = [System.Collections.ArrayList]::new()

    MdDocument([String]$Title) {
        $This.AddH1($Title)
    }

    [Boolean]AddLine([String]$Input) {
        $This.Lines.Add(-join($Input, $This.End))
        return $True
    }

    [Boolean]AddLine() {
        $This.Lines.Add(-join("---", $This.End))
        return $True
    }

    [Boolean]AddH1([String]$Input) {
        [String]$MyLine = -join("# ", $Input, $This.End)
        $This.AddLine($MyLine)
        return $True
    }

    [Boolean]AddH2([String]$Input) {
        [String]$MyLine = -join("## ", $Input, $This.End)
        $This.AddLine($MyLine)
        return $True
    }

    [Boolean]AddH3([String]$Input) {
        [String]$MyLine = -join("### ", $Input, $This.End)
        $This.AddLine($MyLine)
        return $True
    }

    [String]GetOutput() {
        [String]$Result = ""

        $Result = ($This.Lines -join $This.End)

        return $Result
    }

}


class MdTable : JtClass {

    [String]$Vertical = "|"

    [JtTblTable]$JtTblTable = $Null

    MdTable([JtTblTable]$MyJtTblTable) {
        if($Null -eq $MyJtTblTable) {
            Throw "JtTblTable is null!"
        }
        $This.JtTblTable = $MyJtTblTable
    }

    [String]GetHeadLine([System.Array]$ArrayList) {
        [String]$Vert = $This.Vertical

        [System.Collections.ArrayList]$MyLIne = [System.Collections.ArrayList]::new()
        
        [String]$Result = ""
        
        $MYLine.Add($Vert)
        
        [Int32]$i = 0
        foreach ($Element in $ArrayList) {
            [String]$TheElement = $This.JtTblTable.GetFormattedOutput($i, $Element)
            $MyLine.Add($TheElement)
            $MyLine.Add($Vert)
            $i = $i + 1
        }

        $MyLine.Add("`n")
        
        $Result = -join ($MyLine)
        return $Result
    }
    
    [String]GetLine([System.Collections.ArrayList]$ArrayList) {
        [String]$Vert = $This.Vertical
        [String]$Hor = "-----------------------------------------------------------------------------------"
        
        [System.Collections.ArrayList]$MyLIne = [System.Collections.ArrayList]::new()
        
        [String]$Result = ""
        
        $MYLine.Add($Vert)
        
        [Int32]$i = 0
        foreach ($Element in $ArrayList) {
            [String]$TheElement = $This.JtTblTable.GetFormattedOutput($i, $Hor)
            $MyLine.Add($TheElement)
            $MyLine.Add($Vert)
            $i = $i + 1
        }

        $MyLine.Add("`n")
        
        $Result = [system.String]::Join("", $MyLine.ToArray())
        return $Result
    }

    [String]GetOutput() {
        [System.Collections.ArrayList]$MyRows = $This.JtTblTable.GetRows()
        [System.Collections.ArrayList]$Lines = [System.Collections.ArrayList]::new()

        [JtTblRow]$JtTblRowHeader = $This.JtTblTable.GetHeader()

        [System.Array]$TheList = $JtTblRowHeader.GetKeys() 
        $Lines.add($This.GetHeadLine($TheList))
        $Lines.add($This.GetLine($TheList))
        
        foreach ($MyRow in $MyRows) {
            [System.Array]$TheList = $MyRow.GetValues() 
            $Lines.add($This.GetHeadLine($TheList))
        }

        [String]$Result = ""
        $Result = [system.String]::Join("", $Lines.ToArray())

        return $Result
    }
}
