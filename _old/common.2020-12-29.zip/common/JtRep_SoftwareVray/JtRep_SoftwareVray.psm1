using module JtTbl
using module JtInfi
using module JtRep

class JtRep_SoftwareVray : JtRep {

    JtRep_SoftwareVray() : Base("software.vray") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Max_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRay3ds())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Revit_2021())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRevit())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Rhino_6())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRhino())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Sketchup())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRaySketchup())

        return $JtTblRow
    }

}


function New-JtRep_SoftwareVray {

    [JtRep_SoftwareVray]::new() 

}


