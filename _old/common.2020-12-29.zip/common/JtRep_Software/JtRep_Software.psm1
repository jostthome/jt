using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Software : JtRep {
 
    JtRep_Software () : Base("software") {
        $This.HideSpezial = $False
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        foreach ($Field in $JtInfi.GetJtInf_Soft().GetFields()) {
            [JtFieldSoftware]$JtFieldSoftware = $Field
            $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().($JtFieldSoftware.GetLabel()))
        }
 
        return $JtTblRow
    }
}


function New-JtRep_Software {

    [JtRep_Software]::new() 

}



