using module JtTbl
using module JtInf_Soft
using module JtInfi
using module JtRep

class JtRep_Z_Iat : JtRep {
    
    JtRep_Z_Iat() : Base("z.iat") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().Get_WinVersion())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_CreativeSuite_CS6())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Photoshop_CC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Office()) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Rhino_6()) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_SketchUp())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRay3ds())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRevit())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRayRhino())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_vRaySketchup())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LenovoSysUp())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AutoCAD_2020())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Max_2020())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Maya_2020())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Revit_2020())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_ArchiCAD())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Vectorworks())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Cinema4D())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_GoogleEarth())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Unity())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_UnityHub())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Arduino())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_LibreOffice())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AcrobatReader())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_AntiVirus())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Chrome())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Firefox64())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Java())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_PDF24())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellCommand())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_DellSuppAs())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seadrive())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Seafile())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Sumatra())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_VLC())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_WibuKey())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Get_Zip())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsVersion())

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().Get_Grafikkarte())
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().Get_TreiberVersion()) 

        return $JtTblRow
    }

}



function New-JtRep_Z_Iat {

    [JtRep_Z_Iat]::new() 

}

