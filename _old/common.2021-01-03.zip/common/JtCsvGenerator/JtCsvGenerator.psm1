using module JtClass
using module JtCsvWriter
using module JtIo
using module JtIoFolder
using module JtInfi
using module JtRep
using module JtReps
using module JtTbl

class JtCsvGenerator : JtClass {

    [JtIoFolder]$JtIoFolder 
    [String]$Label

    JtCsvGenerator([JtIoFolder]$MyJtIoFolder, [String]$MyLabel) : Base() {
        $This.ClassName = "JtCsvGenerator"
        $This.JtIoFolder = $MyJtIoFolder
        $This.Label = $MyLabel
    
        [JtInfi]$JtInfi = New-JtInfi -JtIoFolder $This.JtIoFolder

        [System.Collections.ArrayList]$MyReps = [JtReps]::GetReps()

        foreach ($MyRep in $MyReps) {
            [JtRep]$Rep = $MyRep

            [Boolean]$UseLine = $True
            if ($True -eq $Rep.HideSpezial ) {
                if ($JtInfi.GetIsNormalBoot()) {
                    $UseLine = $True
                }
                else {
                    $UseLine = $False
                }
            }
            else {
                $UseLine = $True
            }
            
            # test it
            [Boolean]$UseLine = $True
            # test it
            
            [JtTblTable]$JtTblTable = New-JtTblTable -Label $Rep.GetLabel()
            if ($True -eq $UseLine) {
                [JtTblRow]$JtTblRow = $Rep.GetJtTblRow($JtInfi)
                $JtTblTable.AddRow($JtTblRow) | Out-Null
            }

            $DataTable = Get-JtDataTableFromTable -JtTblTable $JtTblTable

            Write-JtLog (-join("Type of DataTable:", $DataTable.GetType()))
            [String]$TheLabel = $JtTblTable.GetLabel()
            [JtIoFolder]$TheFolderCsv = $This.GetFolderCsv()

            [JtCsvData]$JtCsvData = [JtCsvData]::new($TheFolderCsv, $DataTable, $TheLabel)
            $JtCsvData.DoWrite() | Out-Null
        }
    }


    [JtIoFolder]GetFolderCsv() {
        [JtIoFolder]$FolderCsv = $This.JtIoFolder.GetChild("csv", $True)
        return $FolderCsv
    }
}

function New-JtCsvGenerator {

    Param (
        [Parameter(Mandatory = $true)]
        [JtIoFolder]$JtIoFolder,
        [Parameter(Mandatory = $false)]
        [String]$Label
    )
[String]$MyLabel = ""
if(!($Label)) {
    $MyLabel = "NO LABEL"
} else {
    $MyLabel = $Label
}


    [JtCsvGenerator]::new($JtIoFolder, $MyLabel) 
}
