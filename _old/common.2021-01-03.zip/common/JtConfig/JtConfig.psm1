using module JtClass
using module JtIo
using module JtIoFolder

class JtConfig : JtClass {

    [JtIoFolder]$JtIoFolder_Base
    
    JtConfig() {
        $This.ClassName = "JtConfig"
        Write-JtLog -Text "START!"
        
        [String]$MyProjectPath = ""
        [String]$MyPathBase = $env:PATH_BASE
        Write-JtLog -Text ( -join ("MyPathBase:", $MyPathBase))

        if ($Null -eq $MyPathBase) {
            $MyPathBase = ""
        }

        if ($MyPathBase.Length -lt 1) {
            [String]$MyProjectPathNormal = "c:\apps\inventory\default\i"     
            [String]$MyProjectPathDev = -join("d:\Seafile\al-apps\apps\inventory\extern\test")    
            $MyProjectPath = $MyProjectPathNormal
            if (Test-Path $MyProjectPathDev) {
                $MyProjectPath = $MyProjectPathDev
            }
            elseif (Test-Path $MyProjectPathNormal) { 
                $MyProjectPath = $MyProjectPathNormal
            }
            else {
                Throw "Problem with MyProjectPath"
                Exit-PSHostProcess
            }
        }
        else {
            $MyProjectPath = (Get-Item -Path $MyPathBase).parent.FullName
            Write-JtLog -Text ( -join ("MyProjectPath is OK:", $MyProjectPath))
        }
        if ($MyProjectPath.Length -lt 1) {
            Write-JtError -Text ("Problem with MyProjectPath!!!")
            Throw "Problem with MyProjectPath!!!"
        }

        Write-JtLog -Text ( -join ("ProjectPath:", $MyProjectPath))

        [JtIoFolder]$This.JtIoFolder_Base = [JtIoFolder]::new($MyProjectPath)
        $This.DoPrintInfo()
    }

    [Boolean]DoPrintInfo() {
        Write-Host "SHOULD BE LIKE: Get_JtIoFolder_Base :" "D:\Seafile\al-apps\apps\inventory"
        Write-Host "------------IS: Get_JtIoFolder_Base :" $This.Get_JtIoFolder_Base().GetPath()
        
        Write-Host "SHOULD BE LIKE: Get_JtIoFolder_Common :" "c:\apps\inventory\common"
        Write-Host "------------IS: Get_JtIoFolder_Common :" $This.Get_JtIoFolder_Common().GetPath()

        Write-Host "SHOULD BE LIKE: Get_JtIoFolder_Inv :" "c:\_inventory"
        Write-Host "------------IS: Get_JtIoFolder_Inv :" $This.Get_JtIoFolder_Inv().GetPath()

        Write-Host "SHOULD BE LIKE: Get_JtIoFolder_Report :" "c:\_inventory\report"
        Write-Host "------------IS: Get_JtIoFolder_Report :" $This.Get_JtIoFolder_Report().GetPath()

        return $True
    }
    
    # --------------------------------------------------------------------------------------

    
    [JtIoFolder]Get_JtIoFolder_Base() {
        return $This.JtIoFolder_Base
    }
    
    [JtIoFolder]Get_JtIoFolder_Common() {
        [JtIoFolder]$Result = $null
        [JtIoFolder]$Folder_C_Apps_Inventory = [JtIoFolder]::new("c:\apps\inventory")
        [JtIoFolder]$Folder_C_Apps_Inventory_Common = $Folder_C_Apps_Inventory.GetChild("common")
        $Result = $Folder_C_Apps_Inventory_Common
        return $Result
    }

    [JtIoFolder]Get_JtIoFolder_Inv() {
        return New-JtIoFolderInv
    }

    [JtIoFolder]Get_JtIoFolder_Report() {
        return New-JtIoFolderReport
    }
    
}

Function New-JtConfig {

    [JtConfig]::new()
}
