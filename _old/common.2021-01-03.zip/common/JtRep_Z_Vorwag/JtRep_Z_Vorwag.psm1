using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_Vorwag : JtRep {

    JtRep_Z_Vorwag () : Base("z.vorwag") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellCommand)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().ArchiCAD)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().LibreOffice)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Firefox64)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Thunderbird32)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Thunderbird64)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Flash)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().WibuKey)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AcrobatReader)

        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().Get_OsCaption())

        return $JtTblRow
    }
}


function New-JtRep_Z_Vorwag {

    [JtRep_Z_Vorwag]::new() 

}

