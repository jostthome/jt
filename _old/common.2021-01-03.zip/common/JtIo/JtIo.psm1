using module JtClass
using module JtUtil

class JtIo : JtClass {

    static [String]$JtRepo_Client_Suffix_Time = "time"
    static [String]$JtRepo_Client_Suffix_Errors = "errors"
    static [String]$JtRepo_Client_Part_Localhost = "localhost"

    static [String]$JtRepo_Client_Prefix_Report = "report"
    static [String]$JtRepo_Client_Prefix_Files = "files"

    static [String]$JtRepo_Client_Extension_Meta = ".meta"

    static hidden [String]$TimestampFormat = "yyyy-MM-dd_HH-mm-ss"

    hidden [String]$Path = ""
    hidden [Boolean]$BlnExists = $true

    static [String]GetComputername() {
        [String]$Result = ""
        $Result = $env:COMPUTERNAME
        $Result = $Result.ToLower()
        $Computername = $Result
        return $Computername
    }



    static [String]ConvertPathToLabel([String]$Path) {
        [String]$Result = $Path
        $Result = $Result.Replace("%COMPUTERNAME%", $env:COMPUTERNAME)
        $Result = $Result.Replace(":", "")
        $Result = $Result.Replace("*", "")
        $Result = $Result.Replace("\.", "")
        $Result = $Result.Replace("\", "_")
        $Result = $Result.Replace(".", "_")
        $Result = $Result.Replace("__", "_")
        return $Result
    }

    static [String]GetErrors([String]$Path) {
        [String]$Result = "---"
        
        [String]$Match = -join ([JtIo]::JtRepo_Client_Prefix_Report, '.*', '.', [JtIo]::JtRepo_Client_Suffix_Errors, [JtIo]::JtRepo_Client_Extension_Meta)
        
        $MyFiles = Get-ChildItem -Path $Path | Where-Object { $_.Name -match $Match }
        
        if ($Null -ne $MyFiles) {
            if ($MyFiles.Length -gt 0) {
                $Filename = $MyFiles[0].Name
                [String[]]$Parts = $Filename.Split(".")
                $Result = $Parts[1]
            }
        }
        return $Result
    }

    static [String]GetLabelC() {
        $MyLabel = Get-WMIObject -Class Win32_Volume | Where-Object -Property DriveLetter -eq "C:" | Select-Object Label
        
        [String] $LabelC = $MyLabel.Label
        
        return $LabelC
    }

    static [String]GetMediaTypeForValue($Value) {
        [String]$Result = ""

        $Result = switch ($Value) { 
            3 { "HDD" }
            4 { "SSD" } 
            default { $Value }
        } 

        return $Result
    }

    static [String]GetSystemId() {
        $LabelC = [JtIo]::GetLabelC()
        $Computername = $env:COMPUTERNAME
        
        [String]$SystemId = ""
        
        $SystemId = -join ($Computername, ".", $LabelC)
        $SystemId = $SystemId.ToLower()
        return $SystemId
    }

    JtIo() {
        $This.ClassName = "JtIo"
    }

    
    [String]GetName() {
        Throw "GetName should be overwritten"
        return $Null
    }
    
    [String]GetLabelForName() {
        [String]$MyName = $This.GetName()
        [String]$Result = $MyName
        $Result = $Result.Replace(":", "")
        $Result = $Result.Replace("\", "_")
        $Result = $Result.Replace("%COMPUTERNAME%", $env:COMPUTERNAME)
        return $Result
    }
    
    [String]GetLabelForPath() {
        [String]$MyPath = $This.GetPath()
        [String]$Result = [JtIo]::ConvertPathToLabel($MyPath)
        return $Result
    }
    
    [String]GetPath() {
        return $This.Path
    }
}
    


Function New-JtIo {
    
    [JtIo]::new()
}





Export-ModuleMember -Function New-JtIo


