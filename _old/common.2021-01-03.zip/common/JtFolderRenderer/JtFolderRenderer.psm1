﻿using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder
using module JtTbl
using module JtUtil
using module JtColRen
using module JtTemplateFile
using module JtCsvWriter
using module JtColFile
using module JtMd
using module JtPreisliste

class JtFolderRenderer : JtClass {

    [JtIoFolder]$JtIoFolder = $Null
    [JtTemplateFile]$JtTemplateFile = $Null

    JtFolderRenderer([JtIoFolder]$TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer"
        $This.JtIoFolder = $TheJtIoFolder
        Write-JtLog -Text ( -join ("JtFolderRenderer; path:", $This.JtIoFolder.GetPath()))
        $This.JtTemplateFile = Get-JtTemplateFile -JtIoFolder $This.JtIoFolder -Extension $This.GetTemplateFileExtension()
        Write-JtLog(-Join("JtFolderRenderer label:", $this.GetLabel(), " JtTemplateFile name:", $This.JtTemplateFile.GetName()))
    }

    [Boolean]DoCheckFolder() {
        [Boolean]$Result = $True
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()

        
        if ($False -eq $This.JtTemplateFile.IsValid()) {
            return $False
        }
        
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [Boolean]$FileValid = $This.JtTemplateFile.DoCheckFile($JtIoFile)
            if ($($FileValid)) {
                $Result = $False
            }
        }
        return $Result
    }
    
    [Boolean]DoCleanFilesInFolder() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefix()
        [String]$OutputFileExtension = $This.GetOutputFileExtension()
        $This.JtIoFolder.DoCleanFiles($OutputFilePrefix, $OutputFileExtension)
        
        [String]$OutputFilePrefix = $This.GetOutputFilePrefixCsv()
        [String]$OutputFileExtension = $This.GetOutputFileExtensionCsv()
        $This.JtIoFolder.DoCleanFiles($OutputFilePrefix, $OutputFileExtension)
        
        return $True
    }

    [Boolean]DoWriteCsvFileIn([JtIoFolder]$FolderTarget) {
        [String]$OutputFileLabel = $This.GetOutputFileLabelCsv()
        $OutputFileLabel = [JtUtil]::GetFilenameFromString($OutputFileLabel)
        
        if ($FolderTarget.IsExisting()) {
            # OK.
        }
        else {
            Write-JtError -Text ( -join ("TargetFolder does not exist!!! TargetFolder:", $FolderTarget.GetPath()))
            return $False
        }
        
        if ($This.JtIoFolder.IsExisting()) {
            [System.Data.Datatable]$JtTblTable = $This.GetDatatable()
            [JtCsvWriter]$JtCsvWriter = [JtCsvWriter]::new($FolderTarget, $JtTblTable.GetObjects(), $OutputFileLabel)
            $JtCsvWriter.DoWrite()
            return $True
        }
        else {
            Write-JtError -Text ( -join ("JtIoFolder does not exist!!! TargetFolder:", $This.JtIoFolder.GetPath()))
            return $False
        }
    }
    
    [Boolean]DoWriteCsvFileInFolder() {
        [JtIoFolder]$FolderTarget = $This.JtIoFolder
        return $This.DoWriteCsvFileIn($FolderTarget)
    }
    
    [Boolean]DoWriteInCInventory() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        # $This.DoCleanFilesInFolder()
        $This.DoWriteSpecialFileInCInventory()
        return $True
    }

    [Boolean]DoWriteMdFileIn([JtIoFolder]$FolderTarget) {
        Write-JtLog -Text ("Writing MD-Doc - BEGIN")
        [String]$Md = $This.GetMdDoc() 
        Write-JtLog -Text ($Md)
        Write-JtLog -Text ("Writing MD-Doc - END")
        
        [String]$OutFileName = $This.GetMdFileName()
        [String]$OutFilePath = $FolderTarget.GetFilePath($OutFileName)
        
        Write-JtIo -Text ( -join ("Writing MD-Doc:", $OutFilePath))
        $Md | Out-File -FilePath $OutFilePath -Encoding UTF8

        return $True
    }

    [Boolean]DoWriteMdFile() {
        [JtIoFolder]$FolderTarget = $This.JtIoFolder
        return $This.DoWriteMdFileIn($FolderTarget)
    }

    
    [Boolean]DoWriteInFolder() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $This.DoCleanFilesInFolder()
        $This.DoWriteSpecialFileInFolder()
        return $True
    }
    
    [Boolean]DoWriteSpecialFileIn([JtIoFolder]$FolderTarget) {
        [String]$OutputFileName = $This.GetOutputFileName()
        $OutputFileName = [JtUtil]::GetFilenameFromString($OutputFileName)
        
        if ($FolderTarget.IsExisting()) {
            # OK.
        }
        else {
            Write-JtError -Text ( -join ("TargetFolder does not exist!!! TargetFolder:", $FolderTarget.GetPath()))
            return $False
        }
        
        [String]$OutputFilePath = $FolderTarget.GetFilePath($OutputFileName)
        if ($This.JtIoFolder.IsExisting()) {
            Write-JtIo -Text ( -join ("WARNING. Creating special file. PREFIX:", $This.GetOutputFilePrefix(), " EXTENSION:", $This.GetOutputFileExtension(), "; file:", $OutputFilePath))
            $This.JtIoFolder.GetPath() | Out-File -FilePath $OutputFilePath -Encoding UTF8
            return $True
        }
        else {
            Write-JtError -Text ( -join ("JtIoFolder does not exist!!! TargetFolder:", $This.JtIoFolder.GetPath()))
            return $False
        }
    }
    
    [Boolean]DoWriteSpecialFileInFolder() {
        [JtIoFolder]$FolderTarget = $This.JtIoFolder
        return $This.DoWriteSpecialFileIn($FolderTarget)
    }
    

    [System.Data.DataTable]GetDatatable() {
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$TemplateFile = $This.JtTemplateFile
        [String]$TemplateFileName = $TemplateFile.GetName()
        [System.Collections.ArrayList]$ColRens = $TemplateFile.GetJtColRens()

        $FilenameParts = $TemplateFileName.Split(".")

        [System.Data.Datatable]$Datatable = New-Object System.Data.Datatable
        
        foreach ($ColRen in $ColRens) {
            [String]$Header = [JtColRen]$ColRen.GetHeader()

            Write-JtLog ( -join ("GetDatatable.TemplateFileName:", $TemplateFileName, " Header:", $Header))
            $Datatable.Columns.Add($Header, "String")
        }
        
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog -Text ( -join ("____FileName:", $FileName))

            $FilenameParts = $FileName.Split(".")
            $Row = $Datatable.NewRow()
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$ColRen = $ColRens[$j]
                [String]$Header = $ColRen.GetHeader()
                [String]$Value = $ColRens[$j].GetOutput($FilenameParts[$j])
                $Row.($Header) = $Value
            }

            [JtColFile]$ColRen = New-JtColFileName
            [String]$Header = $ColRen.GetHeader()
            [String]$Value = $ColRen.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            [JtColFile]$ColRen = New-JtColFilePath
            [String]$Header = $ColRen.GetHeader()
            [String]$Value = $ColRen.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            $Datatable.Rows.Add($Row)
        }
        return $Datatable
    }

    
    [String]GetInfo() {
        Throw "GetInfo should be overwritten"
        return $Null
    }
    
    [String]GetLabel() {
        Throw "GetLabel should be overwritten"
        return $Null
    }
    
    [String]GetMdDoc() {
        Throw "GetMdDoc should be overwritten"
        return $Null
    }
    
    [String]GetOutputFileExtension() {
        Throw "GetOutputFileExtension should be overwritten"
        return $Null
    }
    
    [String]GetOutputFilePrefix() {
        Throw "GetOutputFilePrefix should be overwritten"
        return $Null
    }
    
    [String]GetOutputFilePrefixCsv() {
        return [JtIoFile]::FilePrefixFolder
    }
    
    [String]GetOutputFileExtensionCsv() {
        return [JtUtil]::FileExtensionCsv
    }
    
    [String]GetOutputFileLabelCsv() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefixCsv()
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$FileLabel = $MyFolderName
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $FileLabel)
        return $OutputFileName
    }
    
    [String]GetOutputFileName() {
        [String]$OutputFilePrefix = $This.GetOutputFilePrefix()
        [String]$OutputFileExtension = $This.GetOutputFileExtension()
        [String]$MyValue = $This.GetInfo()
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$FileLabel = -join ($MyFolderName, ".", $MyValue)
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $FileLabel, $OutputFileExtension)
        return $OutputFileName
    }


    [String]GetSum([String]$MyColumn) {
        [Decimal]$MySum = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            [Decimal]$MyDec = 0

            [String]$TemplateFileName = $This.JtTemplateFile.GetName()

            [String]$MyValue = $JtIoFile.GetInfoFromFileName($TemplateFileName, $JtIoFile.GetName(), $MyColumn)
            $MyValue = $MyValue.Replace("_", ",")
            
            [Decimal]$MyDec = 0

            try {
                [Decimal]$MyDec = [Decimal]$MyValue
            }
            catch {
                Write-JtError -Text ( -join ("Problme in COL:", $MyColumn, " with value:", $MyValue))
            }
            $MySum = $MySum + $MyDec
        }
        [Decimal]$DecResult = $MySum / 100

        [String]$Result = $DecResult.ToString("0.00")
        $Result = $Result.Replace(",", "_")
        $Result = $Result.Replace(".", "_")
        return $Result
    }




    [String]GetTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionFolder
        return $Extension
    }
    
}

class JtFolderRenderer_Count : JtFolderRenderer {

    JtFolderRenderer_Count([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Count"
    }

    [System.Data.Datatable]GetDatatable() {
        [System.Data.Datatable]$Datatable = New-Object System.Data.Datatable 
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [System.Collections.ArrayList]$ColRens = $This.JtTemplateFile.GetJtColRens()

        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog -Text ( -join ("____FileName:", $FileName))
    
            $FilenameParts = $FileName.Split(".")
            $Row = $Datatable.NewRow()
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$ColRen = $ColRens[$j]
                [String]$Header = $ColRen.GetHeader()
                [String]$Value = $ColRens[$j].GetOutput($FilenameParts[$j])
                $Row.($Header) = $Value
            }

            [JtColFile]$ColRen = New-JtColFileYear
            [String]$Header = $ColRen.GetHeader()
            [String]$Value = $ColRen.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            [JtColFile]$ColRen = New-JtColFileAge
            [String]$Header = $ColRen.GetHeader()
            [String]$Value = $ColRen.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            $Datatable.Rows.Add($Row)
        }
        return $Datatable
    }

    [Decimal]GetInfo() {
        [Decimal]$MyCount = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            if ($JtIoFile.GetInfoFromFileName_Count_IsValid()) {
                [String]$MyAnz = $JtIoFile.GetInfoFromFileName_Count()
                [Decimal]$MyDecAnz = [Decimal]$MyAnz 
                $MyCount = $MyCount + $MyDecAnz
            }
            else {
                [JtIoFolder]$Folder = [JtIoFolder]::new($JtIoFile)
                Write-JtFolder -Text ( -join ("Problem with file: "), $JtIoFile.GetName()) -Path $Folder.GetPath()
            }
            
        }
        return $MyCount
    }

    [String]GetLabel() {
        return "COUNT"
    }
    
    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixAnzahl
        return $Result
    }
}


class JtFolderRenderer_Default : JtFolderRenderer {

    JtFolderRenderer_Default([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Default"
    }

    [Decimal]GetInfo() {
        [Decimal]$MyCount = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            Write-JtLog -Text ( -join ("JtIoFile: ", $JtIoFile.GetName()))
        }
        return $MyCount
    }

    
    [String]GetLabel() {
        return "DEFAULT"
    }
    
    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixAnzahl
        return $Result
    }

}


class JtFolderRenderer_Miete : JtFolderRenderer {

    JtFolderRenderer_Miete([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Miete"
    }
    


    [String]GetSum_Miete() {
        [String]$MyCol = "MIETE"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }

    [String]GetSum_Nebenkosten() {
        [String]$MyCol = "NEBENKOSTEN"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }

    [String]GetSum_Betrag() {
        [String]$MyCol = "BETRAG"
        [String]$MySum = $This.GetSum($MyCol)
        return $MySum
    }
    
    [System.Data.Datatable]GetDatatable() {
        [System.Data.Datatable]$Datatable = New-Object System.Data.Datatable
        [JtTemplateFile]$JtTemplateFile = $This.JtTemplateFile
        [System.Collections.ArrayList]$ColRens = $JtTemplateFile.GetJtColRens()

        [JtColRen]$ColRen = New-JtColRenInputTextNr
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")
        
        [Int32]$j = 0
        $j = 0
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")

        $j = 1
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")

        $j = 2
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")
        
        $j = 3
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")

        $j = 4
        [String]$MySum = $This.GetSum_Miete()
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")
        
        $j = 5
        [String]$MySum = $This.GetSum_Nebenkosten()
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")
        
        $j = 6
        [String]$MySum = $This.GetSum_Betrag
        [JtColRen]$ColRen = $ColRens[$j]
        $Datatable.Columns.Add($ColRen.GetHeader(), "String")


        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()

        [Int32]$IntLine = 1
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-Host "____FileName:" $FileName
            
            [String]$Value = ""
            
            $FilenameParts = $FileName.Split(".")
            $Row = $Datatable.NewRow()

            for ([Int32]$j = 0; $j -lt ($FilenameParts.Count - 1); $j++) {
                
                [JtColRen]$ColRen = New-JtColRenInputTextNr
                [String]$Header = $ColRen.GetHeader()
                $Row.($Header) = $IntLine

                [JtColRen]$ColRen = $ColRens[$j]
                
                if ($Null -eq $ColRen) {
                    Write-JtError -Text ( -join ("This should not happen. JtColRen is NULL. JtIoFile:", $JtIoFile.GetPath()))
                }
                else {
                    [String]$Header = $ColRen.GetHeader()
                    $Value = $ColRens[$j].GetOutput($FilenameParts[$j])
                    $Row.($Header) = $Value
                }
            }
            
            $Datatable.Rows.Add($Row)
            $IntLine = $IntLine + 1
        }
        
        $Row = $Datatable.NewRow()
        
        [JtColRen]$ColRen = New-JtColRenInputTextNr
        $Row.($ColRen.GetHeader()) = "SUM:"
        
        [Int32]$j = 0
        $j = 0
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = "(Monat)"

        $j = 1
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = "(Art)"

        $j = 2
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = "(Objekt)"
        
        $j = 3
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = "(Mieter)"

        $j = 4
        [String]$MySum = $This.GetSum_Miete()
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = $ColRen.GetOutput($MySum)
        
        $j = 5
        [String]$MySum = $This.GetSum_Nebenkosten()
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = $ColRen.GetOutput($MySum)
        
        $j = 6
        [String]$MySum = $This.GetSum_Betrag()
        [JtColRen]$ColRen = $ColRens[$j]
        $Row.($ColRen.GetHeader()) = $ColRen.GetOutput($MySum)

        $DataTable.Rows.Add($Row)

        return $DataTable
    }



    [String]GetInfo() {
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }

        $Result = -join ($This.GetSum_Miete(), ".", $This.GetSum_Nebenkosten(), ".", $This.GetSum_Betrag())
        return $Result
    }

    
    [String]GetLabel() {
        return "MIETE"
    }
    


    [String]GetMdDoc() {

        [String]$FolderName = $This.JtIoFolder.GetName()
        $FoldernameParts = $FolderName.split(".")
        [String]$Jahr = $FolderNameParts[$FoldernameParts.count-1]
        [MdDocument]$MdDocument = [MdDocument]::new(-Join("Zahlungen ", $Jahr))
        $MdDocument.AddLine( -join ("*", " ", "Stand: ", [JtLog]::GetMyTimestamp()))
        $MdDocument.AddLine( -join ("*", " ", $This.JtIoFolder.GetParentFolder().GetPath()))

        # $MdDocument.AddLine("Hier werden die Pläne aufgelistet.")

        $MdDocument.AddH2("Miete und Nebenkosten")

        [MdTable]$MyTable = [MdTable]::new($This.GetDatatable())

        $MdDocument.AddLine($MyTable.GetOutput())

        $MdDocument.AddLine("---")

        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName() {
        [String]$OutputFilePrefix = "zzz.ABRECHNUNG"
        [String]$OutputFileExtension = [JtIoFile]::FileExtensionMd
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $MyFolderName, $OutputFileExtension)
        return $OutputFileName
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

    [String]GetTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionWhg
        return $Extension
    }

}


class JtFolderRenderer_Poster : JtFolderRenderer {

    [JtPreisliste]$JtPreisliste = $Null
    [String]$TemplateFileName = $Null

    JtFolderRenderer_Poster([JtIoFolder]$TheJtIoFolder, [JtPreisliste]$MyJtPreisliste) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Poster"
        $This.JtPreisliste = $MyJtPreisliste
        $This.TemplateFileName = -join ("_NACHNAME.VORNAME.LABEL.PAPIER.BxH", [JtIoFile]::FileExtensionPoster)
    }
    

    
    [System.Data.DataTable]GetDatatable() {
        [System.Data.Datatable]$Datatable = New-Object System.Data.Datatable

        [JtColRen]$MyRen = New-JtColRenInputTextNr
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")
        
        [JtColFile]$MyRenFile = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
        $Datatable.Columns.Add($MyRenFile.GetHeader(), "String")
        
        [JtColRen]$MyRen = New-JtColRenInputText -Label "NACHNAME"
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")

        [JtColRen]$MyRen = New-JtColRenInputText -Label "VORNAME"
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")

        [JtColRen]$MyRen = New-JtColRenInputText -Label "LABEL"
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")

        [JtColRen]$MyRen = New-JtColRenInputText -Label "PAPIER"
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")

        [JtColRen]$MyRen = New-JtColRenInputText -Label "BxH"
        $Datatable.Columns.Add($MyRen.GetHeader(), "String")

        
        [JtColFile]$MyRenFile = New-JtColFileArea
        $Datatable.Columns.Add($MyRenFile.GetHeader(), "String")
        
        [JtColFile]$MyRenFile = New-JtColFileJtPreisliste_Paper -JtPreisliste $This.JtPreisliste
        $Datatable.Columns.Add($MyRenFile.GetHeader(), "String")
        
        [JtColFile]$MyRenFile = New-JtColFileJtPreisliste_Ink -JtPreisliste $This.JtPreisliste
        $Datatable.Columns.Add($MyRenFile.GetHeader(), "String")


        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()



        [Int32]$IntLine = 1
        foreach ($MyFile in $Files) {
            $Row = $Datatable.NewRow()
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-Host "____FileName:" $FileName
            
            [String]$Value = ""
            
            [JtColRen]$MyRen = New-JtColRenInputTextNr
            [String]$Value = $IntLine
            $Row.($MyRen.GetHeader()) = $Value
            
            $FilenameParts = $FileName.Split(".")

            [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
            [String]$Value = $JtColFile.GetOutputFile($JtIoFile)
            $Row.($JtColFile.GetHeader()) = $Value
            Write-JtLog ( -join ("Preis:", $Value))

            for ([Int32]$j = 0; $j -lt ($FilenameParts.Count - 1); $j++) {
                [JtColRen]$MyRen = New-JtColRenInputText -Label "NACHNAME" -Header "NACHNAME"
                $Value = $MyRen.GetOutput($FilenameParts[$j])
                [String]$Header = $MyRen.GetHeader()
                $Row.($MyRen.GetHeader()) = $Value
            }

            [JtColRen]$MyRen = New-JtColRenInputText -Label "NACHNAME"
            $Value = $FilenameParts[0]
            $Row.($MyRen.GetHeader()) = $Value
    
            [JtColRen]$MyRen = New-JtColRenInputText -Label "VORNAME"
            $Value = $FilenameParts[1]
            $Row.($MyRen.GetHeader()) = $Value
            
            [JtColRen]$MyRen = New-JtColRenInputText -Label "LABEL"
            $Value = $FilenameParts[2]
            $Row.($MyRen.GetHeader()) = $Value
    
            [JtColRen]$MyRen = New-JtColRenInputText -Label "PAPIER"
            $Value = $FilenameParts[3]
            $Row.($MyRen.GetHeader()) = $Value

            [JtColRen]$MyRen = New-JtColRenInputText -Label "BxH"
            $Value = $FilenameParts[4]
            $Row.($MyRen.GetHeader()) = $Value
            
            [JtColFile]$JtColFile = New-JtColFileArea
            [String]$Value = $JtColFile.GetOutputFile($JtIoFile)
            $Row.($JtColFile.GetHeader()) = $Value
            
            [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Paper -JtPreisliste $This.JtPreisliste
            [String]$Header = $JtColFile.GetHeader()
            [String]$Value = $JtColFile.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value
            
            [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Ink -JtPreisliste $This.JtPreisliste
            [String]$Header = $JtColFile.GetHeader()
            [String]$Value = $JtColFile.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value
            
            $Datatable

            $Datatable.Rows.Add($Row)
            $IntLine = $IntLine + 1
        }
        
        $Row = $Datatable.NewRow()

        [JtColRen]$MyRen = New-JtColRenInputTextNr
        [String]$Header = $MyRen.GetHeader()
        [String]$Value = "SUM:"
        $Row.($Header) = $Value

        [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColFile.GetHeader()
        [String]$Value = $This.GetInfo()
        $Row.($Header) = $Value

        [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Paper -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColFile.GetHeader()
        [String]$Value = ""
        $Row.($Header) = $Value

        [JtColFile]$JtColFile = New-JtColFileJtPreisliste_Ink -JtPreisliste $This.JtPreisliste
        [String]$Header = $JtColFile.GetHeader()
        [String]$Value = ""
        $Row.($Header) = $Value

        $Datatable.Rows.Add($Row)

        $Datatable

        return $Datatable
    }

    
    [String]GetInfo() {
        [JtTemplateFile]$TemplateFile = $This.JtTemplateFile
        [JtColFile]$ColFileJtPreisliste_Price = New-JtColFileJtPreisliste_Price -JtPreisliste $This.JtPreisliste
        [Decimal]$MyPrice = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            
            [String]$MySheetPrice = $ColFileJtPreisliste_Price.GetOutput($JtIoFile)

            Write-JtLog ( -join ("___ MySheetPrice:", $MySheetPrice))
            [Decimal]$MyDecSheetPrice = [JtUtil]::GetConvert_StringToDecimal($MySheetPrice)
            Write-JtLog ( -join ("___ MyDecSheetPrice:", $MyDecSheetPrice))
    
            $MyPrice = $MyPrice + $MyDecSheetPrice
        }
        [Decimal]$DecResult = $MyPrice

        [String]$Result = [JtUtil]::GetConvert_DecimalToString2($DecResult)
        # $Result = $Result.Replace(", ", "_")
        # $Result = $Result.Replace(".", "_")
        return $Result
    }

    [String]GetLabel() {
        return "POSTER"
    }

    [String]GetMdDoc() {
        [MdDocument]$MdDocument = [MdDocument]::new("Fakultät für Architektur und Landschaft")
        $MdDocument.AddLine("https://www.archland.uni-hannover.de/de/fakultaet/ausstattung/plotservice/")
        $MdDocument.AddH2("Plot-Service - Abrechnung")
        $MdDocument.AddLine( -join ("*", " ", "Stand: ", [JtLog]::GetMyTimestamp()))
        $MdDocument.AddLine( -join ("*", " ", "JtPreisliste: ", $This.JtPreisliste.GetTitle()))
        $MdDocument.AddLine( -join ("*", " ", $This.JtIoFolder.GetPath()))

        $MdDocument.AddH2("Pläne")

        [MdTable]$MyTable = [MdTable]::new($This.GetDatatable())

        $MdDocument.AddLine($MyTable.GetOutput())

        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Kunde")
        $MdDocument.AddLine("---")
        $MdDocument.AddLine("Plot-Service")
        $MdDocument.AddLine("---")

        return $MdDocument.GetOutput()
    }

    [String]GetMdFileName() {
        [String]$OutputFilePrefix = "zzz.ABRECHNUNG"
        [String]$OutputFileExtension = [JtIoFile]::FileExtensionMd
        
        [String]$MyFolderName = $This.JtIoFolder.GetName()
        [String]$OutputFileName = -join ($OutputFilePrefix, ".", $MyFolderName, $OutputFileExtension)
        return $OutputFileName
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

    [String]GetTemplateFileExtension() {
        [String]$Extension = [JtIoFile]::FileExtensionPoster
        return $Extension
    }
}


class JtFolderRenderer_Sum : JtFolderRenderer {

    JtFolderRenderer_Sum([JtIoFolder]$TheJtIoFolder) : Base($TheJtIoFolder) {
        $This.ClassName = "JtFolderRenderer_Sum"
    }
    
    [System.Data.Datatable]GetNewDatatable() {
        [System.Data.Datatable]$Datatable = New-Object System.Data.Datatable
        [System.Collections.ArrayList]$Files = $This.JtIoFolder.GetNormalFiles()
        [JtTemplateFile]$JtTemplateFile = $This.JtTemplateFile
    
        foreach ($MyFile in $Files) {
            [JtIoFile]$JtIoFile = $MyFile
            [String]$FileName = $JtIoFile.GetName()
            Write-JtLog ( -join ("____FileName: ", $FileName))
            
            [String]$Value = ""
            
            $Row = $Datatable.NewRow()
            $FilenameParts = $FileName.Split(".")
            for ([Int32]$j = 0; $j -lt $FilenameParts.Count; $j++) {
                [JtColRen]$Ren = $JtTemplateFile.GetJtColRenForColumnNumber($j)

                [String]$Header = $Ren.GetHeader()
                [String]$Value = $Ren.GetOutput($FilenameParts[$j])
                $Row.($Header) = $Value
            }

            [JtColFile]$Ren = New-JtColFileYear
            [String]$Header = $Ren.GetHeader()
            [String]$Value = $Ren.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            [JtColFile]$Ren = New-JtColFileAge
            [String]$Header = $Ren.GetHeader()
            [String]$Value = $Ren.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            [JtColFile]$Ren = New-JtColFileName
            [String]$Header = $Ren.GetHeader()
            [String]$Value = $Ren.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            [JtColFile]$Ren = New-JtColFilePath
            [String]$Header = $Ren.GetHeader()
            [String]$Value = $Ren.GetOutputFile($JtIoFile)
            $Row.($Header) = $Value

            $Datatable.Rows.Add($Row)
        }
        return $Datatable

        
    }


    [String]GetInfo() {
        [Decimal]$MySum = 0
        if (!($This.JtIoFolder.IsExisting())) {
            Write-JtError -Text ( -join ("Error!!! Please edit XML for:", $This.JtIoFolder.GetPath()))
            return $False
        }
        $Files = $This.JtIoFolder.GetNormalFiles()
        for ([int32]$i = 0; $i -lt $Files.Count; $i++) {
            [JtIoFile]$JtIoFile = $Files[$i]
            [Decimal]$MyDecEuro = 0

            if ($JtIoFile.GetInfoFromFileName_Euro_IsValid()) {
                [String]$MyEuro = $JtIoFile.GetInfoFromFileName_Euro()
                
                # Write-Host "___MyEuro:" $MyEuro
                [Decimal]$MyDecEuro = [Decimal]$MyEuro 
                # Write-Host "___MyDecEuro:" $MyDecEuro
            }
            else {
                [JtIoFolder]$JtIoFolder = [JtIoFolder]::new($JtIoFile)
                Write-JtFolder -Text ( -join ("Problem with file EURO:", $JtIoFile.GetName())) -Path $JtIoFolder.GetPath()
            }
    
            $MySum = $MySum + $MyDecEuro
        }
        [Decimal]$DecResult = $MySum / 100

        [String]$Result = $DecResult.ToString("0.00")
        $Result = $Result.Replace(",", "_")
        $Result = $Result.Replace(".", "_")
        return $Result
    }

    [String]GetLabel() {
        return "SUM"
    }

    [String]GetOutputFileExtension() {
        [String]$Result = [JtIoFile]::FileExtensionSum
        return $Result
    }

    [String]GetOutputFilePrefix() {
        [String]$Result = [JtIoFile]::FilePrefixSum
        return $Result
    }

}
