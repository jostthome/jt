using module JtClass
using module JtIo
using module JtIoFile
using module JtIoFolder

class JtCsvWriter : JtClass {

    [System.Collections.ArrayList]$Objects = $Null
    [String]$Label = $Null
    [JtIoFolder]$JtIoFolder = $Null

    JtCsvWriter([JtIoFolder]$TheFolder, [System.Collections.ArrayList]$MyObjects, [String]$MyLabel) {
        $This.ClassName = "JtCsvWriter"
        $This.Objects = $MyObjects
        $This.JtIoFolder = $TheFolder
        $This.Label = $MyLabel
    }
    
    [String]GetFileName() {
        [String]$MyExtension = [JtIoFile]::FileExtensionCsv
        [String]$MyFileName = -join ($This.Label, $MyExtension)
        return $MyFileName
    }
    
    [String]GetFilePathCsv() {
        [String]$MyFileName = $This.GetFileName()
        # [JtIoFolder]$TheFolderCsv = $This.JtIoFolder.GetChild("csv", $True)
        [String]$MyFilePath = $This.JtIoFolder.GetFilePath($MyFileName)
        return $MyFilePath
    }

    [Boolean]DoWrite() {
        [String]$MyExtension = [JtIoFile]::FileExtensionCsv
        [String]$FilePathCsv = $This.GetFilePathCsv()
        Write-JtIo -Text ( -join ("WARNING. Creating ", $MyExtension, " file:", $FilePathCsv))
        $This.Objects | Export-Csv -Path $FilePathCsv -NoTypeInformation -Delimiter ";"
        return $True
    }
}



Function New-JtCsvWriter {

    Param (
        [Parameter()]
        [JtIoFolder]$JtIoFolder, 
        [Parameter()]
        [System.Collections.ArrayList]$JtObjects, 
        [Parameter()]
        [String]$Label
    )

    [JtCsvWriter]::new($JtIoFolder, $JtObjects, $Label)
}


class JtCsvData : JtClass {

    [System.Object[]]$DataTable = $Null
    [String]$Label = $Null
    [JtIoFolder]$JtIoFolder = $Null

    JtCsvData([JtIoFolder]$TheFolder, [System.Object[]]$MyDataTable, [String]$MyLabel) {
        $This.ClassName = "JtCsvWriter"
        $This.DataTable = $MyDataTable
        $This.JtIoFolder = $TheFolder
        $This.Label = $MyLabel
    }
    
    [String]GetFileName() {
        [String]$MyExtension = [JtIoFile]::FileExtensionCsv
        [String]$MyFileName = -join ($This.Label, $MyExtension)
        return $MyFileName
    }
    
    [String]GetFilePathCsv() {
        [String]$MyFileName = $This.GetFileName()
        # [JtIoFolder]$TheFolderCsv = $This.JtIoFolder.GetChild("csv", $True)
        [String]$MyFilePath = $This.JtIoFolder.GetFilePath($MyFileName)
        return $MyFilePath
    }

    [Boolean]DoWrite() {
        [String]$MyExtension = [JtIoFile]::FileExtensionCsv
        [String]$FilePathCsv = $This.GetFilePathCsv()
        Write-JtIo -Text ( -join ("WARNING. Creating ", $MyExtension, " file:", $FilePathCsv))

$TheData = $This.DataTable[0].Table

        $TheData | Export-Csv -Path $FilePathCsv -NoTypeInformation -Delimiter ";"
        return $True
    }
}

Function New-JtCsvData {

    Param (
        [Parameter()]
        [JtIoFolder]$JtIoFolder, 
        [Parameter()]
        [System.Object[]]$DataTable, 
        [Parameter()]
        [String]$Label
    )

    [JtCsvData]::new($JtIoFolder, $DataTable, $Label)
}
