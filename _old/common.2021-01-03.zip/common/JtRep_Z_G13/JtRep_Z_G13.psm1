using module JtTbl
using module JtInfi
using module JtRep

class JtRep_Z_G13 : JtRep {

    JtRep_Z_G13() : Base("z.g13") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)
        
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AffinityDesigner)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AffinityPhoto)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AffinityPublisher)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Revit_2021)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Office)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Office365)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seadrive)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seafile)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().LibreOffice)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Firefox64)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Thunderbird64)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AcrobatReader)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Inkscape)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellCommand)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellSuppAs)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DokanLibrary)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Flash)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        
        return $JtTblRow
    }
}

function New-JtRep_Z_G13 {

    [JtRep_Z_G13]::new() 

}


