using module JtTbl
using module JtInf_Soft
using module JtInfi
using module JtRep

class JtRep_Z_Iat : JtRep {
    
    JtRep_Z_Iat() : Base("z.iat") {
        $This.HideSpezial = $True
    }

    [JtTblRow]GetJtTblRow([JtInfi]$JtInfi) {
        [JtTblRow]$JtTblRow = $This.GetJtTblRowDefault($JtInfi)

        $JtTblRow.AddValue($JtInfi.GetJtInf_AFolder().WinVersion)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().CreativeSuite_CS6)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Photoshop_CC)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Office) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Rhino_6) 
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().SketchUp)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().vRay3ds)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().vRayRevit)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().vRayRhino)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().vRaySketchup)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().LenovoSysUp)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AutoCAD_2020)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Max_2020)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Maya_2020)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Revit_2020)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().ArchiCAD)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Vectorworks)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Cinema4D)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().GoogleEarth)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Unity)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().UnityHub)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Arduino)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().LibreOffice)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AcrobatReader)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().AntiVirus)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Chrome)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Firefox64)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Java)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().PDF24)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellCommand)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().DellSuppAs)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seadrive)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Seafile)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Sumatra)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().VLC)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().WibuKey)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Soft().Zip)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsCaption)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32OperatingSystem().OsVersion)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().Grafikkarte)
        $JtTblRow.AddValue($JtInfi.GetJtInf_Win32VideoController().TreiberVersion) 

        return $JtTblRow
    }

}



function New-JtRep_Z_Iat {

    [JtRep_Z_Iat]::new() 

}

